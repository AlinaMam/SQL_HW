
-- 1 users - пользователи
-- 2 profiles - cтраница пользователя
-- 3 hotels - отели
-- 4 hotel_review - отзывы об отелях
-- 5 hotel_reservations - бронирование отелей
-- 6 media_types - формат фотографий
-- 7 photo_album - фотоальбомы
-- 8 photos - фотографии
-- 9 user_pays - оплата пользователями
-- 10 payment_conditions - условия оплаты
-- 11 room_type - тип номера
-- 12 food_type - тип питания

drop database if exists booking;
create database booking;
use booking;

drop table if exists users;
create table users (
	id serial primary key,
    firstname varchar(50),
    lastname varchar(50),
    email varchar(120) unique,
    phone bigint unsigned unique,
    index users_email(email),
    index users_phone(phone)
    );
    
drop table if exists `profiles`;
create table `profiles` (
	user_id serial primary key,
    gender char(1),
    birthday date,
    created_at datetime default now(),
    hometown varchar(100),
    foreign key (user_id) references users(id)
);
    
drop table if exists hotels;
create table hotels (
	id serial primary key,
    name_hotel varchar(100),
    number_of_stars int unsigned,
    id_room_type bigint unsigned not null,
    id_food_type bigint unsigned not null, 
    index hotels_number_of_stars(number_of_stars)
);
    
drop table if exists hotel_review;
create table hotel_review (
	id bigint unsigned not null, 
    from_user_id bigint unsigned,
    to_hotel_id bigint unsigned,
    body text,
    created_at datetime default now(),
    foreign key (from_user_id) references users(id),
    foreign key (to_hotel_id) references hotels(id)
);

drop table if exists hotel_reservations;
create table hotel_reservations (
	user_id bigint unsigned not null,
    hotel_id bigint unsigned not null,
    arrival_date date, -- дата заезда
    departure_date date, -- дата выезда
    number_adults int unsigned not null, -- кол-во взрослых
    number_children int unsigned not null, -- кол-во детей
    id_room_type bigint unsigned not null, 
    id_food_type bigint unsigned not null, 
    foreign key (user_id) references users(id),
    foreign key (hotel_id) references hotels(id)
);

drop table if exists media_types;
create table media_types (
	id serial primary key,
    `name` varchar(100),
    created_at datetime default now(),
    updated_at datetime default current_timestamp on update current_timestamp
);


drop table if exists `photo_album`;
create table `photo_album` (
	`id` serial primary key,
    `name` varchar(100) default null,
    `hotel_id` bigint unsigned default null,
    `date` date,
    foreign key (hotel_id) references hotels(id)
);

drop table if exists photos;
create table photos (
	`id` serial primary key,
    album_id bigint unsigned not null,
    media_types_id bigint unsigned not null,
    `date` date,
    foreign key (album_id) references photo_album(id),
    foreign key (media_types_id) references media_types(id)
);

drop table if exists condition_payments;
create table condition_payments (
	`id` serial primary key,
    hotel_card_payment varchar(20) default null, -- оплата картой в отеле, значение в таблице да/нет
    site_card_payment varchar(20) default null -- оплата картой на месте, значение в таблице да/нет
);

 drop table if exists user_pays;
 create table user_pays (
	id serial primary key,
	user_id bigint unsigned,
    hotel_id bigint unsigned not null,
    currency varchar(20), -- валюта
    condition_payments_id bigint unsigned, -- метод оплаты
    amount_payment decimal(5,2), -- сумма оплаты
    target_amount_payment varchar(100),
    foreign key (user_id) references users(id),
    foreign key (condition_payments_id) references condition_payments(id),
    foreign key (hotel_id) references hotels(id)
 );
 
 drop table if exists room_type;
 create table room_type (
	id serial primary key,
    `name` varchar(20), 
    hotel_id bigint unsigned not null,
    foreign key (hotel_id) references hotels(id)
 );
 
 drop table if exists food_type;
 create table food_type (
 id serial primary key,
 `name` varchar(20),
 hotel_id bigint unsigned not null,
  foreign key (hotel_id) references hotels(id)
  );

 