#
# TABLE STRUCTURE FOR: condition_payments
#

DROP TABLE IF EXISTS `condition_payments`;

CREATE TABLE `condition_payments` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `hotel_card_payment` varchar(20) COLLATE utf8_unicode_ci DEFAULT NULL,
  `site_card_payment` varchar(20) COLLATE utf8_unicode_ci DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=101 DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

INSERT INTO `condition_payments` (`id`, `hotel_card_payment`, `site_card_payment`) VALUES ('1', '', '1');
INSERT INTO `condition_payments` (`id`, `hotel_card_payment`, `site_card_payment`) VALUES ('2', '', '');
INSERT INTO `condition_payments` (`id`, `hotel_card_payment`, `site_card_payment`) VALUES ('3', '1', '');
INSERT INTO `condition_payments` (`id`, `hotel_card_payment`, `site_card_payment`) VALUES ('4', '1', '1');
INSERT INTO `condition_payments` (`id`, `hotel_card_payment`, `site_card_payment`) VALUES ('5', '1', '1');
INSERT INTO `condition_payments` (`id`, `hotel_card_payment`, `site_card_payment`) VALUES ('6', '1', '');
INSERT INTO `condition_payments` (`id`, `hotel_card_payment`, `site_card_payment`) VALUES ('7', '1', '1');
INSERT INTO `condition_payments` (`id`, `hotel_card_payment`, `site_card_payment`) VALUES ('8', '1', '1');
INSERT INTO `condition_payments` (`id`, `hotel_card_payment`, `site_card_payment`) VALUES ('9', '', '');
INSERT INTO `condition_payments` (`id`, `hotel_card_payment`, `site_card_payment`) VALUES ('10', '1', '');
INSERT INTO `condition_payments` (`id`, `hotel_card_payment`, `site_card_payment`) VALUES ('11', '', '');
INSERT INTO `condition_payments` (`id`, `hotel_card_payment`, `site_card_payment`) VALUES ('12', '', '');
INSERT INTO `condition_payments` (`id`, `hotel_card_payment`, `site_card_payment`) VALUES ('13', '1', '1');
INSERT INTO `condition_payments` (`id`, `hotel_card_payment`, `site_card_payment`) VALUES ('14', '1', '');
INSERT INTO `condition_payments` (`id`, `hotel_card_payment`, `site_card_payment`) VALUES ('15', '', '1');
INSERT INTO `condition_payments` (`id`, `hotel_card_payment`, `site_card_payment`) VALUES ('16', '', '1');
INSERT INTO `condition_payments` (`id`, `hotel_card_payment`, `site_card_payment`) VALUES ('17', '1', '1');
INSERT INTO `condition_payments` (`id`, `hotel_card_payment`, `site_card_payment`) VALUES ('18', '', '');
INSERT INTO `condition_payments` (`id`, `hotel_card_payment`, `site_card_payment`) VALUES ('19', '1', '1');
INSERT INTO `condition_payments` (`id`, `hotel_card_payment`, `site_card_payment`) VALUES ('20', '1', '1');
INSERT INTO `condition_payments` (`id`, `hotel_card_payment`, `site_card_payment`) VALUES ('21', '', '');
INSERT INTO `condition_payments` (`id`, `hotel_card_payment`, `site_card_payment`) VALUES ('22', '1', '');
INSERT INTO `condition_payments` (`id`, `hotel_card_payment`, `site_card_payment`) VALUES ('23', '', '');
INSERT INTO `condition_payments` (`id`, `hotel_card_payment`, `site_card_payment`) VALUES ('24', '', '1');
INSERT INTO `condition_payments` (`id`, `hotel_card_payment`, `site_card_payment`) VALUES ('25', '', '');
INSERT INTO `condition_payments` (`id`, `hotel_card_payment`, `site_card_payment`) VALUES ('26', '', '');
INSERT INTO `condition_payments` (`id`, `hotel_card_payment`, `site_card_payment`) VALUES ('27', '', '1');
INSERT INTO `condition_payments` (`id`, `hotel_card_payment`, `site_card_payment`) VALUES ('28', '', '');
INSERT INTO `condition_payments` (`id`, `hotel_card_payment`, `site_card_payment`) VALUES ('29', '', '1');
INSERT INTO `condition_payments` (`id`, `hotel_card_payment`, `site_card_payment`) VALUES ('30', '1', '');
INSERT INTO `condition_payments` (`id`, `hotel_card_payment`, `site_card_payment`) VALUES ('31', '1', '');
INSERT INTO `condition_payments` (`id`, `hotel_card_payment`, `site_card_payment`) VALUES ('32', '1', '1');
INSERT INTO `condition_payments` (`id`, `hotel_card_payment`, `site_card_payment`) VALUES ('33', '1', '');
INSERT INTO `condition_payments` (`id`, `hotel_card_payment`, `site_card_payment`) VALUES ('34', '', '1');
INSERT INTO `condition_payments` (`id`, `hotel_card_payment`, `site_card_payment`) VALUES ('35', '', '1');
INSERT INTO `condition_payments` (`id`, `hotel_card_payment`, `site_card_payment`) VALUES ('36', '', '1');
INSERT INTO `condition_payments` (`id`, `hotel_card_payment`, `site_card_payment`) VALUES ('37', '1', '');
INSERT INTO `condition_payments` (`id`, `hotel_card_payment`, `site_card_payment`) VALUES ('38', '1', '');
INSERT INTO `condition_payments` (`id`, `hotel_card_payment`, `site_card_payment`) VALUES ('39', '1', '');
INSERT INTO `condition_payments` (`id`, `hotel_card_payment`, `site_card_payment`) VALUES ('40', '1', '1');
INSERT INTO `condition_payments` (`id`, `hotel_card_payment`, `site_card_payment`) VALUES ('41', '1', '1');
INSERT INTO `condition_payments` (`id`, `hotel_card_payment`, `site_card_payment`) VALUES ('42', '', '');
INSERT INTO `condition_payments` (`id`, `hotel_card_payment`, `site_card_payment`) VALUES ('43', '', '1');
INSERT INTO `condition_payments` (`id`, `hotel_card_payment`, `site_card_payment`) VALUES ('44', '', '1');
INSERT INTO `condition_payments` (`id`, `hotel_card_payment`, `site_card_payment`) VALUES ('45', '1', '');
INSERT INTO `condition_payments` (`id`, `hotel_card_payment`, `site_card_payment`) VALUES ('46', '', '1');
INSERT INTO `condition_payments` (`id`, `hotel_card_payment`, `site_card_payment`) VALUES ('47', '1', '1');
INSERT INTO `condition_payments` (`id`, `hotel_card_payment`, `site_card_payment`) VALUES ('48', '', '');
INSERT INTO `condition_payments` (`id`, `hotel_card_payment`, `site_card_payment`) VALUES ('49', '1', '1');
INSERT INTO `condition_payments` (`id`, `hotel_card_payment`, `site_card_payment`) VALUES ('50', '1', '');
INSERT INTO `condition_payments` (`id`, `hotel_card_payment`, `site_card_payment`) VALUES ('51', '1', '');
INSERT INTO `condition_payments` (`id`, `hotel_card_payment`, `site_card_payment`) VALUES ('52', '', '');
INSERT INTO `condition_payments` (`id`, `hotel_card_payment`, `site_card_payment`) VALUES ('53', '1', '1');
INSERT INTO `condition_payments` (`id`, `hotel_card_payment`, `site_card_payment`) VALUES ('54', '', '1');
INSERT INTO `condition_payments` (`id`, `hotel_card_payment`, `site_card_payment`) VALUES ('55', '1', '1');
INSERT INTO `condition_payments` (`id`, `hotel_card_payment`, `site_card_payment`) VALUES ('56', '', '');
INSERT INTO `condition_payments` (`id`, `hotel_card_payment`, `site_card_payment`) VALUES ('57', '', '');
INSERT INTO `condition_payments` (`id`, `hotel_card_payment`, `site_card_payment`) VALUES ('58', '', '1');
INSERT INTO `condition_payments` (`id`, `hotel_card_payment`, `site_card_payment`) VALUES ('59', '', '1');
INSERT INTO `condition_payments` (`id`, `hotel_card_payment`, `site_card_payment`) VALUES ('60', '1', '');
INSERT INTO `condition_payments` (`id`, `hotel_card_payment`, `site_card_payment`) VALUES ('61', '', '1');
INSERT INTO `condition_payments` (`id`, `hotel_card_payment`, `site_card_payment`) VALUES ('62', '1', '');
INSERT INTO `condition_payments` (`id`, `hotel_card_payment`, `site_card_payment`) VALUES ('63', '', '');
INSERT INTO `condition_payments` (`id`, `hotel_card_payment`, `site_card_payment`) VALUES ('64', '', '1');
INSERT INTO `condition_payments` (`id`, `hotel_card_payment`, `site_card_payment`) VALUES ('65', '', '');
INSERT INTO `condition_payments` (`id`, `hotel_card_payment`, `site_card_payment`) VALUES ('66', '1', '');
INSERT INTO `condition_payments` (`id`, `hotel_card_payment`, `site_card_payment`) VALUES ('67', '', '1');
INSERT INTO `condition_payments` (`id`, `hotel_card_payment`, `site_card_payment`) VALUES ('68', '', '');
INSERT INTO `condition_payments` (`id`, `hotel_card_payment`, `site_card_payment`) VALUES ('69', '', '');
INSERT INTO `condition_payments` (`id`, `hotel_card_payment`, `site_card_payment`) VALUES ('70', '1', '1');
INSERT INTO `condition_payments` (`id`, `hotel_card_payment`, `site_card_payment`) VALUES ('71', '1', '');
INSERT INTO `condition_payments` (`id`, `hotel_card_payment`, `site_card_payment`) VALUES ('72', '1', '');
INSERT INTO `condition_payments` (`id`, `hotel_card_payment`, `site_card_payment`) VALUES ('73', '1', '1');
INSERT INTO `condition_payments` (`id`, `hotel_card_payment`, `site_card_payment`) VALUES ('74', '', '');
INSERT INTO `condition_payments` (`id`, `hotel_card_payment`, `site_card_payment`) VALUES ('75', '1', '1');
INSERT INTO `condition_payments` (`id`, `hotel_card_payment`, `site_card_payment`) VALUES ('76', '', '1');
INSERT INTO `condition_payments` (`id`, `hotel_card_payment`, `site_card_payment`) VALUES ('77', '1', '');
INSERT INTO `condition_payments` (`id`, `hotel_card_payment`, `site_card_payment`) VALUES ('78', '1', '');
INSERT INTO `condition_payments` (`id`, `hotel_card_payment`, `site_card_payment`) VALUES ('79', '1', '');
INSERT INTO `condition_payments` (`id`, `hotel_card_payment`, `site_card_payment`) VALUES ('80', '', '');
INSERT INTO `condition_payments` (`id`, `hotel_card_payment`, `site_card_payment`) VALUES ('81', '', '');
INSERT INTO `condition_payments` (`id`, `hotel_card_payment`, `site_card_payment`) VALUES ('82', '1', '1');
INSERT INTO `condition_payments` (`id`, `hotel_card_payment`, `site_card_payment`) VALUES ('83', '', '1');
INSERT INTO `condition_payments` (`id`, `hotel_card_payment`, `site_card_payment`) VALUES ('84', '1', '');
INSERT INTO `condition_payments` (`id`, `hotel_card_payment`, `site_card_payment`) VALUES ('85', '', '1');
INSERT INTO `condition_payments` (`id`, `hotel_card_payment`, `site_card_payment`) VALUES ('86', '1', '');
INSERT INTO `condition_payments` (`id`, `hotel_card_payment`, `site_card_payment`) VALUES ('87', '', '1');
INSERT INTO `condition_payments` (`id`, `hotel_card_payment`, `site_card_payment`) VALUES ('88', '1', '');
INSERT INTO `condition_payments` (`id`, `hotel_card_payment`, `site_card_payment`) VALUES ('89', '1', '');
INSERT INTO `condition_payments` (`id`, `hotel_card_payment`, `site_card_payment`) VALUES ('90', '', '1');
INSERT INTO `condition_payments` (`id`, `hotel_card_payment`, `site_card_payment`) VALUES ('91', '', '');
INSERT INTO `condition_payments` (`id`, `hotel_card_payment`, `site_card_payment`) VALUES ('92', '1', '1');
INSERT INTO `condition_payments` (`id`, `hotel_card_payment`, `site_card_payment`) VALUES ('93', '1', '');
INSERT INTO `condition_payments` (`id`, `hotel_card_payment`, `site_card_payment`) VALUES ('94', '1', '');
INSERT INTO `condition_payments` (`id`, `hotel_card_payment`, `site_card_payment`) VALUES ('95', '', '');
INSERT INTO `condition_payments` (`id`, `hotel_card_payment`, `site_card_payment`) VALUES ('96', '1', '');
INSERT INTO `condition_payments` (`id`, `hotel_card_payment`, `site_card_payment`) VALUES ('97', '1', '');
INSERT INTO `condition_payments` (`id`, `hotel_card_payment`, `site_card_payment`) VALUES ('98', '', '');
INSERT INTO `condition_payments` (`id`, `hotel_card_payment`, `site_card_payment`) VALUES ('99', '', '');
INSERT INTO `condition_payments` (`id`, `hotel_card_payment`, `site_card_payment`) VALUES ('100', '', '');


#
# TABLE STRUCTURE FOR: food_type
#

DROP TABLE IF EXISTS `food_type`;

CREATE TABLE `food_type` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `name` varchar(20) COLLATE utf8_unicode_ci DEFAULT NULL,
  `hotel_id` bigint(20) unsigned NOT NULL,
  PRIMARY KEY (`id`),
  KEY `hotel_id` (`hotel_id`),
  CONSTRAINT `food_type_ibfk_1` FOREIGN KEY (`hotel_id`) REFERENCES `hotels` (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=101 DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

INSERT INTO `food_type` (`id`, `name`, `hotel_id`) VALUES ('1', 'incidunt', '1');
INSERT INTO `food_type` (`id`, `name`, `hotel_id`) VALUES ('2', 'cumque', '2');
INSERT INTO `food_type` (`id`, `name`, `hotel_id`) VALUES ('3', 'illum', '3');
INSERT INTO `food_type` (`id`, `name`, `hotel_id`) VALUES ('4', 'minus', '4');
INSERT INTO `food_type` (`id`, `name`, `hotel_id`) VALUES ('5', 'quidem', '5');
INSERT INTO `food_type` (`id`, `name`, `hotel_id`) VALUES ('6', 'numquam', '6');
INSERT INTO `food_type` (`id`, `name`, `hotel_id`) VALUES ('7', 'consectetur', '7');
INSERT INTO `food_type` (`id`, `name`, `hotel_id`) VALUES ('8', 'ea', '8');
INSERT INTO `food_type` (`id`, `name`, `hotel_id`) VALUES ('9', 'corporis', '9');
INSERT INTO `food_type` (`id`, `name`, `hotel_id`) VALUES ('10', 'distinctio', '10');
INSERT INTO `food_type` (`id`, `name`, `hotel_id`) VALUES ('11', 'distinctio', '11');
INSERT INTO `food_type` (`id`, `name`, `hotel_id`) VALUES ('12', 'vero', '12');
INSERT INTO `food_type` (`id`, `name`, `hotel_id`) VALUES ('13', 'possimus', '13');
INSERT INTO `food_type` (`id`, `name`, `hotel_id`) VALUES ('14', 'illum', '14');
INSERT INTO `food_type` (`id`, `name`, `hotel_id`) VALUES ('15', 'et', '15');
INSERT INTO `food_type` (`id`, `name`, `hotel_id`) VALUES ('16', 'tenetur', '16');
INSERT INTO `food_type` (`id`, `name`, `hotel_id`) VALUES ('17', 'dolore', '17');
INSERT INTO `food_type` (`id`, `name`, `hotel_id`) VALUES ('18', 'quibusdam', '18');
INSERT INTO `food_type` (`id`, `name`, `hotel_id`) VALUES ('19', 'corrupti', '19');
INSERT INTO `food_type` (`id`, `name`, `hotel_id`) VALUES ('20', 'sed', '20');
INSERT INTO `food_type` (`id`, `name`, `hotel_id`) VALUES ('21', 'ut', '21');
INSERT INTO `food_type` (`id`, `name`, `hotel_id`) VALUES ('22', 'illum', '22');
INSERT INTO `food_type` (`id`, `name`, `hotel_id`) VALUES ('23', 'error', '23');
INSERT INTO `food_type` (`id`, `name`, `hotel_id`) VALUES ('24', 'magni', '24');
INSERT INTO `food_type` (`id`, `name`, `hotel_id`) VALUES ('25', 'aut', '25');
INSERT INTO `food_type` (`id`, `name`, `hotel_id`) VALUES ('26', 'enim', '26');
INSERT INTO `food_type` (`id`, `name`, `hotel_id`) VALUES ('27', 'praesentium', '27');
INSERT INTO `food_type` (`id`, `name`, `hotel_id`) VALUES ('28', 'omnis', '28');
INSERT INTO `food_type` (`id`, `name`, `hotel_id`) VALUES ('29', 'unde', '29');
INSERT INTO `food_type` (`id`, `name`, `hotel_id`) VALUES ('30', 'est', '30');
INSERT INTO `food_type` (`id`, `name`, `hotel_id`) VALUES ('31', 'est', '31');
INSERT INTO `food_type` (`id`, `name`, `hotel_id`) VALUES ('32', 'quo', '32');
INSERT INTO `food_type` (`id`, `name`, `hotel_id`) VALUES ('33', 'aut', '33');
INSERT INTO `food_type` (`id`, `name`, `hotel_id`) VALUES ('34', 'quaerat', '34');
INSERT INTO `food_type` (`id`, `name`, `hotel_id`) VALUES ('35', 'et', '35');
INSERT INTO `food_type` (`id`, `name`, `hotel_id`) VALUES ('36', 'qui', '36');
INSERT INTO `food_type` (`id`, `name`, `hotel_id`) VALUES ('37', 'quasi', '37');
INSERT INTO `food_type` (`id`, `name`, `hotel_id`) VALUES ('38', 'ab', '38');
INSERT INTO `food_type` (`id`, `name`, `hotel_id`) VALUES ('39', 'tempora', '39');
INSERT INTO `food_type` (`id`, `name`, `hotel_id`) VALUES ('40', 'minima', '40');
INSERT INTO `food_type` (`id`, `name`, `hotel_id`) VALUES ('41', 'ea', '41');
INSERT INTO `food_type` (`id`, `name`, `hotel_id`) VALUES ('42', 'consequatur', '42');
INSERT INTO `food_type` (`id`, `name`, `hotel_id`) VALUES ('43', 'voluptas', '43');
INSERT INTO `food_type` (`id`, `name`, `hotel_id`) VALUES ('44', 'tenetur', '44');
INSERT INTO `food_type` (`id`, `name`, `hotel_id`) VALUES ('45', 'officiis', '45');
INSERT INTO `food_type` (`id`, `name`, `hotel_id`) VALUES ('46', 'fuga', '46');
INSERT INTO `food_type` (`id`, `name`, `hotel_id`) VALUES ('47', 'blanditiis', '47');
INSERT INTO `food_type` (`id`, `name`, `hotel_id`) VALUES ('48', 'aliquam', '48');
INSERT INTO `food_type` (`id`, `name`, `hotel_id`) VALUES ('49', 'eaque', '49');
INSERT INTO `food_type` (`id`, `name`, `hotel_id`) VALUES ('50', 'magni', '50');
INSERT INTO `food_type` (`id`, `name`, `hotel_id`) VALUES ('51', 'omnis', '51');
INSERT INTO `food_type` (`id`, `name`, `hotel_id`) VALUES ('52', 'id', '52');
INSERT INTO `food_type` (`id`, `name`, `hotel_id`) VALUES ('53', 'omnis', '53');
INSERT INTO `food_type` (`id`, `name`, `hotel_id`) VALUES ('54', 'quam', '54');
INSERT INTO `food_type` (`id`, `name`, `hotel_id`) VALUES ('55', 'repellendus', '55');
INSERT INTO `food_type` (`id`, `name`, `hotel_id`) VALUES ('56', 'et', '56');
INSERT INTO `food_type` (`id`, `name`, `hotel_id`) VALUES ('57', 'voluptatem', '57');
INSERT INTO `food_type` (`id`, `name`, `hotel_id`) VALUES ('58', 'non', '58');
INSERT INTO `food_type` (`id`, `name`, `hotel_id`) VALUES ('59', 'possimus', '59');
INSERT INTO `food_type` (`id`, `name`, `hotel_id`) VALUES ('60', 'eos', '60');
INSERT INTO `food_type` (`id`, `name`, `hotel_id`) VALUES ('61', 'ullam', '61');
INSERT INTO `food_type` (`id`, `name`, `hotel_id`) VALUES ('62', 'provident', '62');
INSERT INTO `food_type` (`id`, `name`, `hotel_id`) VALUES ('63', 'autem', '63');
INSERT INTO `food_type` (`id`, `name`, `hotel_id`) VALUES ('64', 'maxime', '64');
INSERT INTO `food_type` (`id`, `name`, `hotel_id`) VALUES ('65', 'occaecati', '65');
INSERT INTO `food_type` (`id`, `name`, `hotel_id`) VALUES ('66', 'et', '66');
INSERT INTO `food_type` (`id`, `name`, `hotel_id`) VALUES ('67', 'quis', '67');
INSERT INTO `food_type` (`id`, `name`, `hotel_id`) VALUES ('68', 'omnis', '68');
INSERT INTO `food_type` (`id`, `name`, `hotel_id`) VALUES ('69', 'aliquid', '69');
INSERT INTO `food_type` (`id`, `name`, `hotel_id`) VALUES ('70', 'asperiores', '70');
INSERT INTO `food_type` (`id`, `name`, `hotel_id`) VALUES ('71', 'id', '71');
INSERT INTO `food_type` (`id`, `name`, `hotel_id`) VALUES ('72', 'enim', '72');
INSERT INTO `food_type` (`id`, `name`, `hotel_id`) VALUES ('73', 'aperiam', '73');
INSERT INTO `food_type` (`id`, `name`, `hotel_id`) VALUES ('74', 'molestiae', '74');
INSERT INTO `food_type` (`id`, `name`, `hotel_id`) VALUES ('75', 'fugiat', '75');
INSERT INTO `food_type` (`id`, `name`, `hotel_id`) VALUES ('76', 'ut', '76');
INSERT INTO `food_type` (`id`, `name`, `hotel_id`) VALUES ('77', 'omnis', '77');
INSERT INTO `food_type` (`id`, `name`, `hotel_id`) VALUES ('78', 'velit', '78');
INSERT INTO `food_type` (`id`, `name`, `hotel_id`) VALUES ('79', 'et', '79');
INSERT INTO `food_type` (`id`, `name`, `hotel_id`) VALUES ('80', 'ipsa', '80');
INSERT INTO `food_type` (`id`, `name`, `hotel_id`) VALUES ('81', 'aut', '81');
INSERT INTO `food_type` (`id`, `name`, `hotel_id`) VALUES ('82', 'expedita', '82');
INSERT INTO `food_type` (`id`, `name`, `hotel_id`) VALUES ('83', 'corrupti', '83');
INSERT INTO `food_type` (`id`, `name`, `hotel_id`) VALUES ('84', 'totam', '84');
INSERT INTO `food_type` (`id`, `name`, `hotel_id`) VALUES ('85', 'tempore', '85');
INSERT INTO `food_type` (`id`, `name`, `hotel_id`) VALUES ('86', 'esse', '86');
INSERT INTO `food_type` (`id`, `name`, `hotel_id`) VALUES ('87', 'laudantium', '87');
INSERT INTO `food_type` (`id`, `name`, `hotel_id`) VALUES ('88', 'excepturi', '88');
INSERT INTO `food_type` (`id`, `name`, `hotel_id`) VALUES ('89', 'officiis', '89');
INSERT INTO `food_type` (`id`, `name`, `hotel_id`) VALUES ('90', 'consectetur', '90');
INSERT INTO `food_type` (`id`, `name`, `hotel_id`) VALUES ('91', 'fuga', '91');
INSERT INTO `food_type` (`id`, `name`, `hotel_id`) VALUES ('92', 'placeat', '92');
INSERT INTO `food_type` (`id`, `name`, `hotel_id`) VALUES ('93', 'quia', '93');
INSERT INTO `food_type` (`id`, `name`, `hotel_id`) VALUES ('94', 'accusantium', '94');
INSERT INTO `food_type` (`id`, `name`, `hotel_id`) VALUES ('95', 'omnis', '95');
INSERT INTO `food_type` (`id`, `name`, `hotel_id`) VALUES ('96', 'nobis', '96');
INSERT INTO `food_type` (`id`, `name`, `hotel_id`) VALUES ('97', 'sit', '97');
INSERT INTO `food_type` (`id`, `name`, `hotel_id`) VALUES ('98', 'eum', '98');
INSERT INTO `food_type` (`id`, `name`, `hotel_id`) VALUES ('99', 'est', '99');
INSERT INTO `food_type` (`id`, `name`, `hotel_id`) VALUES ('100', 'quisquam', '100');


#
# TABLE STRUCTURE FOR: hotel_reservations
#

DROP TABLE IF EXISTS `hotel_reservations`;

CREATE TABLE `hotel_reservations` (
  `user_id` bigint(20) unsigned NOT NULL,
  `hotel_id` bigint(20) unsigned NOT NULL,
  `arrival_date` date DEFAULT NULL,
  `departure_date` date DEFAULT NULL,
  `number_adults` int(10) unsigned NOT NULL,
  `number_children` int(10) unsigned NOT NULL,
  `id_room_type` bigint(20) unsigned NOT NULL,
  `id_food_type` bigint(20) unsigned NOT NULL,
  KEY `user_id` (`user_id`),
  KEY `hotel_id` (`hotel_id`),
  CONSTRAINT `hotel_reservations_ibfk_1` FOREIGN KEY (`user_id`) REFERENCES `users` (`id`),
  CONSTRAINT `hotel_reservations_ibfk_2` FOREIGN KEY (`hotel_id`) REFERENCES `hotels` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

INSERT INTO `hotel_reservations` (`user_id`, `hotel_id`, `arrival_date`, `departure_date`, `number_adults`, `number_children`, `id_room_type`, `id_food_type`) VALUES ('101', '1', '1997-06-27', '1996-12-01', 9, 3, '5', '3');
INSERT INTO `hotel_reservations` (`user_id`, `hotel_id`, `arrival_date`, `departure_date`, `number_adults`, `number_children`, `id_room_type`, `id_food_type`) VALUES ('102', '2', '1988-12-19', '1971-05-10', 9, 7, '3', '9');
INSERT INTO `hotel_reservations` (`user_id`, `hotel_id`, `arrival_date`, `departure_date`, `number_adults`, `number_children`, `id_room_type`, `id_food_type`) VALUES ('103', '3', '1992-09-19', '1985-02-13', 6, 1, '6', '7');
INSERT INTO `hotel_reservations` (`user_id`, `hotel_id`, `arrival_date`, `departure_date`, `number_adults`, `number_children`, `id_room_type`, `id_food_type`) VALUES ('104', '4', '1996-10-22', '2019-06-03', 2, 7, '8', '5');
INSERT INTO `hotel_reservations` (`user_id`, `hotel_id`, `arrival_date`, `departure_date`, `number_adults`, `number_children`, `id_room_type`, `id_food_type`) VALUES ('105', '5', '1993-10-23', '1973-09-24', 4, 6, '8', '6');
INSERT INTO `hotel_reservations` (`user_id`, `hotel_id`, `arrival_date`, `departure_date`, `number_adults`, `number_children`, `id_room_type`, `id_food_type`) VALUES ('106', '6', '1981-11-22', '1999-07-23', 3, 7, '6', '8');
INSERT INTO `hotel_reservations` (`user_id`, `hotel_id`, `arrival_date`, `departure_date`, `number_adults`, `number_children`, `id_room_type`, `id_food_type`) VALUES ('107', '7', '1999-08-21', '1993-10-15', 6, 2, '5', '3');
INSERT INTO `hotel_reservations` (`user_id`, `hotel_id`, `arrival_date`, `departure_date`, `number_adults`, `number_children`, `id_room_type`, `id_food_type`) VALUES ('108', '8', '1991-05-25', '1996-08-01', 2, 3, '1', '3');
INSERT INTO `hotel_reservations` (`user_id`, `hotel_id`, `arrival_date`, `departure_date`, `number_adults`, `number_children`, `id_room_type`, `id_food_type`) VALUES ('109', '9', '2017-01-24', '1994-05-25', 9, 9, '5', '7');
INSERT INTO `hotel_reservations` (`user_id`, `hotel_id`, `arrival_date`, `departure_date`, `number_adults`, `number_children`, `id_room_type`, `id_food_type`) VALUES ('110', '10', '1986-03-13', '2005-06-09', 7, 7, '3', '6');
INSERT INTO `hotel_reservations` (`user_id`, `hotel_id`, `arrival_date`, `departure_date`, `number_adults`, `number_children`, `id_room_type`, `id_food_type`) VALUES ('112', '11', '1991-11-27', '1990-01-29', 5, 1, '7', '7');
INSERT INTO `hotel_reservations` (`user_id`, `hotel_id`, `arrival_date`, `departure_date`, `number_adults`, `number_children`, `id_room_type`, `id_food_type`) VALUES ('114', '12', '2000-04-18', '1980-09-18', 1, 9, '7', '8');
INSERT INTO `hotel_reservations` (`user_id`, `hotel_id`, `arrival_date`, `departure_date`, `number_adults`, `number_children`, `id_room_type`, `id_food_type`) VALUES ('115', '13', '1970-10-11', '2018-06-05', 8, 4, '3', '9');
INSERT INTO `hotel_reservations` (`user_id`, `hotel_id`, `arrival_date`, `departure_date`, `number_adults`, `number_children`, `id_room_type`, `id_food_type`) VALUES ('116', '14', '2017-02-01', '1977-07-27', 4, 9, '7', '7');
INSERT INTO `hotel_reservations` (`user_id`, `hotel_id`, `arrival_date`, `departure_date`, `number_adults`, `number_children`, `id_room_type`, `id_food_type`) VALUES ('118', '15', '1990-09-14', '2010-11-19', 4, 3, '1', '1');
INSERT INTO `hotel_reservations` (`user_id`, `hotel_id`, `arrival_date`, `departure_date`, `number_adults`, `number_children`, `id_room_type`, `id_food_type`) VALUES ('120', '16', '2001-08-12', '1986-11-06', 2, 3, '8', '1');
INSERT INTO `hotel_reservations` (`user_id`, `hotel_id`, `arrival_date`, `departure_date`, `number_adults`, `number_children`, `id_room_type`, `id_food_type`) VALUES ('124', '17', '2005-10-27', '2017-03-12', 3, 2, '1', '8');
INSERT INTO `hotel_reservations` (`user_id`, `hotel_id`, `arrival_date`, `departure_date`, `number_adults`, `number_children`, `id_room_type`, `id_food_type`) VALUES ('126', '18', '2003-04-03', '2008-04-22', 6, 3, '1', '7');
INSERT INTO `hotel_reservations` (`user_id`, `hotel_id`, `arrival_date`, `departure_date`, `number_adults`, `number_children`, `id_room_type`, `id_food_type`) VALUES ('127', '19', '2014-01-17', '1986-09-28', 9, 7, '2', '1');
INSERT INTO `hotel_reservations` (`user_id`, `hotel_id`, `arrival_date`, `departure_date`, `number_adults`, `number_children`, `id_room_type`, `id_food_type`) VALUES ('128', '20', '2006-11-02', '2010-10-24', 1, 7, '6', '8');
INSERT INTO `hotel_reservations` (`user_id`, `hotel_id`, `arrival_date`, `departure_date`, `number_adults`, `number_children`, `id_room_type`, `id_food_type`) VALUES ('134', '21', '1977-03-10', '1980-09-15', 9, 9, '4', '3');
INSERT INTO `hotel_reservations` (`user_id`, `hotel_id`, `arrival_date`, `departure_date`, `number_adults`, `number_children`, `id_room_type`, `id_food_type`) VALUES ('137', '22', '1971-12-25', '1977-01-17', 7, 4, '7', '5');
INSERT INTO `hotel_reservations` (`user_id`, `hotel_id`, `arrival_date`, `departure_date`, `number_adults`, `number_children`, `id_room_type`, `id_food_type`) VALUES ('138', '23', '2009-10-19', '1999-09-17', 1, 7, '2', '4');
INSERT INTO `hotel_reservations` (`user_id`, `hotel_id`, `arrival_date`, `departure_date`, `number_adults`, `number_children`, `id_room_type`, `id_food_type`) VALUES ('140', '24', '1973-06-17', '2008-09-25', 4, 4, '7', '8');
INSERT INTO `hotel_reservations` (`user_id`, `hotel_id`, `arrival_date`, `departure_date`, `number_adults`, `number_children`, `id_room_type`, `id_food_type`) VALUES ('145', '25', '1999-11-21', '2003-05-30', 2, 8, '4', '8');
INSERT INTO `hotel_reservations` (`user_id`, `hotel_id`, `arrival_date`, `departure_date`, `number_adults`, `number_children`, `id_room_type`, `id_food_type`) VALUES ('146', '26', '2000-10-14', '1997-02-13', 5, 9, '5', '9');
INSERT INTO `hotel_reservations` (`user_id`, `hotel_id`, `arrival_date`, `departure_date`, `number_adults`, `number_children`, `id_room_type`, `id_food_type`) VALUES ('147', '27', '1995-07-12', '2003-09-29', 5, 9, '2', '4');
INSERT INTO `hotel_reservations` (`user_id`, `hotel_id`, `arrival_date`, `departure_date`, `number_adults`, `number_children`, `id_room_type`, `id_food_type`) VALUES ('148', '28', '1970-05-30', '2017-04-08', 5, 7, '1', '9');
INSERT INTO `hotel_reservations` (`user_id`, `hotel_id`, `arrival_date`, `departure_date`, `number_adults`, `number_children`, `id_room_type`, `id_food_type`) VALUES ('149', '29', '1977-09-13', '2009-11-18', 2, 5, '6', '2');
INSERT INTO `hotel_reservations` (`user_id`, `hotel_id`, `arrival_date`, `departure_date`, `number_adults`, `number_children`, `id_room_type`, `id_food_type`) VALUES ('150', '30', '2003-05-27', '2011-01-15', 2, 8, '1', '6');
INSERT INTO `hotel_reservations` (`user_id`, `hotel_id`, `arrival_date`, `departure_date`, `number_adults`, `number_children`, `id_room_type`, `id_food_type`) VALUES ('151', '31', '2011-08-04', '2000-02-27', 4, 7, '3', '4');
INSERT INTO `hotel_reservations` (`user_id`, `hotel_id`, `arrival_date`, `departure_date`, `number_adults`, `number_children`, `id_room_type`, `id_food_type`) VALUES ('152', '32', '1994-02-26', '2014-03-17', 1, 3, '9', '9');
INSERT INTO `hotel_reservations` (`user_id`, `hotel_id`, `arrival_date`, `departure_date`, `number_adults`, `number_children`, `id_room_type`, `id_food_type`) VALUES ('153', '33', '1972-02-12', '1972-12-12', 2, 3, '4', '5');
INSERT INTO `hotel_reservations` (`user_id`, `hotel_id`, `arrival_date`, `departure_date`, `number_adults`, `number_children`, `id_room_type`, `id_food_type`) VALUES ('154', '34', '1971-11-23', '2014-11-07', 5, 4, '2', '7');
INSERT INTO `hotel_reservations` (`user_id`, `hotel_id`, `arrival_date`, `departure_date`, `number_adults`, `number_children`, `id_room_type`, `id_food_type`) VALUES ('155', '35', '1983-02-13', '1997-01-26', 4, 4, '3', '2');
INSERT INTO `hotel_reservations` (`user_id`, `hotel_id`, `arrival_date`, `departure_date`, `number_adults`, `number_children`, `id_room_type`, `id_food_type`) VALUES ('157', '36', '2019-01-27', '1986-10-04', 2, 3, '4', '9');
INSERT INTO `hotel_reservations` (`user_id`, `hotel_id`, `arrival_date`, `departure_date`, `number_adults`, `number_children`, `id_room_type`, `id_food_type`) VALUES ('159', '37', '1983-03-06', '1994-07-11', 3, 9, '8', '9');
INSERT INTO `hotel_reservations` (`user_id`, `hotel_id`, `arrival_date`, `departure_date`, `number_adults`, `number_children`, `id_room_type`, `id_food_type`) VALUES ('160', '38', '1986-07-23', '2000-04-27', 3, 3, '4', '3');
INSERT INTO `hotel_reservations` (`user_id`, `hotel_id`, `arrival_date`, `departure_date`, `number_adults`, `number_children`, `id_room_type`, `id_food_type`) VALUES ('161', '39', '1972-07-25', '2006-10-16', 9, 6, '9', '1');
INSERT INTO `hotel_reservations` (`user_id`, `hotel_id`, `arrival_date`, `departure_date`, `number_adults`, `number_children`, `id_room_type`, `id_food_type`) VALUES ('165', '40', '1987-02-12', '1993-04-08', 5, 2, '3', '8');
INSERT INTO `hotel_reservations` (`user_id`, `hotel_id`, `arrival_date`, `departure_date`, `number_adults`, `number_children`, `id_room_type`, `id_food_type`) VALUES ('168', '41', '2014-01-28', '2017-07-28', 8, 5, '8', '6');
INSERT INTO `hotel_reservations` (`user_id`, `hotel_id`, `arrival_date`, `departure_date`, `number_adults`, `number_children`, `id_room_type`, `id_food_type`) VALUES ('170', '42', '2014-12-23', '1978-02-08', 3, 6, '7', '7');
INSERT INTO `hotel_reservations` (`user_id`, `hotel_id`, `arrival_date`, `departure_date`, `number_adults`, `number_children`, `id_room_type`, `id_food_type`) VALUES ('172', '43', '2013-05-03', '2010-04-27', 4, 4, '5', '7');
INSERT INTO `hotel_reservations` (`user_id`, `hotel_id`, `arrival_date`, `departure_date`, `number_adults`, `number_children`, `id_room_type`, `id_food_type`) VALUES ('173', '44', '1991-06-09', '2013-09-06', 9, 8, '1', '5');
INSERT INTO `hotel_reservations` (`user_id`, `hotel_id`, `arrival_date`, `departure_date`, `number_adults`, `number_children`, `id_room_type`, `id_food_type`) VALUES ('175', '45', '1978-07-30', '2009-11-21', 9, 8, '3', '5');
INSERT INTO `hotel_reservations` (`user_id`, `hotel_id`, `arrival_date`, `departure_date`, `number_adults`, `number_children`, `id_room_type`, `id_food_type`) VALUES ('176', '46', '2007-11-11', '1974-12-03', 1, 2, '1', '2');
INSERT INTO `hotel_reservations` (`user_id`, `hotel_id`, `arrival_date`, `departure_date`, `number_adults`, `number_children`, `id_room_type`, `id_food_type`) VALUES ('177', '47', '1987-07-11', '1985-02-10', 6, 7, '4', '1');
INSERT INTO `hotel_reservations` (`user_id`, `hotel_id`, `arrival_date`, `departure_date`, `number_adults`, `number_children`, `id_room_type`, `id_food_type`) VALUES ('179', '48', '1982-05-22', '1970-03-19', 9, 6, '4', '2');
INSERT INTO `hotel_reservations` (`user_id`, `hotel_id`, `arrival_date`, `departure_date`, `number_adults`, `number_children`, `id_room_type`, `id_food_type`) VALUES ('181', '49', '1989-09-09', '1995-09-27', 8, 8, '8', '5');
INSERT INTO `hotel_reservations` (`user_id`, `hotel_id`, `arrival_date`, `departure_date`, `number_adults`, `number_children`, `id_room_type`, `id_food_type`) VALUES ('182', '50', '1986-05-03', '2004-06-29', 2, 4, '4', '5');
INSERT INTO `hotel_reservations` (`user_id`, `hotel_id`, `arrival_date`, `departure_date`, `number_adults`, `number_children`, `id_room_type`, `id_food_type`) VALUES ('183', '51', '2000-02-25', '2016-12-16', 2, 5, '1', '3');
INSERT INTO `hotel_reservations` (`user_id`, `hotel_id`, `arrival_date`, `departure_date`, `number_adults`, `number_children`, `id_room_type`, `id_food_type`) VALUES ('184', '52', '2018-08-16', '2015-04-07', 1, 5, '8', '7');
INSERT INTO `hotel_reservations` (`user_id`, `hotel_id`, `arrival_date`, `departure_date`, `number_adults`, `number_children`, `id_room_type`, `id_food_type`) VALUES ('187', '53', '1986-03-28', '1974-10-20', 7, 1, '5', '7');
INSERT INTO `hotel_reservations` (`user_id`, `hotel_id`, `arrival_date`, `departure_date`, `number_adults`, `number_children`, `id_room_type`, `id_food_type`) VALUES ('188', '54', '1985-06-25', '1977-04-10', 5, 9, '4', '3');
INSERT INTO `hotel_reservations` (`user_id`, `hotel_id`, `arrival_date`, `departure_date`, `number_adults`, `number_children`, `id_room_type`, `id_food_type`) VALUES ('189', '55', '1980-11-08', '1986-12-17', 4, 3, '1', '6');
INSERT INTO `hotel_reservations` (`user_id`, `hotel_id`, `arrival_date`, `departure_date`, `number_adults`, `number_children`, `id_room_type`, `id_food_type`) VALUES ('191', '56', '1970-03-15', '1987-12-24', 5, 3, '6', '4');
INSERT INTO `hotel_reservations` (`user_id`, `hotel_id`, `arrival_date`, `departure_date`, `number_adults`, `number_children`, `id_room_type`, `id_food_type`) VALUES ('193', '57', '2008-09-05', '1996-02-14', 5, 5, '9', '6');
INSERT INTO `hotel_reservations` (`user_id`, `hotel_id`, `arrival_date`, `departure_date`, `number_adults`, `number_children`, `id_room_type`, `id_food_type`) VALUES ('194', '58', '2008-11-26', '2007-12-31', 1, 9, '9', '5');
INSERT INTO `hotel_reservations` (`user_id`, `hotel_id`, `arrival_date`, `departure_date`, `number_adults`, `number_children`, `id_room_type`, `id_food_type`) VALUES ('195', '59', '1998-03-23', '2014-05-28', 9, 5, '1', '1');
INSERT INTO `hotel_reservations` (`user_id`, `hotel_id`, `arrival_date`, `departure_date`, `number_adults`, `number_children`, `id_room_type`, `id_food_type`) VALUES ('196', '60', '2020-04-27', '2001-05-04', 6, 1, '2', '3');
INSERT INTO `hotel_reservations` (`user_id`, `hotel_id`, `arrival_date`, `departure_date`, `number_adults`, `number_children`, `id_room_type`, `id_food_type`) VALUES ('198', '61', '2003-03-05', '2005-05-12', 8, 7, '8', '4');
INSERT INTO `hotel_reservations` (`user_id`, `hotel_id`, `arrival_date`, `departure_date`, `number_adults`, `number_children`, `id_room_type`, `id_food_type`) VALUES ('199', '62', '2016-04-25', '2016-04-03', 8, 8, '4', '4');
INSERT INTO `hotel_reservations` (`user_id`, `hotel_id`, `arrival_date`, `departure_date`, `number_adults`, `number_children`, `id_room_type`, `id_food_type`) VALUES ('101', '63', '1982-12-05', '1981-03-25', 4, 4, '2', '2');
INSERT INTO `hotel_reservations` (`user_id`, `hotel_id`, `arrival_date`, `departure_date`, `number_adults`, `number_children`, `id_room_type`, `id_food_type`) VALUES ('102', '64', '1978-03-14', '1972-12-27', 4, 3, '4', '2');
INSERT INTO `hotel_reservations` (`user_id`, `hotel_id`, `arrival_date`, `departure_date`, `number_adults`, `number_children`, `id_room_type`, `id_food_type`) VALUES ('103', '65', '1985-11-23', '1977-12-09', 2, 6, '1', '9');
INSERT INTO `hotel_reservations` (`user_id`, `hotel_id`, `arrival_date`, `departure_date`, `number_adults`, `number_children`, `id_room_type`, `id_food_type`) VALUES ('104', '66', '1992-11-16', '2010-07-18', 4, 9, '3', '4');
INSERT INTO `hotel_reservations` (`user_id`, `hotel_id`, `arrival_date`, `departure_date`, `number_adults`, `number_children`, `id_room_type`, `id_food_type`) VALUES ('105', '67', '2006-05-16', '2002-03-21', 8, 3, '3', '8');
INSERT INTO `hotel_reservations` (`user_id`, `hotel_id`, `arrival_date`, `departure_date`, `number_adults`, `number_children`, `id_room_type`, `id_food_type`) VALUES ('106', '68', '1993-04-20', '1975-11-02', 8, 7, '1', '7');
INSERT INTO `hotel_reservations` (`user_id`, `hotel_id`, `arrival_date`, `departure_date`, `number_adults`, `number_children`, `id_room_type`, `id_food_type`) VALUES ('107', '69', '2007-04-19', '2017-08-25', 4, 6, '5', '3');
INSERT INTO `hotel_reservations` (`user_id`, `hotel_id`, `arrival_date`, `departure_date`, `number_adults`, `number_children`, `id_room_type`, `id_food_type`) VALUES ('108', '70', '2019-10-30', '1981-10-14', 9, 4, '9', '7');
INSERT INTO `hotel_reservations` (`user_id`, `hotel_id`, `arrival_date`, `departure_date`, `number_adults`, `number_children`, `id_room_type`, `id_food_type`) VALUES ('109', '71', '2003-07-14', '2000-01-20', 8, 5, '9', '1');
INSERT INTO `hotel_reservations` (`user_id`, `hotel_id`, `arrival_date`, `departure_date`, `number_adults`, `number_children`, `id_room_type`, `id_food_type`) VALUES ('110', '72', '2016-07-08', '1971-08-01', 7, 3, '3', '4');
INSERT INTO `hotel_reservations` (`user_id`, `hotel_id`, `arrival_date`, `departure_date`, `number_adults`, `number_children`, `id_room_type`, `id_food_type`) VALUES ('112', '73', '2010-03-31', '1997-08-09', 4, 1, '1', '2');
INSERT INTO `hotel_reservations` (`user_id`, `hotel_id`, `arrival_date`, `departure_date`, `number_adults`, `number_children`, `id_room_type`, `id_food_type`) VALUES ('114', '74', '2004-07-21', '1975-05-28', 5, 9, '5', '2');
INSERT INTO `hotel_reservations` (`user_id`, `hotel_id`, `arrival_date`, `departure_date`, `number_adults`, `number_children`, `id_room_type`, `id_food_type`) VALUES ('115', '75', '2012-02-02', '1986-02-15', 4, 9, '8', '8');
INSERT INTO `hotel_reservations` (`user_id`, `hotel_id`, `arrival_date`, `departure_date`, `number_adults`, `number_children`, `id_room_type`, `id_food_type`) VALUES ('116', '76', '1981-08-01', '2008-06-19', 2, 9, '4', '3');
INSERT INTO `hotel_reservations` (`user_id`, `hotel_id`, `arrival_date`, `departure_date`, `number_adults`, `number_children`, `id_room_type`, `id_food_type`) VALUES ('118', '77', '2011-04-02', '1997-09-10', 4, 2, '6', '1');
INSERT INTO `hotel_reservations` (`user_id`, `hotel_id`, `arrival_date`, `departure_date`, `number_adults`, `number_children`, `id_room_type`, `id_food_type`) VALUES ('120', '78', '1995-09-09', '2004-12-22', 6, 3, '2', '2');
INSERT INTO `hotel_reservations` (`user_id`, `hotel_id`, `arrival_date`, `departure_date`, `number_adults`, `number_children`, `id_room_type`, `id_food_type`) VALUES ('124', '79', '1999-02-14', '2001-12-20', 4, 1, '7', '9');
INSERT INTO `hotel_reservations` (`user_id`, `hotel_id`, `arrival_date`, `departure_date`, `number_adults`, `number_children`, `id_room_type`, `id_food_type`) VALUES ('126', '80', '1976-11-17', '1995-08-27', 8, 9, '3', '2');
INSERT INTO `hotel_reservations` (`user_id`, `hotel_id`, `arrival_date`, `departure_date`, `number_adults`, `number_children`, `id_room_type`, `id_food_type`) VALUES ('127', '81', '1982-10-25', '2008-03-03', 1, 1, '9', '5');
INSERT INTO `hotel_reservations` (`user_id`, `hotel_id`, `arrival_date`, `departure_date`, `number_adults`, `number_children`, `id_room_type`, `id_food_type`) VALUES ('128', '82', '1971-07-18', '1972-04-18', 5, 4, '3', '9');
INSERT INTO `hotel_reservations` (`user_id`, `hotel_id`, `arrival_date`, `departure_date`, `number_adults`, `number_children`, `id_room_type`, `id_food_type`) VALUES ('134', '83', '2016-11-08', '1996-03-12', 1, 4, '7', '6');
INSERT INTO `hotel_reservations` (`user_id`, `hotel_id`, `arrival_date`, `departure_date`, `number_adults`, `number_children`, `id_room_type`, `id_food_type`) VALUES ('137', '84', '1983-03-12', '1974-05-29', 4, 4, '9', '6');
INSERT INTO `hotel_reservations` (`user_id`, `hotel_id`, `arrival_date`, `departure_date`, `number_adults`, `number_children`, `id_room_type`, `id_food_type`) VALUES ('138', '85', '1972-05-22', '1992-07-12', 9, 9, '8', '2');
INSERT INTO `hotel_reservations` (`user_id`, `hotel_id`, `arrival_date`, `departure_date`, `number_adults`, `number_children`, `id_room_type`, `id_food_type`) VALUES ('140', '86', '1995-09-07', '1980-08-15', 5, 8, '5', '2');
INSERT INTO `hotel_reservations` (`user_id`, `hotel_id`, `arrival_date`, `departure_date`, `number_adults`, `number_children`, `id_room_type`, `id_food_type`) VALUES ('145', '87', '1995-09-12', '2005-03-27', 3, 2, '2', '1');
INSERT INTO `hotel_reservations` (`user_id`, `hotel_id`, `arrival_date`, `departure_date`, `number_adults`, `number_children`, `id_room_type`, `id_food_type`) VALUES ('146', '88', '2019-10-24', '2002-02-17', 6, 8, '6', '7');
INSERT INTO `hotel_reservations` (`user_id`, `hotel_id`, `arrival_date`, `departure_date`, `number_adults`, `number_children`, `id_room_type`, `id_food_type`) VALUES ('147', '89', '2009-06-06', '1998-02-23', 5, 7, '3', '1');
INSERT INTO `hotel_reservations` (`user_id`, `hotel_id`, `arrival_date`, `departure_date`, `number_adults`, `number_children`, `id_room_type`, `id_food_type`) VALUES ('148', '90', '1999-01-11', '2003-07-07', 5, 4, '7', '5');
INSERT INTO `hotel_reservations` (`user_id`, `hotel_id`, `arrival_date`, `departure_date`, `number_adults`, `number_children`, `id_room_type`, `id_food_type`) VALUES ('149', '91', '2009-09-07', '1991-10-13', 4, 6, '6', '9');
INSERT INTO `hotel_reservations` (`user_id`, `hotel_id`, `arrival_date`, `departure_date`, `number_adults`, `number_children`, `id_room_type`, `id_food_type`) VALUES ('150', '92', '1992-08-17', '1999-06-14', 5, 1, '3', '9');
INSERT INTO `hotel_reservations` (`user_id`, `hotel_id`, `arrival_date`, `departure_date`, `number_adults`, `number_children`, `id_room_type`, `id_food_type`) VALUES ('151', '93', '2006-07-04', '1995-04-11', 7, 2, '1', '2');
INSERT INTO `hotel_reservations` (`user_id`, `hotel_id`, `arrival_date`, `departure_date`, `number_adults`, `number_children`, `id_room_type`, `id_food_type`) VALUES ('152', '94', '1994-06-26', '2002-10-31', 3, 3, '4', '5');
INSERT INTO `hotel_reservations` (`user_id`, `hotel_id`, `arrival_date`, `departure_date`, `number_adults`, `number_children`, `id_room_type`, `id_food_type`) VALUES ('153', '95', '1988-01-28', '1981-04-16', 3, 4, '4', '5');
INSERT INTO `hotel_reservations` (`user_id`, `hotel_id`, `arrival_date`, `departure_date`, `number_adults`, `number_children`, `id_room_type`, `id_food_type`) VALUES ('154', '96', '1992-06-05', '1990-04-19', 8, 6, '6', '7');
INSERT INTO `hotel_reservations` (`user_id`, `hotel_id`, `arrival_date`, `departure_date`, `number_adults`, `number_children`, `id_room_type`, `id_food_type`) VALUES ('155', '97', '2012-02-07', '1971-10-19', 4, 6, '8', '4');
INSERT INTO `hotel_reservations` (`user_id`, `hotel_id`, `arrival_date`, `departure_date`, `number_adults`, `number_children`, `id_room_type`, `id_food_type`) VALUES ('157', '98', '2014-02-01', '2016-05-09', 5, 1, '1', '7');
INSERT INTO `hotel_reservations` (`user_id`, `hotel_id`, `arrival_date`, `departure_date`, `number_adults`, `number_children`, `id_room_type`, `id_food_type`) VALUES ('159', '99', '1992-05-05', '1984-09-12', 2, 3, '8', '9');
INSERT INTO `hotel_reservations` (`user_id`, `hotel_id`, `arrival_date`, `departure_date`, `number_adults`, `number_children`, `id_room_type`, `id_food_type`) VALUES ('160', '100', '1973-04-15', '1979-07-03', 1, 9, '7', '5');


#
# TABLE STRUCTURE FOR: hotel_review
#

DROP TABLE IF EXISTS `hotel_review`;

CREATE TABLE `hotel_review` (
  `id` bigint(20) unsigned NOT NULL,
  `from_user_id` bigint(20) unsigned DEFAULT NULL,
  `to_hotel_id` bigint(20) unsigned DEFAULT NULL,
  `body` text COLLATE utf8_unicode_ci DEFAULT NULL,
  `created_at` datetime DEFAULT current_timestamp(),
  KEY `from_user_id` (`from_user_id`),
  KEY `to_hotel_id` (`to_hotel_id`),
  CONSTRAINT `hotel_review_ibfk_1` FOREIGN KEY (`from_user_id`) REFERENCES `users` (`id`),
  CONSTRAINT `hotel_review_ibfk_2` FOREIGN KEY (`to_hotel_id`) REFERENCES `hotels` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

INSERT INTO `hotel_review` (`id`, `from_user_id`, `to_hotel_id`, `body`, `created_at`) VALUES ('1', '101', '1', 'Laborum sit optio ea magnam et rerum vitae. Aperiam eum ut blanditiis corrupti adipisci quo dolorem. Eius non error mollitia quisquam. Necessitatibus fuga modi qui provident. Inventore enim numquam eveniet voluptatum.', '1973-01-19 08:41:16');
INSERT INTO `hotel_review` (`id`, `from_user_id`, `to_hotel_id`, `body`, `created_at`) VALUES ('2', '102', '2', 'Rem consequatur expedita omnis quod. Velit ad sapiente molestias pariatur officia. Ea dolor praesentium esse sunt accusantium explicabo exercitationem. Accusamus error fuga doloribus est quidem ut cum molestiae.', '1990-07-15 22:09:11');
INSERT INTO `hotel_review` (`id`, `from_user_id`, `to_hotel_id`, `body`, `created_at`) VALUES ('3', '103', '3', 'Nihil sit voluptas nam et nulla. Soluta impedit et voluptas delectus omnis neque. Impedit non assumenda harum et.', '1982-12-24 14:02:19');
INSERT INTO `hotel_review` (`id`, `from_user_id`, `to_hotel_id`, `body`, `created_at`) VALUES ('4', '104', '4', 'Reprehenderit laboriosam nesciunt qui error veniam et. Quisquam facere amet delectus repellat nesciunt. Qui soluta sequi id non amet minima.', '1974-12-09 14:04:55');
INSERT INTO `hotel_review` (`id`, `from_user_id`, `to_hotel_id`, `body`, `created_at`) VALUES ('5', '105', '5', 'Mollitia odio quae reprehenderit eius voluptatem in. Nemo aliquam voluptatem velit ut quas sunt non consequuntur. Laborum unde voluptatem dolores corrupti. Voluptatem est voluptatem illum et voluptatum sit qui.', '2016-09-04 19:52:30');
INSERT INTO `hotel_review` (`id`, `from_user_id`, `to_hotel_id`, `body`, `created_at`) VALUES ('6', '106', '6', 'Repellat consequuntur placeat illo ea tempora neque quisquam. Nihil nihil accusamus exercitationem iusto eligendi recusandae sit. Incidunt quod nemo laborum quae voluptatem dolorem. Quidem non corporis et reprehenderit qui. Ut ab sint ut vel facere voluptas.', '1989-12-15 04:21:40');
INSERT INTO `hotel_review` (`id`, `from_user_id`, `to_hotel_id`, `body`, `created_at`) VALUES ('7', '107', '7', 'Beatae ducimus laboriosam qui omnis saepe id eum. Id beatae molestiae ipsum sit ullam perspiciatis. Et sed laboriosam maxime voluptas distinctio. Reiciendis deleniti ut corporis possimus corrupti molestias sit. Officia odio sed in aperiam quasi.', '2002-10-12 20:56:11');
INSERT INTO `hotel_review` (`id`, `from_user_id`, `to_hotel_id`, `body`, `created_at`) VALUES ('8', '108', '8', 'Quas qui facere ut consequatur. Qui itaque qui non necessitatibus facere excepturi totam consequatur. Labore enim possimus omnis eum ipsa facilis est.', '1990-05-18 03:39:15');
INSERT INTO `hotel_review` (`id`, `from_user_id`, `to_hotel_id`, `body`, `created_at`) VALUES ('9', '109', '9', 'Sed aspernatur quaerat dolore eum quae aliquam sunt. Esse sit laudantium laudantium laboriosam natus. Deserunt neque facere quae et temporibus veniam.', '2019-07-15 06:47:30');
INSERT INTO `hotel_review` (`id`, `from_user_id`, `to_hotel_id`, `body`, `created_at`) VALUES ('10', '110', '10', 'Minima rem reiciendis aut asperiores ipsam quia voluptatem. Earum ut aspernatur ut voluptatem ad aperiam ab. Esse quia ipsa explicabo aliquid vitae repellendus et. Architecto quaerat atque tempore labore et.', '2000-02-10 19:14:10');
INSERT INTO `hotel_review` (`id`, `from_user_id`, `to_hotel_id`, `body`, `created_at`) VALUES ('11', '112', '11', 'Saepe quae tenetur excepturi consequatur sit enim. Eum officiis error maiores dicta quia. Perferendis laborum tenetur distinctio. Modi consequuntur quia maxime vero odit eligendi consequuntur nulla.', '1977-11-22 16:49:09');
INSERT INTO `hotel_review` (`id`, `from_user_id`, `to_hotel_id`, `body`, `created_at`) VALUES ('12', '114', '12', 'Sit aut id consequatur ut aut harum rerum voluptatum. Quia reiciendis distinctio dolores vitae quia. Laudantium voluptatibus ut deleniti voluptates. Temporibus labore ducimus mollitia eius unde.', '2004-11-14 21:02:40');
INSERT INTO `hotel_review` (`id`, `from_user_id`, `to_hotel_id`, `body`, `created_at`) VALUES ('13', '115', '13', 'Magnam est et nobis velit aut. Reprehenderit veritatis dolore accusantium dolores laudantium laborum. Impedit sunt rerum modi. Autem quae dolor dolores labore.', '2017-09-10 05:18:30');
INSERT INTO `hotel_review` (`id`, `from_user_id`, `to_hotel_id`, `body`, `created_at`) VALUES ('14', '116', '14', 'Sunt qui ab officia et impedit ut aliquid. Temporibus minus rerum commodi molestiae numquam. Nihil labore voluptatem atque et laboriosam. Aliquam excepturi est quia culpa.', '2002-07-21 14:15:12');
INSERT INTO `hotel_review` (`id`, `from_user_id`, `to_hotel_id`, `body`, `created_at`) VALUES ('15', '118', '15', 'Aut enim quia nobis ad ut autem. Officiis autem repellat consectetur laudantium ea qui ex eos. Harum dolor omnis iusto eos magni. Nobis exercitationem velit architecto.', '1988-10-14 13:01:50');
INSERT INTO `hotel_review` (`id`, `from_user_id`, `to_hotel_id`, `body`, `created_at`) VALUES ('16', '120', '16', 'Distinctio officia sequi dolorem qui. Repellendus necessitatibus fugiat voluptatem voluptatem minus.', '1993-05-27 04:47:17');
INSERT INTO `hotel_review` (`id`, `from_user_id`, `to_hotel_id`, `body`, `created_at`) VALUES ('17', '124', '17', 'Esse cum veniam hic placeat. Sint labore dicta pariatur aut libero dolor non. Rerum quis quaerat eaque doloribus enim optio. Libero aliquam deleniti autem ut in cumque sed.', '1996-12-30 22:43:53');
INSERT INTO `hotel_review` (`id`, `from_user_id`, `to_hotel_id`, `body`, `created_at`) VALUES ('18', '126', '18', 'Dolorem consectetur doloribus et velit et nemo. Enim placeat ut sint minus deleniti ratione ut. Ut fugit porro sequi qui velit magni quia est. Qui est et eos consequatur sapiente laborum.', '1976-10-22 15:12:43');
INSERT INTO `hotel_review` (`id`, `from_user_id`, `to_hotel_id`, `body`, `created_at`) VALUES ('19', '127', '19', 'Alias qui soluta in aut adipisci ea vel. Veniam animi illo velit et quibusdam vitae facilis.', '1997-01-06 19:46:45');
INSERT INTO `hotel_review` (`id`, `from_user_id`, `to_hotel_id`, `body`, `created_at`) VALUES ('20', '128', '20', 'Molestias velit non asperiores excepturi cumque aliquid qui quis. Iusto perspiciatis quasi culpa incidunt consequatur. Eaque inventore ipsum quia quia. Ducimus qui aut delectus in voluptate quae.', '2009-12-25 03:44:52');
INSERT INTO `hotel_review` (`id`, `from_user_id`, `to_hotel_id`, `body`, `created_at`) VALUES ('21', '134', '21', 'Saepe ducimus et quo dicta. Laudantium suscipit consectetur at reiciendis amet nisi. In consequatur rem et ut consequatur non.', '2019-06-06 05:25:18');
INSERT INTO `hotel_review` (`id`, `from_user_id`, `to_hotel_id`, `body`, `created_at`) VALUES ('22', '137', '22', 'Qui non nam eligendi ipsum quae est. Rerum recusandae vel fugit ea et qui iste. Excepturi id labore nostrum eum quia corporis reprehenderit veniam. Odit rerum ratione recusandae id.', '1993-01-10 17:24:23');
INSERT INTO `hotel_review` (`id`, `from_user_id`, `to_hotel_id`, `body`, `created_at`) VALUES ('23', '138', '23', 'Quo totam incidunt cum. Blanditiis est eos repellat qui et. Amet quo sed rerum ad vero et consequuntur nesciunt.', '2002-05-25 21:23:44');
INSERT INTO `hotel_review` (`id`, `from_user_id`, `to_hotel_id`, `body`, `created_at`) VALUES ('24', '140', '24', 'Enim a amet veritatis labore. Est dolorem itaque libero qui facilis aut quae.', '2003-04-22 20:09:44');
INSERT INTO `hotel_review` (`id`, `from_user_id`, `to_hotel_id`, `body`, `created_at`) VALUES ('25', '145', '25', 'Tenetur expedita nobis eum. Praesentium rerum praesentium nam est debitis qui. Cum sint aliquam aut tenetur culpa dolorem inventore.', '1991-06-19 16:08:42');
INSERT INTO `hotel_review` (`id`, `from_user_id`, `to_hotel_id`, `body`, `created_at`) VALUES ('26', '146', '26', 'Sed voluptatem eligendi molestias repellendus incidunt placeat. Atque accusamus rerum quidem non dolorem nam. Ut exercitationem in architecto. Eveniet debitis rerum ut nostrum sit. Est earum sit iste maiores possimus adipisci impedit ipsum.', '2008-01-28 22:30:51');
INSERT INTO `hotel_review` (`id`, `from_user_id`, `to_hotel_id`, `body`, `created_at`) VALUES ('0', '147', '27', 'Accusamus voluptas in libero. Velit odio eaque commodi voluptatem dolore dolor fugit. Similique repellendus laborum quisquam dolorem ut dolor.', '1982-09-21 05:49:28');
INSERT INTO `hotel_review` (`id`, `from_user_id`, `to_hotel_id`, `body`, `created_at`) VALUES ('0', '148', '28', 'Eligendi molestiae ut est eum et laboriosam cupiditate. Consequatur error impedit eos voluptatem nemo. Autem commodi magnam eveniet beatae quidem perferendis nihil. Ad provident porro doloremque vero ipsa qui et sunt.', '1986-01-17 08:24:52');
INSERT INTO `hotel_review` (`id`, `from_user_id`, `to_hotel_id`, `body`, `created_at`) VALUES ('0', '149', '29', 'Et odit sit natus. Sapiente commodi in repudiandae explicabo enim dolore. Neque facere laborum harum rerum qui labore in. Voluptatibus et et commodi asperiores sapiente.', '1970-11-16 09:31:35');
INSERT INTO `hotel_review` (`id`, `from_user_id`, `to_hotel_id`, `body`, `created_at`) VALUES ('0', '150', '30', 'Accusantium eveniet nisi est hic. Quis minima fuga quidem quia cupiditate eos. Enim veniam minus molestiae autem vitae nesciunt. Nesciunt mollitia quis ad illum sit perferendis. Aperiam officia numquam aliquam.', '1975-11-15 07:18:46');
INSERT INTO `hotel_review` (`id`, `from_user_id`, `to_hotel_id`, `body`, `created_at`) VALUES ('0', '151', '31', 'Non sequi eius incidunt vitae. Minima aut blanditiis aliquid dolores.', '1979-05-13 22:01:56');
INSERT INTO `hotel_review` (`id`, `from_user_id`, `to_hotel_id`, `body`, `created_at`) VALUES ('0', '152', '32', 'Deserunt culpa aliquam non molestiae. Consequuntur delectus debitis praesentium quaerat quas neque. Consequatur asperiores maiores exercitationem molestiae.', '2000-04-27 22:37:00');
INSERT INTO `hotel_review` (`id`, `from_user_id`, `to_hotel_id`, `body`, `created_at`) VALUES ('0', '153', '33', 'Necessitatibus laborum itaque aspernatur esse voluptatem. Neque sequi sit voluptates sit sapiente dolores. In est est voluptatem voluptas. Vel deserunt nemo consequatur nihil tempore eius molestiae beatae.', '2008-03-25 20:28:27');
INSERT INTO `hotel_review` (`id`, `from_user_id`, `to_hotel_id`, `body`, `created_at`) VALUES ('0', '154', '34', 'Iure aut voluptatem perferendis suscipit. Deserunt nulla a repellendus excepturi earum qui unde aspernatur. Dicta iusto enim sunt facere sit quidem. Voluptatem et aut odio non dolor odit.', '2001-06-20 17:39:18');
INSERT INTO `hotel_review` (`id`, `from_user_id`, `to_hotel_id`, `body`, `created_at`) VALUES ('0', '155', '35', 'Et eius ut quasi quisquam. Molestiae hic quam alias consequuntur consequuntur ex. Consequatur ipsa commodi nemo maiores officiis.', '1977-07-14 07:20:50');
INSERT INTO `hotel_review` (`id`, `from_user_id`, `to_hotel_id`, `body`, `created_at`) VALUES ('0', '157', '36', 'Tempore quam fugiat et inventore assumenda consequatur. Qui quis dolorum qui saepe omnis nesciunt. Quas cupiditate pariatur vitae consequatur necessitatibus quia ipsam quia.', '1999-02-19 10:57:45');
INSERT INTO `hotel_review` (`id`, `from_user_id`, `to_hotel_id`, `body`, `created_at`) VALUES ('0', '159', '37', 'Aut provident possimus et consequatur est iure. Commodi enim laboriosam distinctio debitis quos laborum. Consequuntur delectus nostrum iusto distinctio.', '2004-01-27 23:02:55');
INSERT INTO `hotel_review` (`id`, `from_user_id`, `to_hotel_id`, `body`, `created_at`) VALUES ('0', '160', '38', 'Ad eius delectus ipsam quis. Et est aperiam et et dolore. Dolorum sunt magni accusamus.', '1998-10-21 15:42:39');
INSERT INTO `hotel_review` (`id`, `from_user_id`, `to_hotel_id`, `body`, `created_at`) VALUES ('0', '161', '39', 'In veniam recusandae magni unde laudantium. Placeat vel officiis perspiciatis recusandae ea et cum nisi. Totam autem et ullam nihil consequatur illo ad. Eveniet dolorem quod illum commodi totam hic quam.', '2010-01-09 14:49:10');
INSERT INTO `hotel_review` (`id`, `from_user_id`, `to_hotel_id`, `body`, `created_at`) VALUES ('0', '165', '40', 'Commodi voluptate eum earum eos eligendi in labore. Voluptas placeat quia error nihil culpa est. Aut repellat labore sint expedita.', '2016-01-04 05:36:54');
INSERT INTO `hotel_review` (`id`, `from_user_id`, `to_hotel_id`, `body`, `created_at`) VALUES ('0', '168', '41', 'Accusantium quibusdam minus quo dolorem. Debitis a laboriosam aut at. Sunt rem quia corrupti est molestias et nisi ea. Repellat inventore et aut consequatur.', '1988-11-18 03:39:55');
INSERT INTO `hotel_review` (`id`, `from_user_id`, `to_hotel_id`, `body`, `created_at`) VALUES ('0', '170', '42', 'Expedita hic sit iure eius saepe mollitia consequatur. Pariatur illum non animi quaerat eum autem. Vero voluptatem explicabo ut nisi blanditiis aut non quam.', '1976-04-26 14:40:22');
INSERT INTO `hotel_review` (`id`, `from_user_id`, `to_hotel_id`, `body`, `created_at`) VALUES ('0', '172', '43', 'Voluptatum incidunt aliquam quasi fugiat aut. In aut odit iusto corporis. Sint quod consequatur a a eum aperiam sit. Qui praesentium quasi provident aliquid eaque soluta facere consequatur.', '1992-05-20 06:33:02');
INSERT INTO `hotel_review` (`id`, `from_user_id`, `to_hotel_id`, `body`, `created_at`) VALUES ('0', '173', '44', 'Deleniti aut quaerat voluptate. Voluptates id accusantium sed. Doloribus molestiae rerum est velit. Illo quae non veritatis fugit ad aspernatur.', '1986-10-11 04:55:20');
INSERT INTO `hotel_review` (`id`, `from_user_id`, `to_hotel_id`, `body`, `created_at`) VALUES ('0', '175', '45', 'Dolores accusamus eos at nisi temporibus cumque autem. Qui ipsam commodi ullam enim voluptates dolores autem aut. Est expedita voluptas blanditiis ea. Eligendi omnis ipsum molestiae enim.', '1996-05-04 09:24:01');
INSERT INTO `hotel_review` (`id`, `from_user_id`, `to_hotel_id`, `body`, `created_at`) VALUES ('0', '176', '46', 'Consequatur et quis eius. Eum atque velit recusandae exercitationem aliquam itaque. Omnis veniam molestiae libero quia.', '2004-02-10 08:31:26');
INSERT INTO `hotel_review` (`id`, `from_user_id`, `to_hotel_id`, `body`, `created_at`) VALUES ('0', '177', '47', 'Natus sint rerum rerum iure. Eos fugit optio et ad. Rerum adipisci voluptas pariatur eos quisquam ea.', '2020-06-14 18:44:21');
INSERT INTO `hotel_review` (`id`, `from_user_id`, `to_hotel_id`, `body`, `created_at`) VALUES ('0', '179', '48', 'Totam amet laudantium totam quisquam reiciendis minus quam unde. Perspiciatis eligendi vel quo voluptas optio. Odit iste sit et veniam dolor. Quos quia dicta nam sed suscipit eum pariatur.', '2004-02-06 08:24:02');
INSERT INTO `hotel_review` (`id`, `from_user_id`, `to_hotel_id`, `body`, `created_at`) VALUES ('0', '181', '49', 'Commodi quae voluptatem autem culpa repellat qui aut totam. Repellat eum modi odit id provident nam quia. Odit nisi quis vero placeat tempore. Dignissimos non quidem quia et iure numquam nobis.', '1972-09-08 08:14:55');
INSERT INTO `hotel_review` (`id`, `from_user_id`, `to_hotel_id`, `body`, `created_at`) VALUES ('0', '182', '50', 'Ut est quas corrupti est alias. Architecto aut porro est asperiores dolor consequatur et. Voluptatibus quisquam reprehenderit ea voluptatem. Ut eum distinctio aut.', '1989-06-27 16:58:52');
INSERT INTO `hotel_review` (`id`, `from_user_id`, `to_hotel_id`, `body`, `created_at`) VALUES ('0', '183', '51', 'Cumque nisi quam maxime amet modi. Fugit at iste odio nemo expedita eum. Velit dolorem optio voluptas dolorum sit earum temporibus.', '1999-02-03 06:00:04');
INSERT INTO `hotel_review` (`id`, `from_user_id`, `to_hotel_id`, `body`, `created_at`) VALUES ('0', '184', '52', 'Recusandae voluptas eius quos sapiente et. Temporibus mollitia corporis adipisci consequuntur nihil voluptatem. Recusandae ut ea consequatur odit saepe adipisci. Voluptatem neque qui impedit eos hic.', '1970-06-24 18:09:17');
INSERT INTO `hotel_review` (`id`, `from_user_id`, `to_hotel_id`, `body`, `created_at`) VALUES ('0', '187', '53', 'Quidem consequatur aut a beatae. Eius quisquam rerum laborum veniam veniam. Sit et veritatis reiciendis ex.', '1979-02-01 13:16:58');
INSERT INTO `hotel_review` (`id`, `from_user_id`, `to_hotel_id`, `body`, `created_at`) VALUES ('0', '188', '54', 'Aut repudiandae reprehenderit temporibus cupiditate. Commodi quis aut ea odit atque et voluptatum.', '1981-10-14 02:37:16');
INSERT INTO `hotel_review` (`id`, `from_user_id`, `to_hotel_id`, `body`, `created_at`) VALUES ('0', '189', '55', 'Porro sit provident commodi illum nemo officia architecto. Ut vero iure quidem odit voluptas optio rerum. Aperiam commodi exercitationem ab cum quisquam voluptatem. Architecto ea ipsum et qui ab aut.', '1990-03-25 03:23:54');
INSERT INTO `hotel_review` (`id`, `from_user_id`, `to_hotel_id`, `body`, `created_at`) VALUES ('0', '191', '56', 'Architecto quas facere veniam vel. Illum atque et suscipit dolorem voluptas libero ducimus. Sit eum ut amet.', '1977-07-03 09:43:15');
INSERT INTO `hotel_review` (`id`, `from_user_id`, `to_hotel_id`, `body`, `created_at`) VALUES ('0', '193', '57', 'Ut rem rerum voluptatem autem ullam natus sed. Ut voluptatibus rerum sunt. Voluptatem et dolorem vel et aut tempora.', '2012-01-17 13:59:02');
INSERT INTO `hotel_review` (`id`, `from_user_id`, `to_hotel_id`, `body`, `created_at`) VALUES ('0', '194', '58', 'Impedit sit temporibus architecto vel similique distinctio est voluptatum. Aperiam possimus in molestiae aut nesciunt nihil vel. Maxime saepe eos natus aspernatur ex.', '2003-11-26 11:29:22');
INSERT INTO `hotel_review` (`id`, `from_user_id`, `to_hotel_id`, `body`, `created_at`) VALUES ('0', '195', '59', 'Et tenetur et dicta sequi hic libero facere. Modi dicta sed voluptatem inventore sint deserunt reiciendis et. Nobis libero suscipit voluptatem sed.', '2017-12-28 03:21:33');
INSERT INTO `hotel_review` (`id`, `from_user_id`, `to_hotel_id`, `body`, `created_at`) VALUES ('0', '196', '60', 'Sed blanditiis architecto labore maxime molestiae corporis occaecati error. Id voluptatibus veniam eveniet molestiae tenetur odit cum. Voluptate aut natus nobis magnam aut. Consequatur accusantium cum sed sint quo enim magnam.', '2018-09-21 13:31:54');
INSERT INTO `hotel_review` (`id`, `from_user_id`, `to_hotel_id`, `body`, `created_at`) VALUES ('0', '198', '61', 'Temporibus aliquam et voluptas perferendis eius ut laboriosam. Non quaerat et commodi rerum qui voluptatibus. Harum ut placeat consectetur ullam et.', '1986-07-31 20:01:10');
INSERT INTO `hotel_review` (`id`, `from_user_id`, `to_hotel_id`, `body`, `created_at`) VALUES ('0', '199', '62', 'Ratione laborum sunt minima nostrum alias mollitia. Perspiciatis molestias rem ut aut eveniet sit labore. Corrupti omnis iusto minima et autem illum.', '2011-04-03 17:03:14');
INSERT INTO `hotel_review` (`id`, `from_user_id`, `to_hotel_id`, `body`, `created_at`) VALUES ('0', '101', '63', 'Soluta temporibus pariatur ipsa qui veniam enim sunt dolore. Saepe soluta quia sit ut tenetur laborum sapiente. Odio et voluptatem deserunt. Deserunt rem dolorum aut.', '1990-03-16 03:00:00');
INSERT INTO `hotel_review` (`id`, `from_user_id`, `to_hotel_id`, `body`, `created_at`) VALUES ('0', '102', '64', 'Quod voluptatem aut eveniet fugit. Ea quis et ab libero. Fuga autem alias quia odit voluptatem laborum distinctio.', '1979-05-16 11:42:32');
INSERT INTO `hotel_review` (`id`, `from_user_id`, `to_hotel_id`, `body`, `created_at`) VALUES ('0', '103', '65', 'Repellat blanditiis aut commodi sint ea optio mollitia. Minima sit molestiae cupiditate officia dolorum magni. Consequatur natus excepturi voluptas ratione et. Libero accusamus sequi maiores ut aspernatur dignissimos.', '2010-04-13 23:49:51');
INSERT INTO `hotel_review` (`id`, `from_user_id`, `to_hotel_id`, `body`, `created_at`) VALUES ('0', '104', '66', 'Inventore quis autem at vitae veniam qui maiores. Veritatis sed tenetur quia. Voluptatem mollitia ut numquam molestiae dicta eligendi quod.', '2016-09-11 19:30:49');
INSERT INTO `hotel_review` (`id`, `from_user_id`, `to_hotel_id`, `body`, `created_at`) VALUES ('0', '105', '67', 'Sint voluptas unde quia eos quis omnis. Fugit corporis qui aut repudiandae nisi et ipsum eos. Consectetur voluptate sit autem commodi assumenda autem aliquam. Perspiciatis voluptatem id natus voluptas voluptatem.', '2013-02-27 16:05:17');
INSERT INTO `hotel_review` (`id`, `from_user_id`, `to_hotel_id`, `body`, `created_at`) VALUES ('0', '106', '68', 'Voluptatem reiciendis dolorem perferendis eaque voluptatem. Libero quam quos aut. Ex provident ut mollitia et rem voluptatem. Facere aliquid quae voluptatem commodi voluptatibus molestiae.', '1996-01-24 11:29:36');
INSERT INTO `hotel_review` (`id`, `from_user_id`, `to_hotel_id`, `body`, `created_at`) VALUES ('0', '107', '69', 'Ut doloribus aliquam velit commodi. Dolorem molestias est dolorum non labore error possimus. Totam quam asperiores voluptas dolor aperiam est repudiandae.', '2004-04-07 16:31:32');
INSERT INTO `hotel_review` (`id`, `from_user_id`, `to_hotel_id`, `body`, `created_at`) VALUES ('0', '108', '70', 'Sunt similique voluptate soluta iure a. Maxime assumenda et enim molestiae doloribus consectetur. Sint consequatur facere omnis. Voluptas dolor qui ut enim ea accusantium rem. Nihil sapiente omnis nihil at veritatis dolor atque.', '2006-06-05 08:43:22');
INSERT INTO `hotel_review` (`id`, `from_user_id`, `to_hotel_id`, `body`, `created_at`) VALUES ('0', '109', '71', 'Omnis expedita necessitatibus laboriosam a molestias non. Beatae sint nobis recusandae temporibus quo molestiae voluptas. Voluptate quis voluptatum rerum ut.', '1978-06-11 20:35:48');
INSERT INTO `hotel_review` (`id`, `from_user_id`, `to_hotel_id`, `body`, `created_at`) VALUES ('0', '110', '72', 'Commodi dolorum deserunt maiores rem dignissimos. Expedita incidunt illum minus sed illo vel. Commodi commodi dolor ut et ut suscipit expedita consequatur.', '1999-03-24 15:12:37');
INSERT INTO `hotel_review` (`id`, `from_user_id`, `to_hotel_id`, `body`, `created_at`) VALUES ('0', '112', '73', 'Omnis sunt maxime ratione aliquid ut aliquam ea. Velit sed nesciunt adipisci ipsum doloremque. Suscipit quam culpa accusamus non praesentium maiores quis. Magnam enim vel autem voluptatem.', '2011-10-17 21:53:28');
INSERT INTO `hotel_review` (`id`, `from_user_id`, `to_hotel_id`, `body`, `created_at`) VALUES ('0', '114', '74', 'Repellat omnis ut eligendi molestiae. Reprehenderit minus ratione consectetur ipsa saepe. Molestiae unde est rem consequatur nisi. Quidem quia adipisci eaque omnis deserunt sed.', '2019-02-28 20:25:02');
INSERT INTO `hotel_review` (`id`, `from_user_id`, `to_hotel_id`, `body`, `created_at`) VALUES ('0', '115', '75', 'Dignissimos possimus pariatur velit a repellendus tempore ea ad. Et sunt laudantium ipsam qui similique ea voluptates eos. Veritatis delectus maxime sapiente voluptate itaque consectetur expedita.', '2018-10-14 13:21:42');
INSERT INTO `hotel_review` (`id`, `from_user_id`, `to_hotel_id`, `body`, `created_at`) VALUES ('0', '116', '76', 'Sequi id expedita qui quod non eum. Voluptatum cumque esse sapiente optio. Ipsum perspiciatis unde dolor quas.', '1974-03-18 03:57:19');
INSERT INTO `hotel_review` (`id`, `from_user_id`, `to_hotel_id`, `body`, `created_at`) VALUES ('0', '118', '77', 'Porro delectus velit dicta soluta possimus eligendi. Quo ut consequatur aut aperiam. Quidem iure voluptatibus rerum nobis quisquam. Expedita nulla unde quia optio. Rerum voluptatem dolore asperiores qui quo reprehenderit ea sit.', '2018-09-18 07:20:08');
INSERT INTO `hotel_review` (`id`, `from_user_id`, `to_hotel_id`, `body`, `created_at`) VALUES ('0', '120', '78', 'Est vel debitis earum qui sed. Suscipit veritatis sequi rerum rerum doloremque. Laudantium commodi eos molestias eos qui. Rem in et consequuntur.', '1972-06-25 05:37:16');
INSERT INTO `hotel_review` (`id`, `from_user_id`, `to_hotel_id`, `body`, `created_at`) VALUES ('0', '124', '79', 'Molestiae modi quia voluptas laboriosam. Temporibus quis odio sint reiciendis et quas. Optio minima illo vel autem quibusdam aliquid at voluptates.', '1990-09-09 10:13:09');
INSERT INTO `hotel_review` (`id`, `from_user_id`, `to_hotel_id`, `body`, `created_at`) VALUES ('0', '126', '80', 'Laudantium explicabo veniam reprehenderit. Eum dolor in aut delectus provident beatae velit. Impedit incidunt ipsa eos unde commodi est. Voluptates et ad maxime nisi sint quasi.', '1999-01-02 07:12:58');
INSERT INTO `hotel_review` (`id`, `from_user_id`, `to_hotel_id`, `body`, `created_at`) VALUES ('0', '127', '81', 'Praesentium ut animi quia quaerat architecto ab. Expedita natus veritatis et fugiat quo itaque commodi rerum. Quibusdam quo nobis quibusdam non magni nobis laborum. Laboriosam consequatur ex aliquam reprehenderit. Sint aut molestias rerum ea quas neque doloremque.', '1990-01-21 20:44:11');
INSERT INTO `hotel_review` (`id`, `from_user_id`, `to_hotel_id`, `body`, `created_at`) VALUES ('0', '128', '82', 'Vel quis ullam praesentium similique hic officia. Commodi facere dolores ut rerum sit. Velit quisquam voluptas tempore recusandae eum ea fugit. Voluptatem omnis voluptates consectetur quisquam eos quibusdam et.', '1990-09-08 10:32:01');
INSERT INTO `hotel_review` (`id`, `from_user_id`, `to_hotel_id`, `body`, `created_at`) VALUES ('0', '134', '83', 'Saepe est nobis mollitia aspernatur ea quo alias. Atque ipsa corrupti debitis. Aspernatur dolorem voluptate quis.', '1986-08-14 12:28:21');
INSERT INTO `hotel_review` (`id`, `from_user_id`, `to_hotel_id`, `body`, `created_at`) VALUES ('0', '137', '84', 'Sed rem ullam in autem sit. Temporibus omnis et ex qui quae. Aperiam sit id velit ab voluptatem eos vel.', '2016-09-19 05:19:57');
INSERT INTO `hotel_review` (`id`, `from_user_id`, `to_hotel_id`, `body`, `created_at`) VALUES ('0', '138', '85', 'Rerum inventore nobis sequi rerum natus. Aut dolores adipisci repellat quaerat a assumenda. Minima saepe voluptates ratione sapiente. Vitae dolorem ad amet excepturi odio ratione culpa.', '1987-03-15 00:28:06');
INSERT INTO `hotel_review` (`id`, `from_user_id`, `to_hotel_id`, `body`, `created_at`) VALUES ('0', '140', '86', 'Quo rerum ut quos nihil. Repellendus in et cum reiciendis molestiae possimus eligendi. Placeat magni vel adipisci. Placeat maxime eveniet dolore earum ducimus.', '2014-08-11 01:54:49');
INSERT INTO `hotel_review` (`id`, `from_user_id`, `to_hotel_id`, `body`, `created_at`) VALUES ('0', '145', '87', 'Aliquid itaque rerum eos nihil possimus nostrum consequatur. Dolores est dignissimos modi eligendi. Quisquam officia fuga minima sed.', '2007-03-02 13:42:13');
INSERT INTO `hotel_review` (`id`, `from_user_id`, `to_hotel_id`, `body`, `created_at`) VALUES ('0', '146', '88', 'Odit inventore veritatis laboriosam esse sunt dolore rerum. Et non temporibus vel pariatur dolore voluptas impedit. Quae sapiente autem aliquid tenetur. Iure eius similique dolorum tempore rerum.', '1977-03-25 08:20:19');
INSERT INTO `hotel_review` (`id`, `from_user_id`, `to_hotel_id`, `body`, `created_at`) VALUES ('0', '147', '89', 'Aperiam sed quos similique excepturi soluta quis. Nulla amet similique maxime nihil voluptatum fuga dolorem nulla. Maiores aliquam commodi eos totam vel temporibus.', '2007-08-15 11:43:53');
INSERT INTO `hotel_review` (`id`, `from_user_id`, `to_hotel_id`, `body`, `created_at`) VALUES ('0', '148', '90', 'Placeat non eos quia quibusdam tempore nihil. Nemo quidem accusamus provident consequatur deleniti. Quod molestiae laboriosam sit iure quasi. Autem magnam explicabo earum eaque.', '2020-01-16 12:39:46');
INSERT INTO `hotel_review` (`id`, `from_user_id`, `to_hotel_id`, `body`, `created_at`) VALUES ('0', '149', '91', 'Ipsa veniam culpa consequatur numquam. Ut reprehenderit enim quas. Nam quibusdam illum sed laborum alias unde cumque quas.', '2016-07-12 08:26:14');
INSERT INTO `hotel_review` (`id`, `from_user_id`, `to_hotel_id`, `body`, `created_at`) VALUES ('0', '150', '92', 'Aut maiores sit ipsam. Repellat minus facere est fuga voluptas. Veniam dicta distinctio odit pariatur deserunt. Aut laboriosam non non.', '1993-04-11 22:18:58');
INSERT INTO `hotel_review` (`id`, `from_user_id`, `to_hotel_id`, `body`, `created_at`) VALUES ('0', '151', '93', 'A ullam eos dignissimos et dicta in. Ipsa occaecati dolorem dolor qui rerum. Qui vero est perspiciatis labore.', '2007-07-06 03:59:24');
INSERT INTO `hotel_review` (`id`, `from_user_id`, `to_hotel_id`, `body`, `created_at`) VALUES ('0', '152', '94', 'Dolore laudantium aperiam eaque est. Aperiam quo ex aut corrupti. Perferendis inventore dicta rerum iusto vel. Enim totam voluptatem itaque ex quo.', '2011-02-13 03:02:47');
INSERT INTO `hotel_review` (`id`, `from_user_id`, `to_hotel_id`, `body`, `created_at`) VALUES ('0', '153', '95', 'Molestiae eligendi amet fugiat earum est. Odit a enim aliquam. Magni adipisci nam quo. Temporibus tenetur odio quo sint numquam aut.', '1974-04-19 11:02:02');
INSERT INTO `hotel_review` (`id`, `from_user_id`, `to_hotel_id`, `body`, `created_at`) VALUES ('0', '154', '96', 'Vel in esse velit autem voluptatem. Corrupti rerum itaque iusto fugiat voluptatum qui quisquam ad. Quidem nihil vero eum hic voluptate reprehenderit magnam. Accusamus mollitia voluptatum amet reprehenderit dolor molestiae. Beatae deserunt officia dignissimos et eligendi omnis.', '1990-04-21 16:53:45');
INSERT INTO `hotel_review` (`id`, `from_user_id`, `to_hotel_id`, `body`, `created_at`) VALUES ('0', '155', '97', 'Qui perspiciatis aliquid libero aut aperiam. Voluptatum quam dolore a temporibus quia sed. Est recusandae provident et odit.', '1971-09-08 11:58:55');
INSERT INTO `hotel_review` (`id`, `from_user_id`, `to_hotel_id`, `body`, `created_at`) VALUES ('0', '157', '98', 'Consequatur fuga dolores quae quam harum. Exercitationem aperiam voluptate et rem. Doloremque tempora odit corrupti nam omnis iste cum. Necessitatibus eum quia fuga odit.', '1994-03-25 17:27:07');
INSERT INTO `hotel_review` (`id`, `from_user_id`, `to_hotel_id`, `body`, `created_at`) VALUES ('0', '159', '99', 'Molestiae molestias dicta dolores voluptas est. Aut aperiam dolor error earum accusantium facere.', '2017-08-14 18:45:12');
INSERT INTO `hotel_review` (`id`, `from_user_id`, `to_hotel_id`, `body`, `created_at`) VALUES ('0', '160', '100', 'Libero illo consequatur molestiae voluptatum. Ut doloremque dolorem accusantium modi et vero labore. Explicabo ut deserunt blanditiis aut rerum ipsa. Et tempore aliquid quasi quae. Ipsa architecto nihil animi.', '2019-12-30 17:07:19');


#
# TABLE STRUCTURE FOR: hotels
#

DROP TABLE IF EXISTS `hotels`;

CREATE TABLE `hotels` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `name_hotel` varchar(100) COLLATE utf8_unicode_ci DEFAULT NULL,
  `number_of_stars` int(10) unsigned DEFAULT NULL,
  `id_room_type` bigint(20) unsigned NOT NULL,
  `id_food_type` bigint(20) unsigned NOT NULL,
  PRIMARY KEY (`id`),
  KEY `hotels_number_of_stars` (`number_of_stars`)
) ENGINE=InnoDB AUTO_INCREMENT=101 DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

INSERT INTO `hotels` (`id`, `name_hotel`, `number_of_stars`, `id_room_type`, `id_food_type`) VALUES ('1', 'expedita', 3257050, '2', '6');
INSERT INTO `hotels` (`id`, `name_hotel`, `number_of_stars`, `id_room_type`, `id_food_type`) VALUES ('2', 'nemo', 488, '5', '9');
INSERT INTO `hotels` (`id`, `name_hotel`, `number_of_stars`, `id_room_type`, `id_food_type`) VALUES ('3', 'eos', 6, '7', '4');
INSERT INTO `hotels` (`id`, `name_hotel`, `number_of_stars`, `id_room_type`, `id_food_type`) VALUES ('4', 'quod', 64538, '6', '7');
INSERT INTO `hotels` (`id`, `name_hotel`, `number_of_stars`, `id_room_type`, `id_food_type`) VALUES ('5', 'sed', 196566, '2', '0');
INSERT INTO `hotels` (`id`, `name_hotel`, `number_of_stars`, `id_room_type`, `id_food_type`) VALUES ('6', 'veritatis', 0, '8', '8');
INSERT INTO `hotels` (`id`, `name_hotel`, `number_of_stars`, `id_room_type`, `id_food_type`) VALUES ('7', 'magnam', 4038938, '9', '6');
INSERT INTO `hotels` (`id`, `name_hotel`, `number_of_stars`, `id_room_type`, `id_food_type`) VALUES ('8', 'debitis', 5318484, '0', '4');
INSERT INTO `hotels` (`id`, `name_hotel`, `number_of_stars`, `id_room_type`, `id_food_type`) VALUES ('9', 'fuga', 504, '2', '4');
INSERT INTO `hotels` (`id`, `name_hotel`, `number_of_stars`, `id_room_type`, `id_food_type`) VALUES ('10', 'doloribus', 0, '7', '2');
INSERT INTO `hotels` (`id`, `name_hotel`, `number_of_stars`, `id_room_type`, `id_food_type`) VALUES ('11', 'beatae', 5953176, '5', '8');
INSERT INTO `hotels` (`id`, `name_hotel`, `number_of_stars`, `id_room_type`, `id_food_type`) VALUES ('12', 'ullam', 601, '6', '3');
INSERT INTO `hotels` (`id`, `name_hotel`, `number_of_stars`, `id_room_type`, `id_food_type`) VALUES ('13', 'repellendus', 1, '1', '1');
INSERT INTO `hotels` (`id`, `name_hotel`, `number_of_stars`, `id_room_type`, `id_food_type`) VALUES ('14', 'ipsum', 0, '4', '9');
INSERT INTO `hotels` (`id`, `name_hotel`, `number_of_stars`, `id_room_type`, `id_food_type`) VALUES ('15', 'rerum', 27275691, '8', '4');
INSERT INTO `hotels` (`id`, `name_hotel`, `number_of_stars`, `id_room_type`, `id_food_type`) VALUES ('16', 'eius', 302217889, '4', '5');
INSERT INTO `hotels` (`id`, `name_hotel`, `number_of_stars`, `id_room_type`, `id_food_type`) VALUES ('17', 'officia', 3369835, '8', '0');
INSERT INTO `hotels` (`id`, `name_hotel`, `number_of_stars`, `id_room_type`, `id_food_type`) VALUES ('18', 'debitis', 42, '6', '7');
INSERT INTO `hotels` (`id`, `name_hotel`, `number_of_stars`, `id_room_type`, `id_food_type`) VALUES ('19', 'dolorum', 1551478, '5', '9');
INSERT INTO `hotels` (`id`, `name_hotel`, `number_of_stars`, `id_room_type`, `id_food_type`) VALUES ('20', 'aliquid', 16066, '1', '2');
INSERT INTO `hotels` (`id`, `name_hotel`, `number_of_stars`, `id_room_type`, `id_food_type`) VALUES ('21', 'sed', 76674, '0', '5');
INSERT INTO `hotels` (`id`, `name_hotel`, `number_of_stars`, `id_room_type`, `id_food_type`) VALUES ('22', 'impedit', 97078, '6', '6');
INSERT INTO `hotels` (`id`, `name_hotel`, `number_of_stars`, `id_room_type`, `id_food_type`) VALUES ('23', 'ratione', 0, '6', '9');
INSERT INTO `hotels` (`id`, `name_hotel`, `number_of_stars`, `id_room_type`, `id_food_type`) VALUES ('24', 'nisi', 57658, '4', '4');
INSERT INTO `hotels` (`id`, `name_hotel`, `number_of_stars`, `id_room_type`, `id_food_type`) VALUES ('25', 'doloremque', 46, '7', '4');
INSERT INTO `hotels` (`id`, `name_hotel`, `number_of_stars`, `id_room_type`, `id_food_type`) VALUES ('26', 'voluptatibus', 97768, '1', '9');
INSERT INTO `hotels` (`id`, `name_hotel`, `number_of_stars`, `id_room_type`, `id_food_type`) VALUES ('27', 'ipsam', 715163, '7', '5');
INSERT INTO `hotels` (`id`, `name_hotel`, `number_of_stars`, `id_room_type`, `id_food_type`) VALUES ('28', 'distinctio', 0, '9', '7');
INSERT INTO `hotels` (`id`, `name_hotel`, `number_of_stars`, `id_room_type`, `id_food_type`) VALUES ('29', 'reprehenderit', 79117920, '8', '2');
INSERT INTO `hotels` (`id`, `name_hotel`, `number_of_stars`, `id_room_type`, `id_food_type`) VALUES ('30', 'reprehenderit', 455662218, '3', '7');
INSERT INTO `hotels` (`id`, `name_hotel`, `number_of_stars`, `id_room_type`, `id_food_type`) VALUES ('31', 'qui', 177279886, '5', '4');
INSERT INTO `hotels` (`id`, `name_hotel`, `number_of_stars`, `id_room_type`, `id_food_type`) VALUES ('32', 'deserunt', 7766, '3', '7');
INSERT INTO `hotels` (`id`, `name_hotel`, `number_of_stars`, `id_room_type`, `id_food_type`) VALUES ('33', 'fugit', 0, '0', '1');
INSERT INTO `hotels` (`id`, `name_hotel`, `number_of_stars`, `id_room_type`, `id_food_type`) VALUES ('34', 'eum', 8432, '1', '0');
INSERT INTO `hotels` (`id`, `name_hotel`, `number_of_stars`, `id_room_type`, `id_food_type`) VALUES ('35', 'ipsam', 51250207, '7', '3');
INSERT INTO `hotels` (`id`, `name_hotel`, `number_of_stars`, `id_room_type`, `id_food_type`) VALUES ('36', 'officia', 2401335, '9', '1');
INSERT INTO `hotels` (`id`, `name_hotel`, `number_of_stars`, `id_room_type`, `id_food_type`) VALUES ('37', 'est', 32633513, '6', '5');
INSERT INTO `hotels` (`id`, `name_hotel`, `number_of_stars`, `id_room_type`, `id_food_type`) VALUES ('38', 'voluptas', 880, '6', '5');
INSERT INTO `hotels` (`id`, `name_hotel`, `number_of_stars`, `id_room_type`, `id_food_type`) VALUES ('39', 'aut', 3982973, '9', '2');
INSERT INTO `hotels` (`id`, `name_hotel`, `number_of_stars`, `id_room_type`, `id_food_type`) VALUES ('40', 'impedit', 59409, '3', '6');
INSERT INTO `hotels` (`id`, `name_hotel`, `number_of_stars`, `id_room_type`, `id_food_type`) VALUES ('41', 'esse', 2684, '1', '3');
INSERT INTO `hotels` (`id`, `name_hotel`, `number_of_stars`, `id_room_type`, `id_food_type`) VALUES ('42', 'laudantium', 3, '3', '9');
INSERT INTO `hotels` (`id`, `name_hotel`, `number_of_stars`, `id_room_type`, `id_food_type`) VALUES ('43', 'molestias', 873440544, '2', '7');
INSERT INTO `hotels` (`id`, `name_hotel`, `number_of_stars`, `id_room_type`, `id_food_type`) VALUES ('44', 'veritatis', 296974297, '7', '5');
INSERT INTO `hotels` (`id`, `name_hotel`, `number_of_stars`, `id_room_type`, `id_food_type`) VALUES ('45', 'assumenda', 3, '7', '4');
INSERT INTO `hotels` (`id`, `name_hotel`, `number_of_stars`, `id_room_type`, `id_food_type`) VALUES ('46', 'enim', 481131, '6', '0');
INSERT INTO `hotels` (`id`, `name_hotel`, `number_of_stars`, `id_room_type`, `id_food_type`) VALUES ('47', 'laborum', 768554, '9', '7');
INSERT INTO `hotels` (`id`, `name_hotel`, `number_of_stars`, `id_room_type`, `id_food_type`) VALUES ('48', 'laudantium', 5982956, '2', '9');
INSERT INTO `hotels` (`id`, `name_hotel`, `number_of_stars`, `id_room_type`, `id_food_type`) VALUES ('49', 'suscipit', 752460, '8', '3');
INSERT INTO `hotels` (`id`, `name_hotel`, `number_of_stars`, `id_room_type`, `id_food_type`) VALUES ('50', 'qui', 765712, '6', '2');
INSERT INTO `hotels` (`id`, `name_hotel`, `number_of_stars`, `id_room_type`, `id_food_type`) VALUES ('51', 'rem', 78, '8', '5');
INSERT INTO `hotels` (`id`, `name_hotel`, `number_of_stars`, `id_room_type`, `id_food_type`) VALUES ('52', 'omnis', 38469497, '4', '0');
INSERT INTO `hotels` (`id`, `name_hotel`, `number_of_stars`, `id_room_type`, `id_food_type`) VALUES ('53', 'sint', 112, '2', '0');
INSERT INTO `hotels` (`id`, `name_hotel`, `number_of_stars`, `id_room_type`, `id_food_type`) VALUES ('54', 'autem', 461, '3', '5');
INSERT INTO `hotels` (`id`, `name_hotel`, `number_of_stars`, `id_room_type`, `id_food_type`) VALUES ('55', 'ipsum', 308, '5', '9');
INSERT INTO `hotels` (`id`, `name_hotel`, `number_of_stars`, `id_room_type`, `id_food_type`) VALUES ('56', 'illum', 739, '6', '6');
INSERT INTO `hotels` (`id`, `name_hotel`, `number_of_stars`, `id_room_type`, `id_food_type`) VALUES ('57', 'enim', 6, '7', '7');
INSERT INTO `hotels` (`id`, `name_hotel`, `number_of_stars`, `id_room_type`, `id_food_type`) VALUES ('58', 'adipisci', 0, '5', '7');
INSERT INTO `hotels` (`id`, `name_hotel`, `number_of_stars`, `id_room_type`, `id_food_type`) VALUES ('59', 'placeat', 8292, '5', '8');
INSERT INTO `hotels` (`id`, `name_hotel`, `number_of_stars`, `id_room_type`, `id_food_type`) VALUES ('60', 'maxime', 592, '9', '8');
INSERT INTO `hotels` (`id`, `name_hotel`, `number_of_stars`, `id_room_type`, `id_food_type`) VALUES ('61', 'voluptas', 38, '6', '4');
INSERT INTO `hotels` (`id`, `name_hotel`, `number_of_stars`, `id_room_type`, `id_food_type`) VALUES ('62', 'sunt', 59, '7', '2');
INSERT INTO `hotels` (`id`, `name_hotel`, `number_of_stars`, `id_room_type`, `id_food_type`) VALUES ('63', 'molestiae', 0, '8', '6');
INSERT INTO `hotels` (`id`, `name_hotel`, `number_of_stars`, `id_room_type`, `id_food_type`) VALUES ('64', 'voluptatem', 0, '0', '5');
INSERT INTO `hotels` (`id`, `name_hotel`, `number_of_stars`, `id_room_type`, `id_food_type`) VALUES ('65', 'deleniti', 60059, '0', '1');
INSERT INTO `hotels` (`id`, `name_hotel`, `number_of_stars`, `id_room_type`, `id_food_type`) VALUES ('66', 'temporibus', 8513704, '5', '7');
INSERT INTO `hotels` (`id`, `name_hotel`, `number_of_stars`, `id_room_type`, `id_food_type`) VALUES ('67', 'voluptatem', 2, '1', '0');
INSERT INTO `hotels` (`id`, `name_hotel`, `number_of_stars`, `id_room_type`, `id_food_type`) VALUES ('68', 'quo', 85744, '6', '8');
INSERT INTO `hotels` (`id`, `name_hotel`, `number_of_stars`, `id_room_type`, `id_food_type`) VALUES ('69', 'omnis', 93, '3', '1');
INSERT INTO `hotels` (`id`, `name_hotel`, `number_of_stars`, `id_room_type`, `id_food_type`) VALUES ('70', 'nostrum', 6, '6', '5');
INSERT INTO `hotels` (`id`, `name_hotel`, `number_of_stars`, `id_room_type`, `id_food_type`) VALUES ('71', 'labore', 26, '8', '4');
INSERT INTO `hotels` (`id`, `name_hotel`, `number_of_stars`, `id_room_type`, `id_food_type`) VALUES ('72', 'sit', 7430, '2', '0');
INSERT INTO `hotels` (`id`, `name_hotel`, `number_of_stars`, `id_room_type`, `id_food_type`) VALUES ('73', 'quis', 467084008, '6', '5');
INSERT INTO `hotels` (`id`, `name_hotel`, `number_of_stars`, `id_room_type`, `id_food_type`) VALUES ('74', 'quam', 1035, '6', '5');
INSERT INTO `hotels` (`id`, `name_hotel`, `number_of_stars`, `id_room_type`, `id_food_type`) VALUES ('75', 'delectus', 3759458, '3', '7');
INSERT INTO `hotels` (`id`, `name_hotel`, `number_of_stars`, `id_room_type`, `id_food_type`) VALUES ('76', 'explicabo', 7623, '3', '2');
INSERT INTO `hotels` (`id`, `name_hotel`, `number_of_stars`, `id_room_type`, `id_food_type`) VALUES ('77', 'quia', 3728497, '9', '9');
INSERT INTO `hotels` (`id`, `name_hotel`, `number_of_stars`, `id_room_type`, `id_food_type`) VALUES ('78', 'in', 659958454, '6', '0');
INSERT INTO `hotels` (`id`, `name_hotel`, `number_of_stars`, `id_room_type`, `id_food_type`) VALUES ('79', 'rerum', 751, '6', '0');
INSERT INTO `hotels` (`id`, `name_hotel`, `number_of_stars`, `id_room_type`, `id_food_type`) VALUES ('80', 'aut', 489188694, '6', '7');
INSERT INTO `hotels` (`id`, `name_hotel`, `number_of_stars`, `id_room_type`, `id_food_type`) VALUES ('81', 'ratione', 0, '1', '0');
INSERT INTO `hotels` (`id`, `name_hotel`, `number_of_stars`, `id_room_type`, `id_food_type`) VALUES ('82', 'quia', 0, '1', '9');
INSERT INTO `hotels` (`id`, `name_hotel`, `number_of_stars`, `id_room_type`, `id_food_type`) VALUES ('83', 'repudiandae', 27, '8', '1');
INSERT INTO `hotels` (`id`, `name_hotel`, `number_of_stars`, `id_room_type`, `id_food_type`) VALUES ('84', 'placeat', 5, '8', '4');
INSERT INTO `hotels` (`id`, `name_hotel`, `number_of_stars`, `id_room_type`, `id_food_type`) VALUES ('85', 'quia', 55671701, '0', '9');
INSERT INTO `hotels` (`id`, `name_hotel`, `number_of_stars`, `id_room_type`, `id_food_type`) VALUES ('86', 'iusto', 57, '6', '0');
INSERT INTO `hotels` (`id`, `name_hotel`, `number_of_stars`, `id_room_type`, `id_food_type`) VALUES ('87', 'temporibus', 43479897, '7', '7');
INSERT INTO `hotels` (`id`, `name_hotel`, `number_of_stars`, `id_room_type`, `id_food_type`) VALUES ('88', 'sunt', 0, '2', '6');
INSERT INTO `hotels` (`id`, `name_hotel`, `number_of_stars`, `id_room_type`, `id_food_type`) VALUES ('89', 'tenetur', 6, '8', '1');
INSERT INTO `hotels` (`id`, `name_hotel`, `number_of_stars`, `id_room_type`, `id_food_type`) VALUES ('90', 'voluptas', 3664, '4', '2');
INSERT INTO `hotels` (`id`, `name_hotel`, `number_of_stars`, `id_room_type`, `id_food_type`) VALUES ('91', 'quidem', 9, '9', '8');
INSERT INTO `hotels` (`id`, `name_hotel`, `number_of_stars`, `id_room_type`, `id_food_type`) VALUES ('92', 'quo', 22, '8', '0');
INSERT INTO `hotels` (`id`, `name_hotel`, `number_of_stars`, `id_room_type`, `id_food_type`) VALUES ('93', 'ea', 59365274, '4', '5');
INSERT INTO `hotels` (`id`, `name_hotel`, `number_of_stars`, `id_room_type`, `id_food_type`) VALUES ('94', 'magnam', 354595884, '0', '0');
INSERT INTO `hotels` (`id`, `name_hotel`, `number_of_stars`, `id_room_type`, `id_food_type`) VALUES ('95', 'accusamus', 85388, '1', '8');
INSERT INTO `hotels` (`id`, `name_hotel`, `number_of_stars`, `id_room_type`, `id_food_type`) VALUES ('96', 'inventore', 572150, '4', '7');
INSERT INTO `hotels` (`id`, `name_hotel`, `number_of_stars`, `id_room_type`, `id_food_type`) VALUES ('97', 'nam', 46399749, '8', '6');
INSERT INTO `hotels` (`id`, `name_hotel`, `number_of_stars`, `id_room_type`, `id_food_type`) VALUES ('98', 'quis', 1806026, '7', '2');
INSERT INTO `hotels` (`id`, `name_hotel`, `number_of_stars`, `id_room_type`, `id_food_type`) VALUES ('99', 'aut', 1776, '0', '4');
INSERT INTO `hotels` (`id`, `name_hotel`, `number_of_stars`, `id_room_type`, `id_food_type`) VALUES ('100', 'officia', 36, '9', '4');


#
# TABLE STRUCTURE FOR: media_types
#

DROP TABLE IF EXISTS `media_types`;

CREATE TABLE `media_types` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `name` varchar(100) COLLATE utf8_unicode_ci DEFAULT NULL,
  `created_at` datetime DEFAULT current_timestamp(),
  `updated_at` datetime DEFAULT current_timestamp() ON UPDATE current_timestamp(),
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=101 DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

INSERT INTO `media_types` (`id`, `name`, `created_at`, `updated_at`) VALUES ('1', 'optio', '2019-02-06 04:03:05', '2020-06-09 18:22:06');
INSERT INTO `media_types` (`id`, `name`, `created_at`, `updated_at`) VALUES ('2', 'dolorum', '1987-12-21 08:53:55', '2009-08-18 00:38:23');
INSERT INTO `media_types` (`id`, `name`, `created_at`, `updated_at`) VALUES ('3', 'sint', '1995-02-15 18:21:59', '2017-11-07 09:11:18');
INSERT INTO `media_types` (`id`, `name`, `created_at`, `updated_at`) VALUES ('4', 'nisi', '1993-06-22 02:56:30', '2017-07-06 03:28:44');
INSERT INTO `media_types` (`id`, `name`, `created_at`, `updated_at`) VALUES ('5', 'aut', '2009-10-25 11:01:00', '2016-04-01 20:56:47');
INSERT INTO `media_types` (`id`, `name`, `created_at`, `updated_at`) VALUES ('6', 'incidunt', '1991-06-18 02:46:39', '2002-10-19 04:44:22');
INSERT INTO `media_types` (`id`, `name`, `created_at`, `updated_at`) VALUES ('7', 'rerum', '1999-06-06 12:36:39', '2009-01-13 07:54:37');
INSERT INTO `media_types` (`id`, `name`, `created_at`, `updated_at`) VALUES ('8', 'in', '2018-08-03 10:48:35', '2013-08-14 06:17:46');
INSERT INTO `media_types` (`id`, `name`, `created_at`, `updated_at`) VALUES ('9', 'laudantium', '1973-09-21 07:12:17', '2016-12-06 13:30:49');
INSERT INTO `media_types` (`id`, `name`, `created_at`, `updated_at`) VALUES ('10', 'quam', '2015-02-01 05:39:29', '2017-07-21 13:02:39');
INSERT INTO `media_types` (`id`, `name`, `created_at`, `updated_at`) VALUES ('11', 'vero', '1992-01-23 23:22:34', '1998-12-04 23:23:51');
INSERT INTO `media_types` (`id`, `name`, `created_at`, `updated_at`) VALUES ('12', 'sunt', '1970-10-29 23:36:56', '2008-06-23 06:32:56');
INSERT INTO `media_types` (`id`, `name`, `created_at`, `updated_at`) VALUES ('13', 'nostrum', '1992-10-22 11:37:54', '1988-12-15 04:16:29');
INSERT INTO `media_types` (`id`, `name`, `created_at`, `updated_at`) VALUES ('14', 'minus', '2014-10-17 07:30:04', '1976-11-05 21:15:50');
INSERT INTO `media_types` (`id`, `name`, `created_at`, `updated_at`) VALUES ('15', 'quia', '1999-04-15 07:34:33', '1977-10-17 00:33:21');
INSERT INTO `media_types` (`id`, `name`, `created_at`, `updated_at`) VALUES ('16', 'sed', '2010-04-12 08:22:46', '2001-02-16 16:55:15');
INSERT INTO `media_types` (`id`, `name`, `created_at`, `updated_at`) VALUES ('17', 'ut', '1996-07-27 14:59:13', '1998-03-13 11:47:26');
INSERT INTO `media_types` (`id`, `name`, `created_at`, `updated_at`) VALUES ('18', 'non', '1970-07-23 18:22:43', '1981-10-18 01:28:14');
INSERT INTO `media_types` (`id`, `name`, `created_at`, `updated_at`) VALUES ('19', 'velit', '1997-10-23 10:54:31', '1991-09-08 04:49:03');
INSERT INTO `media_types` (`id`, `name`, `created_at`, `updated_at`) VALUES ('20', 'pariatur', '1985-12-05 19:42:26', '1981-09-04 14:17:13');
INSERT INTO `media_types` (`id`, `name`, `created_at`, `updated_at`) VALUES ('21', 'molestiae', '1984-05-28 12:49:13', '2009-12-08 18:14:25');
INSERT INTO `media_types` (`id`, `name`, `created_at`, `updated_at`) VALUES ('22', 'dicta', '1970-08-12 23:02:00', '1982-02-12 22:11:57');
INSERT INTO `media_types` (`id`, `name`, `created_at`, `updated_at`) VALUES ('23', 'non', '2011-04-21 06:57:34', '2007-11-01 07:42:06');
INSERT INTO `media_types` (`id`, `name`, `created_at`, `updated_at`) VALUES ('24', 'ut', '1994-02-12 13:35:12', '1999-07-09 08:17:04');
INSERT INTO `media_types` (`id`, `name`, `created_at`, `updated_at`) VALUES ('25', 'eum', '1979-08-14 09:46:15', '1995-07-06 04:00:20');
INSERT INTO `media_types` (`id`, `name`, `created_at`, `updated_at`) VALUES ('26', 'laborum', '2001-01-30 01:24:07', '1989-08-09 16:49:47');
INSERT INTO `media_types` (`id`, `name`, `created_at`, `updated_at`) VALUES ('27', 'vero', '2013-03-29 12:01:46', '1996-06-13 10:07:59');
INSERT INTO `media_types` (`id`, `name`, `created_at`, `updated_at`) VALUES ('28', 'eos', '1994-08-05 19:42:49', '2001-07-22 14:11:04');
INSERT INTO `media_types` (`id`, `name`, `created_at`, `updated_at`) VALUES ('29', 'veritatis', '1971-09-17 07:27:54', '1980-07-05 23:23:45');
INSERT INTO `media_types` (`id`, `name`, `created_at`, `updated_at`) VALUES ('30', 'deserunt', '1999-01-06 01:39:16', '2009-12-08 13:45:45');
INSERT INTO `media_types` (`id`, `name`, `created_at`, `updated_at`) VALUES ('31', 'laborum', '1970-04-22 15:14:23', '2020-03-20 19:58:09');
INSERT INTO `media_types` (`id`, `name`, `created_at`, `updated_at`) VALUES ('32', 'vel', '2003-02-22 01:37:29', '1987-03-02 20:56:21');
INSERT INTO `media_types` (`id`, `name`, `created_at`, `updated_at`) VALUES ('33', 'quia', '1979-02-20 06:14:39', '1991-08-30 23:40:08');
INSERT INTO `media_types` (`id`, `name`, `created_at`, `updated_at`) VALUES ('34', 'libero', '1986-05-24 02:24:04', '1984-06-28 10:37:33');
INSERT INTO `media_types` (`id`, `name`, `created_at`, `updated_at`) VALUES ('35', 'et', '2002-09-15 18:00:18', '1995-07-23 23:06:02');
INSERT INTO `media_types` (`id`, `name`, `created_at`, `updated_at`) VALUES ('36', 'nobis', '2014-02-25 17:07:01', '1979-08-08 10:16:02');
INSERT INTO `media_types` (`id`, `name`, `created_at`, `updated_at`) VALUES ('37', 'quaerat', '1987-01-04 22:02:58', '1998-10-11 16:53:20');
INSERT INTO `media_types` (`id`, `name`, `created_at`, `updated_at`) VALUES ('38', 'eius', '1982-03-04 23:38:58', '1994-05-23 22:38:40');
INSERT INTO `media_types` (`id`, `name`, `created_at`, `updated_at`) VALUES ('39', 'reiciendis', '1996-07-03 07:11:49', '2009-07-29 01:34:06');
INSERT INTO `media_types` (`id`, `name`, `created_at`, `updated_at`) VALUES ('40', 'earum', '1980-06-29 01:44:12', '1980-07-08 04:04:38');
INSERT INTO `media_types` (`id`, `name`, `created_at`, `updated_at`) VALUES ('41', 'quibusdam', '1986-06-22 01:36:41', '2007-06-27 23:27:20');
INSERT INTO `media_types` (`id`, `name`, `created_at`, `updated_at`) VALUES ('42', 'culpa', '2011-01-02 09:26:48', '1999-06-21 09:37:09');
INSERT INTO `media_types` (`id`, `name`, `created_at`, `updated_at`) VALUES ('43', 'et', '1988-05-15 09:09:47', '2005-08-02 15:37:38');
INSERT INTO `media_types` (`id`, `name`, `created_at`, `updated_at`) VALUES ('44', 'cupiditate', '1999-03-20 13:53:50', '1981-10-14 00:20:44');
INSERT INTO `media_types` (`id`, `name`, `created_at`, `updated_at`) VALUES ('45', 'dolore', '1989-11-01 21:50:28', '1988-08-23 15:23:40');
INSERT INTO `media_types` (`id`, `name`, `created_at`, `updated_at`) VALUES ('46', 'incidunt', '2016-09-04 12:42:00', '1973-12-09 17:22:23');
INSERT INTO `media_types` (`id`, `name`, `created_at`, `updated_at`) VALUES ('47', 'iusto', '1999-06-18 02:07:27', '1991-01-06 23:01:40');
INSERT INTO `media_types` (`id`, `name`, `created_at`, `updated_at`) VALUES ('48', 'modi', '1979-01-21 12:10:31', '2019-09-14 12:16:20');
INSERT INTO `media_types` (`id`, `name`, `created_at`, `updated_at`) VALUES ('49', 'perspiciatis', '2013-08-23 18:11:33', '2007-10-27 06:30:52');
INSERT INTO `media_types` (`id`, `name`, `created_at`, `updated_at`) VALUES ('50', 'est', '1996-06-23 14:55:12', '2007-03-28 12:05:35');
INSERT INTO `media_types` (`id`, `name`, `created_at`, `updated_at`) VALUES ('51', 'rem', '1997-01-15 03:14:09', '1984-01-14 07:44:56');
INSERT INTO `media_types` (`id`, `name`, `created_at`, `updated_at`) VALUES ('52', 'numquam', '2001-01-25 06:39:08', '2011-01-10 04:21:00');
INSERT INTO `media_types` (`id`, `name`, `created_at`, `updated_at`) VALUES ('53', 'deleniti', '2012-09-18 20:22:48', '1987-06-25 05:58:04');
INSERT INTO `media_types` (`id`, `name`, `created_at`, `updated_at`) VALUES ('54', 'nam', '2007-11-22 19:43:57', '2014-07-10 22:37:58');
INSERT INTO `media_types` (`id`, `name`, `created_at`, `updated_at`) VALUES ('55', 'voluptatem', '1993-12-04 10:24:34', '1983-10-10 22:32:48');
INSERT INTO `media_types` (`id`, `name`, `created_at`, `updated_at`) VALUES ('56', 'consequuntur', '1993-06-14 21:02:30', '1974-07-23 14:22:31');
INSERT INTO `media_types` (`id`, `name`, `created_at`, `updated_at`) VALUES ('57', 'reiciendis', '2011-03-07 05:35:41', '1999-01-25 13:14:22');
INSERT INTO `media_types` (`id`, `name`, `created_at`, `updated_at`) VALUES ('58', 'eius', '1999-09-03 13:16:39', '2002-10-22 12:24:49');
INSERT INTO `media_types` (`id`, `name`, `created_at`, `updated_at`) VALUES ('59', 'quia', '1990-06-20 01:51:48', '2008-11-12 03:41:13');
INSERT INTO `media_types` (`id`, `name`, `created_at`, `updated_at`) VALUES ('60', 'sit', '1972-04-08 07:52:04', '2015-10-13 00:13:12');
INSERT INTO `media_types` (`id`, `name`, `created_at`, `updated_at`) VALUES ('61', 'tempora', '1983-05-15 09:49:14', '1975-08-24 22:06:22');
INSERT INTO `media_types` (`id`, `name`, `created_at`, `updated_at`) VALUES ('62', 'aliquid', '1988-01-16 01:40:51', '1979-05-26 21:01:19');
INSERT INTO `media_types` (`id`, `name`, `created_at`, `updated_at`) VALUES ('63', 'qui', '2011-12-23 14:20:55', '1987-11-04 21:00:55');
INSERT INTO `media_types` (`id`, `name`, `created_at`, `updated_at`) VALUES ('64', 'deserunt', '2015-08-21 13:11:51', '1979-05-08 02:54:51');
INSERT INTO `media_types` (`id`, `name`, `created_at`, `updated_at`) VALUES ('65', 'soluta', '1989-02-03 18:44:59', '2003-01-31 04:48:05');
INSERT INTO `media_types` (`id`, `name`, `created_at`, `updated_at`) VALUES ('66', 'ullam', '1994-09-14 09:38:54', '1970-12-17 18:25:19');
INSERT INTO `media_types` (`id`, `name`, `created_at`, `updated_at`) VALUES ('67', 'praesentium', '2006-08-12 02:11:54', '2011-11-03 11:51:48');
INSERT INTO `media_types` (`id`, `name`, `created_at`, `updated_at`) VALUES ('68', 'in', '1989-04-19 04:29:40', '1995-07-26 05:40:37');
INSERT INTO `media_types` (`id`, `name`, `created_at`, `updated_at`) VALUES ('69', 'praesentium', '1983-01-18 16:50:31', '2003-11-16 13:20:16');
INSERT INTO `media_types` (`id`, `name`, `created_at`, `updated_at`) VALUES ('70', 'iste', '1996-03-23 16:34:08', '1976-07-31 19:58:05');
INSERT INTO `media_types` (`id`, `name`, `created_at`, `updated_at`) VALUES ('71', 'officiis', '2011-02-28 04:01:06', '1974-05-14 21:38:03');
INSERT INTO `media_types` (`id`, `name`, `created_at`, `updated_at`) VALUES ('72', 'facilis', '1994-08-19 18:21:27', '2015-07-29 06:15:26');
INSERT INTO `media_types` (`id`, `name`, `created_at`, `updated_at`) VALUES ('73', 'unde', '1991-03-03 16:09:07', '1971-06-20 12:30:56');
INSERT INTO `media_types` (`id`, `name`, `created_at`, `updated_at`) VALUES ('74', 'accusantium', '2014-01-08 06:25:56', '1985-06-27 22:50:10');
INSERT INTO `media_types` (`id`, `name`, `created_at`, `updated_at`) VALUES ('75', 'deserunt', '1998-04-30 19:37:47', '1985-07-30 20:54:37');
INSERT INTO `media_types` (`id`, `name`, `created_at`, `updated_at`) VALUES ('76', 'vel', '2015-05-18 12:40:03', '2016-11-21 01:44:36');
INSERT INTO `media_types` (`id`, `name`, `created_at`, `updated_at`) VALUES ('77', 'est', '1984-03-20 16:38:28', '1979-06-25 12:25:52');
INSERT INTO `media_types` (`id`, `name`, `created_at`, `updated_at`) VALUES ('78', 'vitae', '1973-09-22 08:09:29', '2013-06-09 13:12:10');
INSERT INTO `media_types` (`id`, `name`, `created_at`, `updated_at`) VALUES ('79', 'et', '1979-04-19 18:55:52', '2006-08-01 17:04:25');
INSERT INTO `media_types` (`id`, `name`, `created_at`, `updated_at`) VALUES ('80', 'sit', '1990-06-28 10:45:16', '1977-02-10 20:50:10');
INSERT INTO `media_types` (`id`, `name`, `created_at`, `updated_at`) VALUES ('81', 'eius', '2014-08-26 18:36:19', '1997-04-12 04:44:43');
INSERT INTO `media_types` (`id`, `name`, `created_at`, `updated_at`) VALUES ('82', 'sunt', '1978-06-13 17:43:30', '2016-03-30 05:24:21');
INSERT INTO `media_types` (`id`, `name`, `created_at`, `updated_at`) VALUES ('83', 'fuga', '1981-06-25 20:50:47', '2001-10-19 20:40:38');
INSERT INTO `media_types` (`id`, `name`, `created_at`, `updated_at`) VALUES ('84', 'amet', '1996-01-19 21:23:32', '1979-11-08 00:41:05');
INSERT INTO `media_types` (`id`, `name`, `created_at`, `updated_at`) VALUES ('85', 'consequatur', '2004-12-26 20:04:32', '1992-09-12 11:17:26');
INSERT INTO `media_types` (`id`, `name`, `created_at`, `updated_at`) VALUES ('86', 'molestiae', '1990-09-10 21:18:21', '2012-05-15 07:10:06');
INSERT INTO `media_types` (`id`, `name`, `created_at`, `updated_at`) VALUES ('87', 'nulla', '2004-07-10 22:43:25', '2018-07-03 20:05:47');
INSERT INTO `media_types` (`id`, `name`, `created_at`, `updated_at`) VALUES ('88', 'minus', '2008-09-04 22:19:35', '1973-04-13 21:55:48');
INSERT INTO `media_types` (`id`, `name`, `created_at`, `updated_at`) VALUES ('89', 'neque', '1992-09-15 19:04:59', '1993-09-05 21:26:27');
INSERT INTO `media_types` (`id`, `name`, `created_at`, `updated_at`) VALUES ('90', 'illum', '2017-08-16 10:37:43', '2014-10-08 15:38:08');
INSERT INTO `media_types` (`id`, `name`, `created_at`, `updated_at`) VALUES ('91', 'illum', '1992-06-17 06:44:07', '2008-02-03 01:07:58');
INSERT INTO `media_types` (`id`, `name`, `created_at`, `updated_at`) VALUES ('92', 'quasi', '1997-03-21 11:11:05', '2010-11-29 02:47:44');
INSERT INTO `media_types` (`id`, `name`, `created_at`, `updated_at`) VALUES ('93', 'ut', '1980-05-24 21:09:23', '2007-09-15 06:14:54');
INSERT INTO `media_types` (`id`, `name`, `created_at`, `updated_at`) VALUES ('94', 'reiciendis', '2013-11-06 21:20:49', '1970-08-05 18:38:12');
INSERT INTO `media_types` (`id`, `name`, `created_at`, `updated_at`) VALUES ('95', 'maxime', '1974-07-29 21:57:20', '1983-04-17 22:07:37');
INSERT INTO `media_types` (`id`, `name`, `created_at`, `updated_at`) VALUES ('96', 'quis', '1980-04-14 07:08:54', '1988-06-16 01:13:33');
INSERT INTO `media_types` (`id`, `name`, `created_at`, `updated_at`) VALUES ('97', 'voluptatibus', '2008-01-10 22:22:22', '1990-05-20 22:44:56');
INSERT INTO `media_types` (`id`, `name`, `created_at`, `updated_at`) VALUES ('98', 'quam', '1995-02-11 15:46:23', '1982-08-08 10:39:59');
INSERT INTO `media_types` (`id`, `name`, `created_at`, `updated_at`) VALUES ('99', 'possimus', '1997-07-02 17:17:39', '1989-03-06 17:52:17');
INSERT INTO `media_types` (`id`, `name`, `created_at`, `updated_at`) VALUES ('100', 'quia', '2019-01-20 15:13:20', '1980-04-20 18:47:37');


#
# TABLE STRUCTURE FOR: photo_album
#

DROP TABLE IF EXISTS `photo_album`;

CREATE TABLE `photo_album` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `name` varchar(100) COLLATE utf8_unicode_ci DEFAULT NULL,
  `hotel_id` bigint(20) unsigned DEFAULT NULL,
  `date` date DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `hotel_id` (`hotel_id`),
  CONSTRAINT `photo_album_ibfk_1` FOREIGN KEY (`hotel_id`) REFERENCES `hotels` (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=101 DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

INSERT INTO `photo_album` (`id`, `name`, `hotel_id`, `date`) VALUES ('1', 'voluptatem', '1', '2012-06-06');
INSERT INTO `photo_album` (`id`, `name`, `hotel_id`, `date`) VALUES ('2', 'quidem', '2', '2013-09-11');
INSERT INTO `photo_album` (`id`, `name`, `hotel_id`, `date`) VALUES ('3', 'et', '3', '1994-07-25');
INSERT INTO `photo_album` (`id`, `name`, `hotel_id`, `date`) VALUES ('4', 'velit', '4', '1974-09-14');
INSERT INTO `photo_album` (`id`, `name`, `hotel_id`, `date`) VALUES ('5', 'accusamus', '5', '1973-11-02');
INSERT INTO `photo_album` (`id`, `name`, `hotel_id`, `date`) VALUES ('6', 'molestiae', '6', '2006-11-17');
INSERT INTO `photo_album` (`id`, `name`, `hotel_id`, `date`) VALUES ('7', 'quisquam', '7', '1972-09-21');
INSERT INTO `photo_album` (`id`, `name`, `hotel_id`, `date`) VALUES ('8', 'necessitatibus', '8', '2012-05-12');
INSERT INTO `photo_album` (`id`, `name`, `hotel_id`, `date`) VALUES ('9', 'pariatur', '9', '1979-09-15');
INSERT INTO `photo_album` (`id`, `name`, `hotel_id`, `date`) VALUES ('10', 'omnis', '10', '1996-12-26');
INSERT INTO `photo_album` (`id`, `name`, `hotel_id`, `date`) VALUES ('11', 'molestiae', '11', '2011-02-07');
INSERT INTO `photo_album` (`id`, `name`, `hotel_id`, `date`) VALUES ('12', 'voluptas', '12', '1986-04-05');
INSERT INTO `photo_album` (`id`, `name`, `hotel_id`, `date`) VALUES ('13', 'iusto', '13', '1974-09-18');
INSERT INTO `photo_album` (`id`, `name`, `hotel_id`, `date`) VALUES ('14', 'dolores', '14', '1974-09-25');
INSERT INTO `photo_album` (`id`, `name`, `hotel_id`, `date`) VALUES ('15', 'a', '15', '1999-12-21');
INSERT INTO `photo_album` (`id`, `name`, `hotel_id`, `date`) VALUES ('16', 'ea', '16', '1988-05-10');
INSERT INTO `photo_album` (`id`, `name`, `hotel_id`, `date`) VALUES ('17', 'eaque', '17', '2004-03-08');
INSERT INTO `photo_album` (`id`, `name`, `hotel_id`, `date`) VALUES ('18', 'facere', '18', '2015-01-13');
INSERT INTO `photo_album` (`id`, `name`, `hotel_id`, `date`) VALUES ('19', 'illo', '19', '1971-12-26');
INSERT INTO `photo_album` (`id`, `name`, `hotel_id`, `date`) VALUES ('20', 'cumque', '20', '1982-01-04');
INSERT INTO `photo_album` (`id`, `name`, `hotel_id`, `date`) VALUES ('21', 'ipsam', '21', '1972-09-24');
INSERT INTO `photo_album` (`id`, `name`, `hotel_id`, `date`) VALUES ('22', 'earum', '22', '2000-09-06');
INSERT INTO `photo_album` (`id`, `name`, `hotel_id`, `date`) VALUES ('23', 'qui', '23', '1990-08-29');
INSERT INTO `photo_album` (`id`, `name`, `hotel_id`, `date`) VALUES ('24', 'saepe', '24', '2012-02-22');
INSERT INTO `photo_album` (`id`, `name`, `hotel_id`, `date`) VALUES ('25', 'voluptatem', '25', '2005-08-26');
INSERT INTO `photo_album` (`id`, `name`, `hotel_id`, `date`) VALUES ('26', 'voluptatibus', '26', '1996-08-22');
INSERT INTO `photo_album` (`id`, `name`, `hotel_id`, `date`) VALUES ('27', 'voluptatem', '27', '1970-10-04');
INSERT INTO `photo_album` (`id`, `name`, `hotel_id`, `date`) VALUES ('28', 'quos', '28', '2011-08-02');
INSERT INTO `photo_album` (`id`, `name`, `hotel_id`, `date`) VALUES ('29', 'quia', '29', '1974-04-01');
INSERT INTO `photo_album` (`id`, `name`, `hotel_id`, `date`) VALUES ('30', 'qui', '30', '1999-09-15');
INSERT INTO `photo_album` (`id`, `name`, `hotel_id`, `date`) VALUES ('31', 'neque', '31', '2008-10-28');
INSERT INTO `photo_album` (`id`, `name`, `hotel_id`, `date`) VALUES ('32', 'error', '32', '2015-08-02');
INSERT INTO `photo_album` (`id`, `name`, `hotel_id`, `date`) VALUES ('33', 'voluptas', '33', '1978-09-23');
INSERT INTO `photo_album` (`id`, `name`, `hotel_id`, `date`) VALUES ('34', 'laudantium', '34', '1981-02-01');
INSERT INTO `photo_album` (`id`, `name`, `hotel_id`, `date`) VALUES ('35', 'molestias', '35', '1981-03-12');
INSERT INTO `photo_album` (`id`, `name`, `hotel_id`, `date`) VALUES ('36', 'omnis', '36', '2017-09-25');
INSERT INTO `photo_album` (`id`, `name`, `hotel_id`, `date`) VALUES ('37', 'et', '37', '2017-05-01');
INSERT INTO `photo_album` (`id`, `name`, `hotel_id`, `date`) VALUES ('38', 'optio', '38', '2008-02-28');
INSERT INTO `photo_album` (`id`, `name`, `hotel_id`, `date`) VALUES ('39', 'qui', '39', '1989-10-21');
INSERT INTO `photo_album` (`id`, `name`, `hotel_id`, `date`) VALUES ('40', 'omnis', '40', '1984-07-29');
INSERT INTO `photo_album` (`id`, `name`, `hotel_id`, `date`) VALUES ('41', 'doloremque', '41', '2014-03-20');
INSERT INTO `photo_album` (`id`, `name`, `hotel_id`, `date`) VALUES ('42', 'nulla', '42', '1997-01-23');
INSERT INTO `photo_album` (`id`, `name`, `hotel_id`, `date`) VALUES ('43', 'at', '43', '1994-03-09');
INSERT INTO `photo_album` (`id`, `name`, `hotel_id`, `date`) VALUES ('44', 'quos', '44', '2001-04-08');
INSERT INTO `photo_album` (`id`, `name`, `hotel_id`, `date`) VALUES ('45', 'voluptatem', '45', '1979-08-27');
INSERT INTO `photo_album` (`id`, `name`, `hotel_id`, `date`) VALUES ('46', 'nam', '46', '1971-11-25');
INSERT INTO `photo_album` (`id`, `name`, `hotel_id`, `date`) VALUES ('47', 'dolorem', '47', '1984-12-08');
INSERT INTO `photo_album` (`id`, `name`, `hotel_id`, `date`) VALUES ('48', 'ut', '48', '1973-06-04');
INSERT INTO `photo_album` (`id`, `name`, `hotel_id`, `date`) VALUES ('49', 'quod', '49', '2015-12-27');
INSERT INTO `photo_album` (`id`, `name`, `hotel_id`, `date`) VALUES ('50', 'pariatur', '50', '2012-04-13');
INSERT INTO `photo_album` (`id`, `name`, `hotel_id`, `date`) VALUES ('51', 'tempore', '51', '1986-05-09');
INSERT INTO `photo_album` (`id`, `name`, `hotel_id`, `date`) VALUES ('52', 'animi', '52', '1979-11-14');
INSERT INTO `photo_album` (`id`, `name`, `hotel_id`, `date`) VALUES ('53', 'ipsam', '53', '2015-08-25');
INSERT INTO `photo_album` (`id`, `name`, `hotel_id`, `date`) VALUES ('54', 'ut', '54', '1983-04-13');
INSERT INTO `photo_album` (`id`, `name`, `hotel_id`, `date`) VALUES ('55', 'consequatur', '55', '1982-05-16');
INSERT INTO `photo_album` (`id`, `name`, `hotel_id`, `date`) VALUES ('56', 'aut', '56', '2009-11-15');
INSERT INTO `photo_album` (`id`, `name`, `hotel_id`, `date`) VALUES ('57', 'maxime', '57', '1993-11-29');
INSERT INTO `photo_album` (`id`, `name`, `hotel_id`, `date`) VALUES ('58', 'tenetur', '58', '1997-03-22');
INSERT INTO `photo_album` (`id`, `name`, `hotel_id`, `date`) VALUES ('59', 'nobis', '59', '2019-02-18');
INSERT INTO `photo_album` (`id`, `name`, `hotel_id`, `date`) VALUES ('60', 'est', '60', '1981-02-26');
INSERT INTO `photo_album` (`id`, `name`, `hotel_id`, `date`) VALUES ('61', 'voluptas', '61', '1993-07-28');
INSERT INTO `photo_album` (`id`, `name`, `hotel_id`, `date`) VALUES ('62', 'ut', '62', '1977-11-10');
INSERT INTO `photo_album` (`id`, `name`, `hotel_id`, `date`) VALUES ('63', 'unde', '63', '1995-03-21');
INSERT INTO `photo_album` (`id`, `name`, `hotel_id`, `date`) VALUES ('64', 'praesentium', '64', '1986-11-06');
INSERT INTO `photo_album` (`id`, `name`, `hotel_id`, `date`) VALUES ('65', 'est', '65', '1998-05-31');
INSERT INTO `photo_album` (`id`, `name`, `hotel_id`, `date`) VALUES ('66', 'quo', '66', '1983-03-04');
INSERT INTO `photo_album` (`id`, `name`, `hotel_id`, `date`) VALUES ('67', 'doloremque', '67', '2012-05-16');
INSERT INTO `photo_album` (`id`, `name`, `hotel_id`, `date`) VALUES ('68', 'ex', '68', '1973-03-22');
INSERT INTO `photo_album` (`id`, `name`, `hotel_id`, `date`) VALUES ('69', 'nisi', '69', '1980-01-14');
INSERT INTO `photo_album` (`id`, `name`, `hotel_id`, `date`) VALUES ('70', 'ratione', '70', '2010-11-18');
INSERT INTO `photo_album` (`id`, `name`, `hotel_id`, `date`) VALUES ('71', 'eaque', '71', '1974-02-07');
INSERT INTO `photo_album` (`id`, `name`, `hotel_id`, `date`) VALUES ('72', 'voluptatem', '72', '1971-10-11');
INSERT INTO `photo_album` (`id`, `name`, `hotel_id`, `date`) VALUES ('73', 'repellat', '73', '1985-01-18');
INSERT INTO `photo_album` (`id`, `name`, `hotel_id`, `date`) VALUES ('74', 'pariatur', '74', '2006-06-23');
INSERT INTO `photo_album` (`id`, `name`, `hotel_id`, `date`) VALUES ('75', 'ducimus', '75', '2000-05-14');
INSERT INTO `photo_album` (`id`, `name`, `hotel_id`, `date`) VALUES ('76', 'officiis', '76', '2010-06-08');
INSERT INTO `photo_album` (`id`, `name`, `hotel_id`, `date`) VALUES ('77', 'iure', '77', '2003-08-30');
INSERT INTO `photo_album` (`id`, `name`, `hotel_id`, `date`) VALUES ('78', 'voluptas', '78', '2001-11-30');
INSERT INTO `photo_album` (`id`, `name`, `hotel_id`, `date`) VALUES ('79', 'autem', '79', '2003-11-23');
INSERT INTO `photo_album` (`id`, `name`, `hotel_id`, `date`) VALUES ('80', 'dolores', '80', '1982-10-13');
INSERT INTO `photo_album` (`id`, `name`, `hotel_id`, `date`) VALUES ('81', 'quis', '81', '1988-11-14');
INSERT INTO `photo_album` (`id`, `name`, `hotel_id`, `date`) VALUES ('82', 'repudiandae', '82', '1989-04-08');
INSERT INTO `photo_album` (`id`, `name`, `hotel_id`, `date`) VALUES ('83', 'accusamus', '83', '1992-06-06');
INSERT INTO `photo_album` (`id`, `name`, `hotel_id`, `date`) VALUES ('84', 'incidunt', '84', '1981-09-30');
INSERT INTO `photo_album` (`id`, `name`, `hotel_id`, `date`) VALUES ('85', 'non', '85', '1970-01-12');
INSERT INTO `photo_album` (`id`, `name`, `hotel_id`, `date`) VALUES ('86', 'sunt', '86', '2000-10-21');
INSERT INTO `photo_album` (`id`, `name`, `hotel_id`, `date`) VALUES ('87', 'omnis', '87', '1990-09-16');
INSERT INTO `photo_album` (`id`, `name`, `hotel_id`, `date`) VALUES ('88', 'quas', '88', '2001-12-20');
INSERT INTO `photo_album` (`id`, `name`, `hotel_id`, `date`) VALUES ('89', 'dolores', '89', '1988-08-19');
INSERT INTO `photo_album` (`id`, `name`, `hotel_id`, `date`) VALUES ('90', 'deserunt', '90', '2012-04-26');
INSERT INTO `photo_album` (`id`, `name`, `hotel_id`, `date`) VALUES ('91', 'minus', '91', '1991-05-12');
INSERT INTO `photo_album` (`id`, `name`, `hotel_id`, `date`) VALUES ('92', 'vero', '92', '2011-09-14');
INSERT INTO `photo_album` (`id`, `name`, `hotel_id`, `date`) VALUES ('93', 'rerum', '93', '1990-02-09');
INSERT INTO `photo_album` (`id`, `name`, `hotel_id`, `date`) VALUES ('94', 'quam', '94', '1999-12-26');
INSERT INTO `photo_album` (`id`, `name`, `hotel_id`, `date`) VALUES ('95', 'soluta', '95', '1970-01-05');
INSERT INTO `photo_album` (`id`, `name`, `hotel_id`, `date`) VALUES ('96', 'et', '96', '1977-10-06');
INSERT INTO `photo_album` (`id`, `name`, `hotel_id`, `date`) VALUES ('97', 'nostrum', '97', '2015-03-16');
INSERT INTO `photo_album` (`id`, `name`, `hotel_id`, `date`) VALUES ('98', 'blanditiis', '98', '1986-03-08');
INSERT INTO `photo_album` (`id`, `name`, `hotel_id`, `date`) VALUES ('99', 'quod', '99', '1981-03-29');
INSERT INTO `photo_album` (`id`, `name`, `hotel_id`, `date`) VALUES ('100', 'corporis', '100', '1985-02-15');


#
# TABLE STRUCTURE FOR: photos
#

DROP TABLE IF EXISTS `photos`;

CREATE TABLE `photos` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `album_id` bigint(20) unsigned NOT NULL,
  `media_types_id` bigint(20) unsigned NOT NULL,
  `date` date DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `album_id` (`album_id`),
  KEY `media_types_id` (`media_types_id`),
  CONSTRAINT `photos_ibfk_1` FOREIGN KEY (`album_id`) REFERENCES `photo_album` (`id`),
  CONSTRAINT `photos_ibfk_2` FOREIGN KEY (`media_types_id`) REFERENCES `media_types` (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=101 DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

INSERT INTO `photos` (`id`, `album_id`, `media_types_id`, `date`) VALUES ('1', '1', '1', '1990-07-07');
INSERT INTO `photos` (`id`, `album_id`, `media_types_id`, `date`) VALUES ('2', '2', '2', '1989-08-14');
INSERT INTO `photos` (`id`, `album_id`, `media_types_id`, `date`) VALUES ('3', '3', '3', '1970-04-24');
INSERT INTO `photos` (`id`, `album_id`, `media_types_id`, `date`) VALUES ('4', '4', '4', '1981-08-01');
INSERT INTO `photos` (`id`, `album_id`, `media_types_id`, `date`) VALUES ('5', '5', '5', '1973-06-04');
INSERT INTO `photos` (`id`, `album_id`, `media_types_id`, `date`) VALUES ('6', '6', '6', '1979-12-21');
INSERT INTO `photos` (`id`, `album_id`, `media_types_id`, `date`) VALUES ('7', '7', '7', '2001-07-18');
INSERT INTO `photos` (`id`, `album_id`, `media_types_id`, `date`) VALUES ('8', '8', '8', '2000-06-24');
INSERT INTO `photos` (`id`, `album_id`, `media_types_id`, `date`) VALUES ('9', '9', '9', '1998-08-02');
INSERT INTO `photos` (`id`, `album_id`, `media_types_id`, `date`) VALUES ('10', '10', '10', '1996-10-10');
INSERT INTO `photos` (`id`, `album_id`, `media_types_id`, `date`) VALUES ('11', '11', '11', '1984-06-05');
INSERT INTO `photos` (`id`, `album_id`, `media_types_id`, `date`) VALUES ('12', '12', '12', '2018-12-10');
INSERT INTO `photos` (`id`, `album_id`, `media_types_id`, `date`) VALUES ('13', '13', '13', '1973-01-21');
INSERT INTO `photos` (`id`, `album_id`, `media_types_id`, `date`) VALUES ('14', '14', '14', '1994-12-25');
INSERT INTO `photos` (`id`, `album_id`, `media_types_id`, `date`) VALUES ('15', '15', '15', '2015-08-13');
INSERT INTO `photos` (`id`, `album_id`, `media_types_id`, `date`) VALUES ('16', '16', '16', '1987-10-22');
INSERT INTO `photos` (`id`, `album_id`, `media_types_id`, `date`) VALUES ('17', '17', '17', '1970-10-19');
INSERT INTO `photos` (`id`, `album_id`, `media_types_id`, `date`) VALUES ('18', '18', '18', '2011-01-28');
INSERT INTO `photos` (`id`, `album_id`, `media_types_id`, `date`) VALUES ('19', '19', '19', '1998-06-02');
INSERT INTO `photos` (`id`, `album_id`, `media_types_id`, `date`) VALUES ('20', '20', '20', '2006-03-09');
INSERT INTO `photos` (`id`, `album_id`, `media_types_id`, `date`) VALUES ('21', '21', '21', '1986-10-29');
INSERT INTO `photos` (`id`, `album_id`, `media_types_id`, `date`) VALUES ('22', '22', '22', '2012-08-24');
INSERT INTO `photos` (`id`, `album_id`, `media_types_id`, `date`) VALUES ('23', '23', '23', '2010-05-22');
INSERT INTO `photos` (`id`, `album_id`, `media_types_id`, `date`) VALUES ('24', '24', '24', '2016-08-02');
INSERT INTO `photos` (`id`, `album_id`, `media_types_id`, `date`) VALUES ('25', '25', '25', '1983-01-05');
INSERT INTO `photos` (`id`, `album_id`, `media_types_id`, `date`) VALUES ('26', '26', '26', '1991-04-22');
INSERT INTO `photos` (`id`, `album_id`, `media_types_id`, `date`) VALUES ('27', '27', '27', '2003-07-20');
INSERT INTO `photos` (`id`, `album_id`, `media_types_id`, `date`) VALUES ('28', '28', '28', '1988-10-06');
INSERT INTO `photos` (`id`, `album_id`, `media_types_id`, `date`) VALUES ('29', '29', '29', '1993-04-14');
INSERT INTO `photos` (`id`, `album_id`, `media_types_id`, `date`) VALUES ('30', '30', '30', '1978-04-02');
INSERT INTO `photos` (`id`, `album_id`, `media_types_id`, `date`) VALUES ('31', '31', '31', '2009-09-01');
INSERT INTO `photos` (`id`, `album_id`, `media_types_id`, `date`) VALUES ('32', '32', '32', '2009-02-06');
INSERT INTO `photos` (`id`, `album_id`, `media_types_id`, `date`) VALUES ('33', '33', '33', '1999-01-31');
INSERT INTO `photos` (`id`, `album_id`, `media_types_id`, `date`) VALUES ('34', '34', '34', '1997-02-17');
INSERT INTO `photos` (`id`, `album_id`, `media_types_id`, `date`) VALUES ('35', '35', '35', '2007-03-20');
INSERT INTO `photos` (`id`, `album_id`, `media_types_id`, `date`) VALUES ('36', '36', '36', '1998-08-11');
INSERT INTO `photos` (`id`, `album_id`, `media_types_id`, `date`) VALUES ('37', '37', '37', '1982-06-29');
INSERT INTO `photos` (`id`, `album_id`, `media_types_id`, `date`) VALUES ('38', '38', '38', '1995-01-04');
INSERT INTO `photos` (`id`, `album_id`, `media_types_id`, `date`) VALUES ('39', '39', '39', '2016-07-18');
INSERT INTO `photos` (`id`, `album_id`, `media_types_id`, `date`) VALUES ('40', '40', '40', '1991-08-01');
INSERT INTO `photos` (`id`, `album_id`, `media_types_id`, `date`) VALUES ('41', '41', '41', '2017-03-04');
INSERT INTO `photos` (`id`, `album_id`, `media_types_id`, `date`) VALUES ('42', '42', '42', '1996-07-13');
INSERT INTO `photos` (`id`, `album_id`, `media_types_id`, `date`) VALUES ('43', '43', '43', '2012-06-08');
INSERT INTO `photos` (`id`, `album_id`, `media_types_id`, `date`) VALUES ('44', '44', '44', '1993-03-10');
INSERT INTO `photos` (`id`, `album_id`, `media_types_id`, `date`) VALUES ('45', '45', '45', '1999-07-07');
INSERT INTO `photos` (`id`, `album_id`, `media_types_id`, `date`) VALUES ('46', '46', '46', '1977-07-27');
INSERT INTO `photos` (`id`, `album_id`, `media_types_id`, `date`) VALUES ('47', '47', '47', '1970-02-11');
INSERT INTO `photos` (`id`, `album_id`, `media_types_id`, `date`) VALUES ('48', '48', '48', '2004-01-12');
INSERT INTO `photos` (`id`, `album_id`, `media_types_id`, `date`) VALUES ('49', '49', '49', '2000-12-02');
INSERT INTO `photos` (`id`, `album_id`, `media_types_id`, `date`) VALUES ('50', '50', '50', '1991-12-26');
INSERT INTO `photos` (`id`, `album_id`, `media_types_id`, `date`) VALUES ('51', '51', '51', '2006-04-03');
INSERT INTO `photos` (`id`, `album_id`, `media_types_id`, `date`) VALUES ('52', '52', '52', '1990-12-16');
INSERT INTO `photos` (`id`, `album_id`, `media_types_id`, `date`) VALUES ('53', '53', '53', '1973-10-27');
INSERT INTO `photos` (`id`, `album_id`, `media_types_id`, `date`) VALUES ('54', '54', '54', '2005-11-14');
INSERT INTO `photos` (`id`, `album_id`, `media_types_id`, `date`) VALUES ('55', '55', '55', '2000-01-14');
INSERT INTO `photos` (`id`, `album_id`, `media_types_id`, `date`) VALUES ('56', '56', '56', '1987-05-19');
INSERT INTO `photos` (`id`, `album_id`, `media_types_id`, `date`) VALUES ('57', '57', '57', '1992-06-30');
INSERT INTO `photos` (`id`, `album_id`, `media_types_id`, `date`) VALUES ('58', '58', '58', '1989-09-27');
INSERT INTO `photos` (`id`, `album_id`, `media_types_id`, `date`) VALUES ('59', '59', '59', '1990-11-21');
INSERT INTO `photos` (`id`, `album_id`, `media_types_id`, `date`) VALUES ('60', '60', '60', '1975-11-10');
INSERT INTO `photos` (`id`, `album_id`, `media_types_id`, `date`) VALUES ('61', '61', '61', '2000-04-08');
INSERT INTO `photos` (`id`, `album_id`, `media_types_id`, `date`) VALUES ('62', '62', '62', '1998-11-20');
INSERT INTO `photos` (`id`, `album_id`, `media_types_id`, `date`) VALUES ('63', '63', '63', '1973-01-22');
INSERT INTO `photos` (`id`, `album_id`, `media_types_id`, `date`) VALUES ('64', '64', '64', '2018-10-01');
INSERT INTO `photos` (`id`, `album_id`, `media_types_id`, `date`) VALUES ('65', '65', '65', '1992-12-17');
INSERT INTO `photos` (`id`, `album_id`, `media_types_id`, `date`) VALUES ('66', '66', '66', '1981-03-24');
INSERT INTO `photos` (`id`, `album_id`, `media_types_id`, `date`) VALUES ('67', '67', '67', '2011-10-31');
INSERT INTO `photos` (`id`, `album_id`, `media_types_id`, `date`) VALUES ('68', '68', '68', '1997-06-28');
INSERT INTO `photos` (`id`, `album_id`, `media_types_id`, `date`) VALUES ('69', '69', '69', '1990-08-13');
INSERT INTO `photos` (`id`, `album_id`, `media_types_id`, `date`) VALUES ('70', '70', '70', '1997-01-29');
INSERT INTO `photos` (`id`, `album_id`, `media_types_id`, `date`) VALUES ('71', '71', '71', '1977-08-02');
INSERT INTO `photos` (`id`, `album_id`, `media_types_id`, `date`) VALUES ('72', '72', '72', '1981-03-13');
INSERT INTO `photos` (`id`, `album_id`, `media_types_id`, `date`) VALUES ('73', '73', '73', '2013-12-24');
INSERT INTO `photos` (`id`, `album_id`, `media_types_id`, `date`) VALUES ('74', '74', '74', '2010-06-08');
INSERT INTO `photos` (`id`, `album_id`, `media_types_id`, `date`) VALUES ('75', '75', '75', '2006-01-18');
INSERT INTO `photos` (`id`, `album_id`, `media_types_id`, `date`) VALUES ('76', '76', '76', '2005-05-02');
INSERT INTO `photos` (`id`, `album_id`, `media_types_id`, `date`) VALUES ('77', '77', '77', '1977-09-11');
INSERT INTO `photos` (`id`, `album_id`, `media_types_id`, `date`) VALUES ('78', '78', '78', '2003-09-26');
INSERT INTO `photos` (`id`, `album_id`, `media_types_id`, `date`) VALUES ('79', '79', '79', '2018-06-12');
INSERT INTO `photos` (`id`, `album_id`, `media_types_id`, `date`) VALUES ('80', '80', '80', '1979-06-11');
INSERT INTO `photos` (`id`, `album_id`, `media_types_id`, `date`) VALUES ('81', '81', '81', '1976-07-19');
INSERT INTO `photos` (`id`, `album_id`, `media_types_id`, `date`) VALUES ('82', '82', '82', '1975-06-18');
INSERT INTO `photos` (`id`, `album_id`, `media_types_id`, `date`) VALUES ('83', '83', '83', '2002-09-05');
INSERT INTO `photos` (`id`, `album_id`, `media_types_id`, `date`) VALUES ('84', '84', '84', '1973-05-28');
INSERT INTO `photos` (`id`, `album_id`, `media_types_id`, `date`) VALUES ('85', '85', '85', '2000-06-23');
INSERT INTO `photos` (`id`, `album_id`, `media_types_id`, `date`) VALUES ('86', '86', '86', '2019-10-21');
INSERT INTO `photos` (`id`, `album_id`, `media_types_id`, `date`) VALUES ('87', '87', '87', '2012-03-03');
INSERT INTO `photos` (`id`, `album_id`, `media_types_id`, `date`) VALUES ('88', '88', '88', '1977-12-27');
INSERT INTO `photos` (`id`, `album_id`, `media_types_id`, `date`) VALUES ('89', '89', '89', '1997-08-31');
INSERT INTO `photos` (`id`, `album_id`, `media_types_id`, `date`) VALUES ('90', '90', '90', '2010-01-15');
INSERT INTO `photos` (`id`, `album_id`, `media_types_id`, `date`) VALUES ('91', '91', '91', '1988-11-15');
INSERT INTO `photos` (`id`, `album_id`, `media_types_id`, `date`) VALUES ('92', '92', '92', '1975-08-17');
INSERT INTO `photos` (`id`, `album_id`, `media_types_id`, `date`) VALUES ('93', '93', '93', '1980-08-05');
INSERT INTO `photos` (`id`, `album_id`, `media_types_id`, `date`) VALUES ('94', '94', '94', '1970-09-13');
INSERT INTO `photos` (`id`, `album_id`, `media_types_id`, `date`) VALUES ('95', '95', '95', '1997-05-03');
INSERT INTO `photos` (`id`, `album_id`, `media_types_id`, `date`) VALUES ('96', '96', '96', '1981-05-01');
INSERT INTO `photos` (`id`, `album_id`, `media_types_id`, `date`) VALUES ('97', '97', '97', '2008-08-22');
INSERT INTO `photos` (`id`, `album_id`, `media_types_id`, `date`) VALUES ('98', '98', '98', '1971-12-27');
INSERT INTO `photos` (`id`, `album_id`, `media_types_id`, `date`) VALUES ('99', '99', '99', '1977-11-12');
INSERT INTO `photos` (`id`, `album_id`, `media_types_id`, `date`) VALUES ('100', '100', '100', '1992-05-15');


#
# TABLE STRUCTURE FOR: profiles
#

DROP TABLE IF EXISTS `profiles`;

CREATE TABLE `profiles` (
  `user_id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `gender` char(1) COLLATE utf8_unicode_ci DEFAULT NULL,
  `birthday` date DEFAULT NULL,
  `created_at` datetime DEFAULT current_timestamp(),
  `hometown` varchar(100) COLLATE utf8_unicode_ci DEFAULT NULL,
  PRIMARY KEY (`user_id`),
  CONSTRAINT `profiles_ibfk_1` FOREIGN KEY (`user_id`) REFERENCES `users` (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=201 DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

INSERT INTO `profiles` (`user_id`, `gender`, `birthday`, `created_at`, `hometown`) VALUES ('101', 'P', '1980-08-11', '1997-05-29 23:42:06', 'Port');
INSERT INTO `profiles` (`user_id`, `gender`, `birthday`, `created_at`, `hometown`) VALUES ('102', 'D', '1973-05-14', '1986-01-29 15:56:17', 'South');
INSERT INTO `profiles` (`user_id`, `gender`, `birthday`, `created_at`, `hometown`) VALUES ('103', 'M', '2009-09-08', '1972-02-29 16:56:02', 'New');
INSERT INTO `profiles` (`user_id`, `gender`, `birthday`, `created_at`, `hometown`) VALUES ('104', 'M', '1981-08-22', '1999-08-20 21:28:03', 'North');
INSERT INTO `profiles` (`user_id`, `gender`, `birthday`, `created_at`, `hometown`) VALUES ('105', 'M', '1972-09-07', '1975-11-14 12:06:04', 'Port');
INSERT INTO `profiles` (`user_id`, `gender`, `birthday`, `created_at`, `hometown`) VALUES ('106', 'M', '1979-06-22', '1988-07-26 08:19:24', 'New');
INSERT INTO `profiles` (`user_id`, `gender`, `birthday`, `created_at`, `hometown`) VALUES ('107', 'P', '1970-10-08', '2008-03-11 13:52:36', 'South');
INSERT INTO `profiles` (`user_id`, `gender`, `birthday`, `created_at`, `hometown`) VALUES ('108', 'M', '1974-10-11', '1971-08-06 09:42:09', 'East');
INSERT INTO `profiles` (`user_id`, `gender`, `birthday`, `created_at`, `hometown`) VALUES ('109', 'P', '2013-04-09', '1989-09-25 21:33:00', 'Lake');
INSERT INTO `profiles` (`user_id`, `gender`, `birthday`, `created_at`, `hometown`) VALUES ('110', 'D', '1971-04-26', '1987-11-14 03:12:54', 'Lake');
INSERT INTO `profiles` (`user_id`, `gender`, `birthday`, `created_at`, `hometown`) VALUES ('112', 'M', '2010-10-26', '1997-01-24 06:10:29', 'New');
INSERT INTO `profiles` (`user_id`, `gender`, `birthday`, `created_at`, `hometown`) VALUES ('114', 'M', '1974-06-18', '2005-07-27 22:53:43', 'Lake');
INSERT INTO `profiles` (`user_id`, `gender`, `birthday`, `created_at`, `hometown`) VALUES ('115', 'D', '1998-01-17', '2004-09-13 23:33:01', 'New');
INSERT INTO `profiles` (`user_id`, `gender`, `birthday`, `created_at`, `hometown`) VALUES ('116', 'P', '2012-12-05', '1986-04-05 17:59:05', 'East');
INSERT INTO `profiles` (`user_id`, `gender`, `birthday`, `created_at`, `hometown`) VALUES ('118', 'M', '1983-12-13', '1992-10-02 19:34:26', 'West');
INSERT INTO `profiles` (`user_id`, `gender`, `birthday`, `created_at`, `hometown`) VALUES ('120', 'P', '2018-10-28', '1979-01-03 02:15:44', 'New');
INSERT INTO `profiles` (`user_id`, `gender`, `birthday`, `created_at`, `hometown`) VALUES ('124', 'P', '1982-08-30', '1998-05-06 23:15:12', 'East');
INSERT INTO `profiles` (`user_id`, `gender`, `birthday`, `created_at`, `hometown`) VALUES ('126', 'M', '2018-09-13', '1986-07-10 10:14:43', 'Lake');
INSERT INTO `profiles` (`user_id`, `gender`, `birthday`, `created_at`, `hometown`) VALUES ('127', 'M', '2012-02-16', '2004-12-04 03:47:00', 'Port');
INSERT INTO `profiles` (`user_id`, `gender`, `birthday`, `created_at`, `hometown`) VALUES ('128', 'M', '1971-04-14', '1999-07-13 04:39:21', 'Lake');
INSERT INTO `profiles` (`user_id`, `gender`, `birthday`, `created_at`, `hometown`) VALUES ('134', 'D', '1994-08-12', '1986-01-22 23:08:17', 'North');
INSERT INTO `profiles` (`user_id`, `gender`, `birthday`, `created_at`, `hometown`) VALUES ('137', 'M', '1996-04-28', '1994-07-20 22:26:10', 'West');
INSERT INTO `profiles` (`user_id`, `gender`, `birthday`, `created_at`, `hometown`) VALUES ('138', 'M', '1985-05-05', '1998-11-11 11:13:13', 'East');
INSERT INTO `profiles` (`user_id`, `gender`, `birthday`, `created_at`, `hometown`) VALUES ('140', 'M', '1987-04-16', '2010-05-04 00:39:42', 'West');
INSERT INTO `profiles` (`user_id`, `gender`, `birthday`, `created_at`, `hometown`) VALUES ('145', 'P', '2017-09-02', '1992-11-22 08:56:28', 'Port');
INSERT INTO `profiles` (`user_id`, `gender`, `birthday`, `created_at`, `hometown`) VALUES ('146', 'M', '2007-06-20', '1999-05-15 17:58:14', 'Port');
INSERT INTO `profiles` (`user_id`, `gender`, `birthday`, `created_at`, `hometown`) VALUES ('147', 'P', '1997-07-27', '1998-06-28 06:50:07', 'West');
INSERT INTO `profiles` (`user_id`, `gender`, `birthday`, `created_at`, `hometown`) VALUES ('148', 'D', '2004-09-03', '2008-04-09 03:52:30', 'West');
INSERT INTO `profiles` (`user_id`, `gender`, `birthday`, `created_at`, `hometown`) VALUES ('149', 'M', '1982-01-15', '1973-11-20 09:00:04', 'West');
INSERT INTO `profiles` (`user_id`, `gender`, `birthday`, `created_at`, `hometown`) VALUES ('150', 'P', '2004-06-03', '1994-10-29 04:33:49', 'South');
INSERT INTO `profiles` (`user_id`, `gender`, `birthday`, `created_at`, `hometown`) VALUES ('151', 'D', '1987-03-05', '1995-06-12 21:58:19', 'Port');
INSERT INTO `profiles` (`user_id`, `gender`, `birthday`, `created_at`, `hometown`) VALUES ('152', 'D', '1977-09-20', '1987-07-14 14:01:22', 'North');
INSERT INTO `profiles` (`user_id`, `gender`, `birthday`, `created_at`, `hometown`) VALUES ('153', 'P', '2006-07-03', '1970-09-28 04:46:32', 'North');
INSERT INTO `profiles` (`user_id`, `gender`, `birthday`, `created_at`, `hometown`) VALUES ('154', 'D', '2019-05-25', '2007-01-21 03:16:36', 'South');
INSERT INTO `profiles` (`user_id`, `gender`, `birthday`, `created_at`, `hometown`) VALUES ('155', 'D', '1994-05-25', '1976-05-12 00:28:11', 'New');
INSERT INTO `profiles` (`user_id`, `gender`, `birthday`, `created_at`, `hometown`) VALUES ('157', 'P', '1993-04-17', '2011-11-16 00:36:02', 'South');
INSERT INTO `profiles` (`user_id`, `gender`, `birthday`, `created_at`, `hometown`) VALUES ('159', 'M', '2011-10-20', '1972-05-16 12:37:28', 'East');
INSERT INTO `profiles` (`user_id`, `gender`, `birthday`, `created_at`, `hometown`) VALUES ('160', 'P', '2000-10-26', '1989-10-16 04:02:11', 'East');
INSERT INTO `profiles` (`user_id`, `gender`, `birthday`, `created_at`, `hometown`) VALUES ('161', 'D', '2005-03-03', '1981-08-02 14:53:35', 'West');
INSERT INTO `profiles` (`user_id`, `gender`, `birthday`, `created_at`, `hometown`) VALUES ('165', 'P', '2018-06-18', '2006-07-12 06:38:44', 'New');
INSERT INTO `profiles` (`user_id`, `gender`, `birthday`, `created_at`, `hometown`) VALUES ('168', 'M', '1974-03-29', '1993-01-30 18:53:08', 'South');
INSERT INTO `profiles` (`user_id`, `gender`, `birthday`, `created_at`, `hometown`) VALUES ('170', 'P', '1982-10-31', '2017-02-16 02:16:23', 'Lake');
INSERT INTO `profiles` (`user_id`, `gender`, `birthday`, `created_at`, `hometown`) VALUES ('172', 'D', '1973-09-24', '2015-07-24 15:03:16', 'New');
INSERT INTO `profiles` (`user_id`, `gender`, `birthday`, `created_at`, `hometown`) VALUES ('173', 'M', '1993-08-18', '2002-09-08 12:19:26', 'New');
INSERT INTO `profiles` (`user_id`, `gender`, `birthday`, `created_at`, `hometown`) VALUES ('175', 'P', '2015-07-06', '2017-11-20 15:05:23', 'West');
INSERT INTO `profiles` (`user_id`, `gender`, `birthday`, `created_at`, `hometown`) VALUES ('176', 'M', '2013-12-16', '2019-07-06 03:22:23', 'East');
INSERT INTO `profiles` (`user_id`, `gender`, `birthday`, `created_at`, `hometown`) VALUES ('177', 'M', '2003-04-10', '1998-08-23 04:41:52', 'North');
INSERT INTO `profiles` (`user_id`, `gender`, `birthday`, `created_at`, `hometown`) VALUES ('179', 'P', '1984-09-05', '1999-09-10 00:48:28', 'North');
INSERT INTO `profiles` (`user_id`, `gender`, `birthday`, `created_at`, `hometown`) VALUES ('181', 'P', '2001-06-13', '1974-07-18 12:15:37', 'North');
INSERT INTO `profiles` (`user_id`, `gender`, `birthday`, `created_at`, `hometown`) VALUES ('182', 'P', '1996-07-10', '1992-02-07 14:45:29', 'West');
INSERT INTO `profiles` (`user_id`, `gender`, `birthday`, `created_at`, `hometown`) VALUES ('183', 'D', '1996-01-21', '2018-05-16 13:22:31', 'Port');
INSERT INTO `profiles` (`user_id`, `gender`, `birthday`, `created_at`, `hometown`) VALUES ('184', 'M', '1977-10-14', '1986-10-31 05:55:07', 'East');
INSERT INTO `profiles` (`user_id`, `gender`, `birthday`, `created_at`, `hometown`) VALUES ('187', 'M', '2002-02-07', '1999-10-25 10:11:04', 'South');
INSERT INTO `profiles` (`user_id`, `gender`, `birthday`, `created_at`, `hometown`) VALUES ('188', 'D', '1977-03-25', '1979-11-24 12:48:18', 'West');
INSERT INTO `profiles` (`user_id`, `gender`, `birthday`, `created_at`, `hometown`) VALUES ('189', 'D', '2014-08-09', '2014-06-16 00:21:00', 'Lake');
INSERT INTO `profiles` (`user_id`, `gender`, `birthday`, `created_at`, `hometown`) VALUES ('191', 'M', '2016-03-04', '1973-02-20 21:54:52', 'North');
INSERT INTO `profiles` (`user_id`, `gender`, `birthday`, `created_at`, `hometown`) VALUES ('193', 'D', '2016-07-19', '2005-11-30 22:12:59', 'North');
INSERT INTO `profiles` (`user_id`, `gender`, `birthday`, `created_at`, `hometown`) VALUES ('194', 'M', '2010-10-16', '2019-12-27 00:28:44', 'East');
INSERT INTO `profiles` (`user_id`, `gender`, `birthday`, `created_at`, `hometown`) VALUES ('195', 'P', '1972-09-25', '2016-01-12 00:29:49', 'West');
INSERT INTO `profiles` (`user_id`, `gender`, `birthday`, `created_at`, `hometown`) VALUES ('196', 'M', '1980-06-16', '2007-03-11 23:28:33', 'West');
INSERT INTO `profiles` (`user_id`, `gender`, `birthday`, `created_at`, `hometown`) VALUES ('198', 'M', '1979-08-05', '1998-10-03 04:33:07', 'Port');
INSERT INTO `profiles` (`user_id`, `gender`, `birthday`, `created_at`, `hometown`) VALUES ('199', 'M', '2013-11-28', '2010-04-23 05:33:13', 'South');


#
# TABLE STRUCTURE FOR: room_type
#

DROP TABLE IF EXISTS `room_type`;

CREATE TABLE `room_type` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `name` varchar(20) COLLATE utf8_unicode_ci DEFAULT NULL,
  `hotel_id` bigint(20) unsigned NOT NULL,
  PRIMARY KEY (`id`),
  KEY `hotel_id` (`hotel_id`),
  CONSTRAINT `room_type_ibfk_1` FOREIGN KEY (`hotel_id`) REFERENCES `hotels` (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=101 DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

INSERT INTO `room_type` (`id`, `name`, `hotel_id`) VALUES ('1', 'corporis', '1');
INSERT INTO `room_type` (`id`, `name`, `hotel_id`) VALUES ('2', 'eveniet', '2');
INSERT INTO `room_type` (`id`, `name`, `hotel_id`) VALUES ('3', 'quo', '3');
INSERT INTO `room_type` (`id`, `name`, `hotel_id`) VALUES ('4', 'aspernatur', '4');
INSERT INTO `room_type` (`id`, `name`, `hotel_id`) VALUES ('5', 'facilis', '5');
INSERT INTO `room_type` (`id`, `name`, `hotel_id`) VALUES ('6', 'est', '6');
INSERT INTO `room_type` (`id`, `name`, `hotel_id`) VALUES ('7', 'sint', '7');
INSERT INTO `room_type` (`id`, `name`, `hotel_id`) VALUES ('8', 'sit', '8');
INSERT INTO `room_type` (`id`, `name`, `hotel_id`) VALUES ('9', 'sit', '9');
INSERT INTO `room_type` (`id`, `name`, `hotel_id`) VALUES ('10', 'est', '10');
INSERT INTO `room_type` (`id`, `name`, `hotel_id`) VALUES ('11', 'harum', '11');
INSERT INTO `room_type` (`id`, `name`, `hotel_id`) VALUES ('12', 'dolor', '12');
INSERT INTO `room_type` (`id`, `name`, `hotel_id`) VALUES ('13', 'minima', '13');
INSERT INTO `room_type` (`id`, `name`, `hotel_id`) VALUES ('14', 'ullam', '14');
INSERT INTO `room_type` (`id`, `name`, `hotel_id`) VALUES ('15', 'sed', '15');
INSERT INTO `room_type` (`id`, `name`, `hotel_id`) VALUES ('16', 'doloribus', '16');
INSERT INTO `room_type` (`id`, `name`, `hotel_id`) VALUES ('17', 'pariatur', '17');
INSERT INTO `room_type` (`id`, `name`, `hotel_id`) VALUES ('18', 'ut', '18');
INSERT INTO `room_type` (`id`, `name`, `hotel_id`) VALUES ('19', 'tempore', '19');
INSERT INTO `room_type` (`id`, `name`, `hotel_id`) VALUES ('20', 'rerum', '20');
INSERT INTO `room_type` (`id`, `name`, `hotel_id`) VALUES ('21', 'corporis', '21');
INSERT INTO `room_type` (`id`, `name`, `hotel_id`) VALUES ('22', 'voluptatem', '22');
INSERT INTO `room_type` (`id`, `name`, `hotel_id`) VALUES ('23', 'omnis', '23');
INSERT INTO `room_type` (`id`, `name`, `hotel_id`) VALUES ('24', 'tenetur', '24');
INSERT INTO `room_type` (`id`, `name`, `hotel_id`) VALUES ('25', 'velit', '25');
INSERT INTO `room_type` (`id`, `name`, `hotel_id`) VALUES ('26', 'voluptatem', '26');
INSERT INTO `room_type` (`id`, `name`, `hotel_id`) VALUES ('27', 'eveniet', '27');
INSERT INTO `room_type` (`id`, `name`, `hotel_id`) VALUES ('28', 'rerum', '28');
INSERT INTO `room_type` (`id`, `name`, `hotel_id`) VALUES ('29', 'qui', '29');
INSERT INTO `room_type` (`id`, `name`, `hotel_id`) VALUES ('30', 'optio', '30');
INSERT INTO `room_type` (`id`, `name`, `hotel_id`) VALUES ('31', 'omnis', '31');
INSERT INTO `room_type` (`id`, `name`, `hotel_id`) VALUES ('32', 'sunt', '32');
INSERT INTO `room_type` (`id`, `name`, `hotel_id`) VALUES ('33', 'qui', '33');
INSERT INTO `room_type` (`id`, `name`, `hotel_id`) VALUES ('34', 'aut', '34');
INSERT INTO `room_type` (`id`, `name`, `hotel_id`) VALUES ('35', 'qui', '35');
INSERT INTO `room_type` (`id`, `name`, `hotel_id`) VALUES ('36', 'cumque', '36');
INSERT INTO `room_type` (`id`, `name`, `hotel_id`) VALUES ('37', 'ratione', '37');
INSERT INTO `room_type` (`id`, `name`, `hotel_id`) VALUES ('38', 'veritatis', '38');
INSERT INTO `room_type` (`id`, `name`, `hotel_id`) VALUES ('39', 'laboriosam', '39');
INSERT INTO `room_type` (`id`, `name`, `hotel_id`) VALUES ('40', 'non', '40');
INSERT INTO `room_type` (`id`, `name`, `hotel_id`) VALUES ('41', 'odit', '41');
INSERT INTO `room_type` (`id`, `name`, `hotel_id`) VALUES ('42', 'minima', '42');
INSERT INTO `room_type` (`id`, `name`, `hotel_id`) VALUES ('43', 'nemo', '43');
INSERT INTO `room_type` (`id`, `name`, `hotel_id`) VALUES ('44', 'quas', '44');
INSERT INTO `room_type` (`id`, `name`, `hotel_id`) VALUES ('45', 'sit', '45');
INSERT INTO `room_type` (`id`, `name`, `hotel_id`) VALUES ('46', 'laudantium', '46');
INSERT INTO `room_type` (`id`, `name`, `hotel_id`) VALUES ('47', 'sit', '47');
INSERT INTO `room_type` (`id`, `name`, `hotel_id`) VALUES ('48', 'occaecati', '48');
INSERT INTO `room_type` (`id`, `name`, `hotel_id`) VALUES ('49', 'ipsa', '49');
INSERT INTO `room_type` (`id`, `name`, `hotel_id`) VALUES ('50', 'non', '50');
INSERT INTO `room_type` (`id`, `name`, `hotel_id`) VALUES ('51', 'aliquam', '51');
INSERT INTO `room_type` (`id`, `name`, `hotel_id`) VALUES ('52', 'sed', '52');
INSERT INTO `room_type` (`id`, `name`, `hotel_id`) VALUES ('53', 'eius', '53');
INSERT INTO `room_type` (`id`, `name`, `hotel_id`) VALUES ('54', 'quia', '54');
INSERT INTO `room_type` (`id`, `name`, `hotel_id`) VALUES ('55', 'iure', '55');
INSERT INTO `room_type` (`id`, `name`, `hotel_id`) VALUES ('56', 'impedit', '56');
INSERT INTO `room_type` (`id`, `name`, `hotel_id`) VALUES ('57', 'doloremque', '57');
INSERT INTO `room_type` (`id`, `name`, `hotel_id`) VALUES ('58', 'necessitatibus', '58');
INSERT INTO `room_type` (`id`, `name`, `hotel_id`) VALUES ('59', 'soluta', '59');
INSERT INTO `room_type` (`id`, `name`, `hotel_id`) VALUES ('60', 'aspernatur', '60');
INSERT INTO `room_type` (`id`, `name`, `hotel_id`) VALUES ('61', 'inventore', '61');
INSERT INTO `room_type` (`id`, `name`, `hotel_id`) VALUES ('62', 'magni', '62');
INSERT INTO `room_type` (`id`, `name`, `hotel_id`) VALUES ('63', 'sunt', '63');
INSERT INTO `room_type` (`id`, `name`, `hotel_id`) VALUES ('64', 'ab', '64');
INSERT INTO `room_type` (`id`, `name`, `hotel_id`) VALUES ('65', 'ut', '65');
INSERT INTO `room_type` (`id`, `name`, `hotel_id`) VALUES ('66', 'deserunt', '66');
INSERT INTO `room_type` (`id`, `name`, `hotel_id`) VALUES ('67', 'molestiae', '67');
INSERT INTO `room_type` (`id`, `name`, `hotel_id`) VALUES ('68', 'eos', '68');
INSERT INTO `room_type` (`id`, `name`, `hotel_id`) VALUES ('69', 'similique', '69');
INSERT INTO `room_type` (`id`, `name`, `hotel_id`) VALUES ('70', 'ut', '70');
INSERT INTO `room_type` (`id`, `name`, `hotel_id`) VALUES ('71', 'est', '71');
INSERT INTO `room_type` (`id`, `name`, `hotel_id`) VALUES ('72', 'sequi', '72');
INSERT INTO `room_type` (`id`, `name`, `hotel_id`) VALUES ('73', 'non', '73');
INSERT INTO `room_type` (`id`, `name`, `hotel_id`) VALUES ('74', 'impedit', '74');
INSERT INTO `room_type` (`id`, `name`, `hotel_id`) VALUES ('75', 'atque', '75');
INSERT INTO `room_type` (`id`, `name`, `hotel_id`) VALUES ('76', 'fugiat', '76');
INSERT INTO `room_type` (`id`, `name`, `hotel_id`) VALUES ('77', 'aut', '77');
INSERT INTO `room_type` (`id`, `name`, `hotel_id`) VALUES ('78', 'dolorum', '78');
INSERT INTO `room_type` (`id`, `name`, `hotel_id`) VALUES ('79', 'quia', '79');
INSERT INTO `room_type` (`id`, `name`, `hotel_id`) VALUES ('80', 'totam', '80');
INSERT INTO `room_type` (`id`, `name`, `hotel_id`) VALUES ('81', 'molestias', '81');
INSERT INTO `room_type` (`id`, `name`, `hotel_id`) VALUES ('82', 'voluptatem', '82');
INSERT INTO `room_type` (`id`, `name`, `hotel_id`) VALUES ('83', 'tempora', '83');
INSERT INTO `room_type` (`id`, `name`, `hotel_id`) VALUES ('84', 'asperiores', '84');
INSERT INTO `room_type` (`id`, `name`, `hotel_id`) VALUES ('85', 'velit', '85');
INSERT INTO `room_type` (`id`, `name`, `hotel_id`) VALUES ('86', 'officiis', '86');
INSERT INTO `room_type` (`id`, `name`, `hotel_id`) VALUES ('87', 'aut', '87');
INSERT INTO `room_type` (`id`, `name`, `hotel_id`) VALUES ('88', 'ex', '88');
INSERT INTO `room_type` (`id`, `name`, `hotel_id`) VALUES ('89', 'dolore', '89');
INSERT INTO `room_type` (`id`, `name`, `hotel_id`) VALUES ('90', 'qui', '90');
INSERT INTO `room_type` (`id`, `name`, `hotel_id`) VALUES ('91', 'dicta', '91');
INSERT INTO `room_type` (`id`, `name`, `hotel_id`) VALUES ('92', 'unde', '92');
INSERT INTO `room_type` (`id`, `name`, `hotel_id`) VALUES ('93', 'maiores', '93');
INSERT INTO `room_type` (`id`, `name`, `hotel_id`) VALUES ('94', 'quia', '94');
INSERT INTO `room_type` (`id`, `name`, `hotel_id`) VALUES ('95', 'sunt', '95');
INSERT INTO `room_type` (`id`, `name`, `hotel_id`) VALUES ('96', 'dolorum', '96');
INSERT INTO `room_type` (`id`, `name`, `hotel_id`) VALUES ('97', 'numquam', '97');
INSERT INTO `room_type` (`id`, `name`, `hotel_id`) VALUES ('98', 'atque', '98');
INSERT INTO `room_type` (`id`, `name`, `hotel_id`) VALUES ('99', 'voluptatibus', '99');
INSERT INTO `room_type` (`id`, `name`, `hotel_id`) VALUES ('100', 'voluptas', '100');


#
# TABLE STRUCTURE FOR: user_pays
#

DROP TABLE IF EXISTS `user_pays`;

CREATE TABLE `user_pays` (
  `user_id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `hotel_id` bigint(20) unsigned NOT NULL,
  `currency` varchar(20) COLLATE utf8_unicode_ci DEFAULT NULL,
  `condition_payments_id` bigint(20) unsigned DEFAULT NULL,
  `amount_payment` decimal(5,2) DEFAULT NULL,
  `target_amount_payment` varchar(100) COLLATE utf8_unicode_ci DEFAULT NULL,
  PRIMARY KEY (`user_id`),
  KEY `condition_payments_id` (`condition_payments_id`),
  KEY `hotel_id` (`hotel_id`),
  CONSTRAINT `user_pays_ibfk_1` FOREIGN KEY (`user_id`) REFERENCES `users` (`id`),
  CONSTRAINT `user_pays_ibfk_2` FOREIGN KEY (`condition_payments_id`) REFERENCES `condition_payments` (`id`),
  CONSTRAINT `user_pays_ibfk_3` FOREIGN KEY (`hotel_id`) REFERENCES `hotels` (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=201 DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

INSERT INTO `user_pays` (`id`, `user_id`, `hotel_id`, `currency`, `condition_payments_id`, `amount_payment`, `target_amount_payment`) VALUES ('1', '101', '1', 'Visa', '1', '0.00', NULL);
INSERT INTO `user_pays` (`id`,`user_id`, `hotel_id`, `currency`, `condition_payments_id`, `amount_payment`, `target_amount_payment`) VALUES ('2', '102', '2', 'American Express', '2', '999.99', NULL);
INSERT INTO `user_pays` (`id`,`user_id`, `hotel_id`, `currency`, `condition_payments_id`, `amount_payment`, `target_amount_payment`) VALUES ('3', '103', '3', 'Visa', '3', '999.99', NULL);
INSERT INTO `user_pays` (`id`,`user_id`, `hotel_id`, `currency`, `condition_payments_id`, `amount_payment`, `target_amount_payment`) VALUES ('4','104', '4', 'Visa', '4', '999.99', NULL);
INSERT INTO `user_pays` (`id`,`user_id`, `hotel_id`, `currency`, `condition_payments_id`, `amount_payment`, `target_amount_payment`) VALUES ('5','105', '5', 'MasterCard', '5', '999.99', NULL);
INSERT INTO `user_pays` (`id`,`user_id`, `hotel_id`, `currency`, `condition_payments_id`, `amount_payment`, `target_amount_payment`) VALUES ('6','106', '6', 'MasterCard', '6', '999.99', NULL);
INSERT INTO `user_pays` (`id`,`user_id`, `hotel_id`, `currency`, `condition_payments_id`, `amount_payment`, `target_amount_payment`) VALUES ('7','107', '7', 'American Express', '7', '999.99', NULL);
INSERT INTO `user_pays` (`id`,`user_id`, `hotel_id`, `currency`, `condition_payments_id`, `amount_payment`, `target_amount_payment`) VALUES ('8','108', '8', 'Visa', '8', '0.00', NULL);
INSERT INTO `user_pays` (`id`,`user_id`, `hotel_id`, `currency`, `condition_payments_id`, `amount_payment`, `target_amount_payment`) VALUES ('9','109', '9', 'MasterCard', '9', '10.57', NULL);
INSERT INTO `user_pays` (`id`,`user_id`, `hotel_id`, `currency`, `condition_payments_id`, `amount_payment`, `target_amount_payment`) VALUES ('10','110', '10', 'Visa', '10', '999.99', NULL);
INSERT INTO `user_pays` (`id`,`user_id`, `hotel_id`, `currency`, `condition_payments_id`, `amount_payment`, `target_amount_payment`) VALUES ('11','112', '12', 'MasterCard', '12', '1.90', NULL);
INSERT INTO `user_pays` (`id`,`user_id`, `hotel_id`, `currency`, `condition_payments_id`, `amount_payment`, `target_amount_payment`) VALUES ('12','114', '14', 'Visa', '14', '1.00', NULL);
INSERT INTO `user_pays` (`id`,`user_id`, `hotel_id`, `currency`, `condition_payments_id`, `amount_payment`, `target_amount_payment`) VALUES ('13','115', '15', 'Visa', '15', '999.99', NULL);
INSERT INTO `user_pays` (`id`,`user_id`, `hotel_id`, `currency`, `condition_payments_id`, `amount_payment`, `target_amount_payment`) VALUES ('14','116', '16', 'MasterCard', '16', '999.99', NULL);
INSERT INTO `user_pays` (`id`,`user_id`, `hotel_id`, `currency`, `condition_payments_id`, `amount_payment`, `target_amount_payment`) VALUES ('15','118', '18', 'MasterCard', '18', '999.99', NULL);
INSERT INTO `user_pays` (`id`,`user_id`, `hotel_id`, `currency`, `condition_payments_id`, `amount_payment`, `target_amount_payment`) VALUES ('16','120', '20', 'MasterCard', '20', '999.99', NULL);
INSERT INTO `user_pays` (`id`,`user_id`, `hotel_id`, `currency`, `condition_payments_id`, `amount_payment`, `target_amount_payment`) VALUES ('17','124', '24', 'Visa', '24', '999.99', NULL);
INSERT INTO `user_pays` (`id`,`user_id`, `hotel_id`, `currency`, `condition_payments_id`, `amount_payment`, `target_amount_payment`) VALUES ('18','126', '26', 'MasterCard', '26', '229.47', NULL);
INSERT INTO `user_pays` (`id`,`user_id`, `hotel_id`, `currency`, `condition_payments_id`, `amount_payment`, `target_amount_payment`) VALUES ('19','127', '27', 'MasterCard', '27', '101.16', NULL);
INSERT INTO `user_pays` (`id`,`user_id`, `hotel_id`, `currency`, `condition_payments_id`, `amount_payment`, `target_amount_payment`) VALUES ('20','128', '28', 'Visa', '28', '999.99', NULL);
INSERT INTO `user_pays` (`id`,`user_id`, `hotel_id`, `currency`, `condition_payments_id`, `amount_payment`, `target_amount_payment`) VALUES ('21','134', '34', 'MasterCard', '34', '37.09', NULL);
INSERT INTO `user_pays` (`id`,`user_id`, `hotel_id`, `currency`, `condition_payments_id`, `amount_payment`, `target_amount_payment`) VALUES ('22','137', '37', 'MasterCard', '37', '999.99', NULL);
INSERT INTO `user_pays` (`id`,`user_id`, `hotel_id`, `currency`, `condition_payments_id`, `amount_payment`, `target_amount_payment`) VALUES ('23','138', '38', 'Visa', '38', '0.02', NULL);
INSERT INTO `user_pays` (`id`,`user_id`, `hotel_id`, `currency`, `condition_payments_id`, `amount_payment`, `target_amount_payment`) VALUES ('24','140', '40', 'MasterCard', '40', '100.00', NULL);
INSERT INTO `user_pays` (`id`,`user_id`, `hotel_id`, `currency`, `condition_payments_id`, `amount_payment`, `target_amount_payment`) VALUES ('25','145', '45', 'MasterCard', '45', '200.00', NULL);
INSERT INTO `user_pays` (`id`,`user_id`, `hotel_id`, `currency`, `condition_payments_id`, `amount_payment`, `target_amount_payment`) VALUES ('26','145', '45', 'MasterCard', '46', '300.00', NULL);
INSERT INTO `user_pays` (`id`,`user_id`, `hotel_id`, `currency`, `condition_payments_id`, `amount_payment`, `target_amount_payment`) VALUES ('27','145', '45', 'American Express', '47', '999.99', NULL);
INSERT INTO `user_pays` (`id`,`user_id`, `hotel_id`, `currency`, `condition_payments_id`, `amount_payment`, `target_amount_payment`) VALUES ('28','148', '48', 'Visa', '48', '14.60', NULL);
INSERT INTO `user_pays` (`id`,`user_id`, `hotel_id`, `currency`, `condition_payments_id`, `amount_payment`, `target_amount_payment`) VALUES ('29','149', '49', 'Visa', '49', '999.99', NULL);
INSERT INTO `user_pays` (`id`,`user_id`, `hotel_id`, `currency`, `condition_payments_id`, `amount_payment`, `target_amount_payment`) VALUES ('30','150', '50', 'Discover Card', '50', '999.99', NULL);
INSERT INTO `user_pays` (`id`,`user_id`, `hotel_id`, `currency`, `condition_payments_id`, `amount_payment`, `target_amount_payment`) VALUES ('31','151', '51', 'MasterCard', '51', '999.99', NULL);
INSERT INTO `user_pays` (`id`,`user_id`, `hotel_id`, `currency`, `condition_payments_id`, `amount_payment`, `target_amount_payment`) VALUES ('32','152', '52', 'Visa', '52', '999.99', NULL);
INSERT INTO `user_pays` (`id`,`user_id`, `hotel_id`, `currency`, `condition_payments_id`, `amount_payment`, `target_amount_payment`) VALUES ('33','153', '53', 'Discover Card', '53', '999.99', NULL);
INSERT INTO `user_pays` (`id`,`user_id`, `hotel_id`, `currency`, `condition_payments_id`, `amount_payment`, `target_amount_payment`) VALUES ('34','154', '54', 'Visa', '54', '999.99', NULL);
INSERT INTO `user_pays` (`id`,`user_id`, `hotel_id`, `currency`, `condition_payments_id`, `amount_payment`, `target_amount_payment`) VALUES ('35','155', '55', 'Visa', '55', '999.99', NULL);
INSERT INTO `user_pays` (`id`,`user_id`, `hotel_id`, `currency`, `condition_payments_id`, `amount_payment`, `target_amount_payment`) VALUES ('36','157', '57', 'Visa', '57', '999.99', NULL);
INSERT INTO `user_pays` (`id`,`user_id`, `hotel_id`, `currency`, `condition_payments_id`, `amount_payment`, `target_amount_payment`) VALUES ('37','159', '59', 'Visa', '59', '3.56', NULL);
INSERT INTO `user_pays` (`id`,`user_id`, `hotel_id`, `currency`, `condition_payments_id`, `amount_payment`, `target_amount_payment`) VALUES ('38','160', '60', 'MasterCard', '60', '2.49', NULL);
INSERT INTO `user_pays` (`id`,`user_id`, `hotel_id`, `currency`, `condition_payments_id`, `amount_payment`, `target_amount_payment`) VALUES ('39','161', '61', 'MasterCard', '61', '1.98', NULL);
INSERT INTO `user_pays` (`id`,`user_id`, `hotel_id`, `currency`, `condition_payments_id`, `amount_payment`, `target_amount_payment`) VALUES ('40','165', '65', 'American Express', '65', '541.62', NULL);
INSERT INTO `user_pays` (`id`,`user_id`, `hotel_id`, `currency`, `condition_payments_id`, `amount_payment`, `target_amount_payment`) VALUES ('41','168', '68', 'American Express', '68', '999.99', NULL);
INSERT INTO `user_pays` (`id`,`user_id`, `hotel_id`, `currency`, `condition_payments_id`, `amount_payment`, `target_amount_payment`) VALUES ('42','170', '70', 'American Express', '70', '999.99', NULL);
INSERT INTO `user_pays` (`id`,`user_id`, `hotel_id`, `currency`, `condition_payments_id`, `amount_payment`, `target_amount_payment`) VALUES ('43','172', '72', 'American Express', '72', '999.99', NULL);
INSERT INTO `user_pays` (`id`,`user_id`, `hotel_id`, `currency`, `condition_payments_id`, `amount_payment`, `target_amount_payment`) VALUES ('44','173', '73', 'MasterCard', '73', '999.99', NULL);
INSERT INTO `user_pays` (`id`,`user_id`, `hotel_id`, `currency`, `condition_payments_id`, `amount_payment`, `target_amount_payment`) VALUES ('45','175', '75', 'Visa', '75', '999.99', NULL);
INSERT INTO `user_pays` (`id`,`user_id`, `hotel_id`, `currency`, `condition_payments_id`, `amount_payment`, `target_amount_payment`) VALUES ('46','176', '76', 'Visa', '76', '999.99', NULL);
INSERT INTO `user_pays` (`id`,`user_id`, `hotel_id`, `currency`, `condition_payments_id`, `amount_payment`, `target_amount_payment`) VALUES ('47','177', '77', 'Visa', '77', '30.50', NULL);
INSERT INTO `user_pays` (`id`,`user_id`, `hotel_id`, `currency`, `condition_payments_id`, `amount_payment`, `target_amount_payment`) VALUES ('48','179', '79', 'MasterCard', '79', '0.16', NULL);
INSERT INTO `user_pays` (`id`,`user_id`, `hotel_id`, `currency`, `condition_payments_id`, `amount_payment`, `target_amount_payment`) VALUES ('49','181', '81', 'MasterCard', '81', '0.00', NULL);
INSERT INTO `user_pays` (`id`,`user_id`, `hotel_id`, `currency`, `condition_payments_id`, `amount_payment`, `target_amount_payment`) VALUES ('50','182', '82', 'Visa', '82', '999.99', NULL);
INSERT INTO `user_pays` (`id`,`user_id`, `hotel_id`, `currency`, `condition_payments_id`, `amount_payment`, `target_amount_payment`) VALUES ('51','183', '83', 'Visa', '83', '732.79', NULL);
INSERT INTO `user_pays` (`id`,`user_id`, `hotel_id`, `currency`, `condition_payments_id`, `amount_payment`, `target_amount_payment`) VALUES ('52','184', '84', 'Visa', '84', '1.80', NULL);
INSERT INTO `user_pays` (`id`,`user_id`, `hotel_id`, `currency`, `condition_payments_id`, `amount_payment`, `target_amount_payment`) VALUES ('53','187', '87', 'Discover Card', '87', '530.01', NULL);
INSERT INTO `user_pays` (`id`,`user_id`, `hotel_id`, `currency`, `condition_payments_id`, `amount_payment`, `target_amount_payment`) VALUES ('54','188', '88', 'MasterCard', '88', '999.99', NULL);
INSERT INTO `user_pays` (`id`,`user_id`, `hotel_id`, `currency`, `condition_payments_id`, `amount_payment`, `target_amount_payment`) VALUES ('55','189', '89', 'MasterCard', '89', '26.32', NULL);
INSERT INTO `user_pays` (`id`,`user_id`, `hotel_id`, `currency`, `condition_payments_id`, `amount_payment`, `target_amount_payment`) VALUES ('56','191', '91', 'Visa', '91', '999.99', NULL);
INSERT INTO `user_pays` (`id`,`user_id`, `hotel_id`, `currency`, `condition_payments_id`, `amount_payment`, `target_amount_payment`) VALUES ('57','193', '93', 'MasterCard', '93', '999.99', NULL);
INSERT INTO `user_pays` (`id`,`user_id`, `hotel_id`, `currency`, `condition_payments_id`, `amount_payment`, `target_amount_payment`) VALUES ('58','194', '94', 'MasterCard', '94', '999.99', NULL);
INSERT INTO `user_pays` (`id`,`user_id`, `hotel_id`, `currency`, `condition_payments_id`, `amount_payment`, `target_amount_payment`) VALUES ('59','195', '95', 'MasterCard', '95', '999.99', NULL);
INSERT INTO `user_pays` (`id`,`user_id`, `hotel_id`, `currency`, `condition_payments_id`, `amount_payment`, `target_amount_payment`) VALUES ('60','196', '96', 'Visa', '96', '0.00', NULL);
INSERT INTO `user_pays` (`id`,`user_id`, `hotel_id`, `currency`, `condition_payments_id`, `amount_payment`, `target_amount_payment`) VALUES ('61','198', '98', 'Visa', '98', '0.73', NULL);
INSERT INTO `user_pays` (`id`,`user_id`, `hotel_id`, `currency`, `condition_payments_id`, `amount_payment`, `target_amount_payment`) VALUES ('62','199', '99', 'MasterCard', '99', '999.99', NULL);


#
# TABLE STRUCTURE FOR: users
#

DROP TABLE IF EXISTS `users`;

CREATE TABLE `users` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `firstname` varchar(50) COLLATE utf8_unicode_ci DEFAULT NULL,
  `lastname` varchar(50) COLLATE utf8_unicode_ci DEFAULT NULL,
  `email` varchar(120) COLLATE utf8_unicode_ci DEFAULT NULL,
  `phone` bigint(20) unsigned DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `email` (`email`),
  UNIQUE KEY `phone` (`phone`),
  KEY `users_email` (`email`),
  KEY `users_phone` (`phone`)
) ENGINE=InnoDB AUTO_INCREMENT=201 DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

INSERT INTO `users` (`id`, `firstname`, `lastname`, `email`, `phone`) VALUES ('101', 'Daphney', 'O\'Reilly', 'josiane.fadel@example.net', '565593');
INSERT INTO `users` (`id`, `firstname`, `lastname`, `email`, `phone`) VALUES ('102', 'Gia', 'Rutherford', 'durward79@example.org', '983880');
INSERT INTO `users` (`id`, `firstname`, `lastname`, `email`, `phone`) VALUES ('103', 'Shanel', 'Upton', 'alison15@example.org', '1');
INSERT INTO `users` (`id`, `firstname`, `lastname`, `email`, `phone`) VALUES ('104', 'Julia', 'Beer', 'doug.miller@example.net', '393');
INSERT INTO `users` (`id`, `firstname`, `lastname`, `email`, `phone`) VALUES ('105', 'Kory', 'Schinner', 'ola.schimmel@example.org', '662942');
INSERT INTO `users` (`id`, `firstname`, `lastname`, `email`, `phone`) VALUES ('106', 'Jeffry', 'Blanda', 'renner.adolfo@example.net', '0');
INSERT INTO `users` (`id`, `firstname`, `lastname`, `email`, `phone`) VALUES ('107', 'Simeon', 'Boyle', 'michaela77@example.net', '329');
INSERT INTO `users` (`id`, `firstname`, `lastname`, `email`, `phone`) VALUES ('108', 'Eva', 'Blanda', 'remington.schneider@example.org', '787');
INSERT INTO `users` (`id`, `firstname`, `lastname`, `email`, `phone`) VALUES ('109', 'Jammie', 'Heller', 'mondricka@example.com', '954683');
INSERT INTO `users` (`id`, `firstname`, `lastname`, `email`, `phone`) VALUES ('110', 'Ned', 'Wyman', 'alda.streich@example.org', '522197');
INSERT INTO `users` (`id`, `firstname`, `lastname`, `email`, `phone`) VALUES ('112', 'Tomasa', 'Corkery', 'ila39@example.net', '5844508034');
INSERT INTO `users` (`id`, `firstname`, `lastname`, `email`, `phone`) VALUES ('114', 'Lori', 'Jones', 'christiansen.ryleigh@example.com', '992');
INSERT INTO `users` (`id`, `firstname`, `lastname`, `email`, `phone`) VALUES ('115', 'Bernard', 'Fritsch', 'micaela36@example.net', '824');
INSERT INTO `users` (`id`, `firstname`, `lastname`, `email`, `phone`) VALUES ('116', 'Emanuel', 'Gleichner', 'wgutmann@example.com', '250');
INSERT INTO `users` (`id`, `firstname`, `lastname`, `email`, `phone`) VALUES ('118', 'Tremayne', 'Dach', 'xschowalter@example.net', '442');
INSERT INTO `users` (`id`, `firstname`, `lastname`, `email`, `phone`) VALUES ('120', 'Nathanael', 'Carter', 'khalid.weissnat@example.com', '695');
INSERT INTO `users` (`id`, `firstname`, `lastname`, `email`, `phone`) VALUES ('124', 'Pietro', 'Romaguera', 'tkuvalis@example.com', '267');
INSERT INTO `users` (`id`, `firstname`, `lastname`, `email`, `phone`) VALUES ('126', 'Deron', 'Schmeler', 'wreilly@example.net', '388858');
INSERT INTO `users` (`id`, `firstname`, `lastname`, `email`, `phone`) VALUES ('127', 'Merle', 'Dickens', 'pconroy@example.net', '896130');
INSERT INTO `users` (`id`, `firstname`, `lastname`, `email`, `phone`) VALUES ('128', 'Liliane', 'Kihn', 'bartoletti.angela@example.com', '255');
INSERT INTO `users` (`id`, `firstname`, `lastname`, `email`, `phone`) VALUES ('134', 'Gabriel', 'Jakubowski', 'cbrekke@example.org', '115790');
INSERT INTO `users` (`id`, `firstname`, `lastname`, `email`, `phone`) VALUES ('137', 'Birdie', 'Beier', 'katrina.anderson@example.com', '280878079');
INSERT INTO `users` (`id`, `firstname`, `lastname`, `email`, `phone`) VALUES ('138', 'Zora', 'Grady', 'antonietta32@example.com', '322226');
INSERT INTO `users` (`id`, `firstname`, `lastname`, `email`, `phone`) VALUES ('140', 'Camille', 'Kub', 'muller.lindsey@example.net', '409');
INSERT INTO `users` (`id`, `firstname`, `lastname`, `email`, `phone`) VALUES ('145', 'Ralph', 'Bins', 'ariane20@example.org', '636668');
INSERT INTO `users` (`id`, `firstname`, `lastname`, `email`, `phone`) VALUES ('146', 'Ethan', 'Rowe', 'blair.hirthe@example.net', '13');
INSERT INTO `users` (`id`, `firstname`, `lastname`, `email`, `phone`) VALUES ('147', 'Joanie', 'Romaguera', 'tkrajcik@example.net', '968045');
INSERT INTO `users` (`id`, `firstname`, `lastname`, `email`, `phone`) VALUES ('148', 'Jeff', 'Nolan', 'nboehm@example.net', '713');
INSERT INTO `users` (`id`, `firstname`, `lastname`, `email`, `phone`) VALUES ('149', 'Green', 'Buckridge', 'emmie07@example.org', '88');
INSERT INTO `users` (`id`, `firstname`, `lastname`, `email`, `phone`) VALUES ('150', 'Valentina', 'Heidenreich', 'nader.marques@example.org', '6335233308');
INSERT INTO `users` (`id`, `firstname`, `lastname`, `email`, `phone`) VALUES ('151', 'Jordane', 'Rogahn', 'elijah.veum@example.org', '5398312213');
INSERT INTO `users` (`id`, `firstname`, `lastname`, `email`, `phone`) VALUES ('152', 'Christina', 'Smitham', 'green.dovie@example.com', '711');
INSERT INTO `users` (`id`, `firstname`, `lastname`, `email`, `phone`) VALUES ('153', 'Nat', 'Ortiz', 'eritchie@example.org', '98');
INSERT INTO `users` (`id`, `firstname`, `lastname`, `email`, `phone`) VALUES ('154', 'Vergie', 'Eichmann', 'brakus.alize@example.com', '620');
INSERT INTO `users` (`id`, `firstname`, `lastname`, `email`, `phone`) VALUES ('155', 'Heidi', 'Weimann', 'dickinson.alena@example.com', '82');
INSERT INTO `users` (`id`, `firstname`, `lastname`, `email`, `phone`) VALUES ('157', 'Forrest', 'Bergnaum', 'dudley.dibbert@example.net', '415');
INSERT INTO `users` (`id`, `firstname`, `lastname`, `email`, `phone`) VALUES ('159', 'Emily', 'McCullough', 'martin.fadel@example.net', '118913');
INSERT INTO `users` (`id`, `firstname`, `lastname`, `email`, `phone`) VALUES ('160', 'Bernice', 'Pfeffer', 'ashley70@example.org', '593');
INSERT INTO `users` (`id`, `firstname`, `lastname`, `email`, `phone`) VALUES ('161', 'Dominic', 'Turner', 'mosciski.isaias@example.net', '740388');
INSERT INTO `users` (`id`, `firstname`, `lastname`, `email`, `phone`) VALUES ('165', 'Sunny', 'Graham', 'dsmith@example.org', '9173549632');
INSERT INTO `users` (`id`, `firstname`, `lastname`, `email`, `phone`) VALUES ('168', 'Citlalli', 'Hane', 'emilie67@example.net', '834991');
INSERT INTO `users` (`id`, `firstname`, `lastname`, `email`, `phone`) VALUES ('170', 'Toney', 'Walsh', 'glen35@example.com', '335');
INSERT INTO `users` (`id`, `firstname`, `lastname`, `email`, `phone`) VALUES ('172', 'Marcelina', 'Little', 'grimes.keith@example.net', '187282');
INSERT INTO `users` (`id`, `firstname`, `lastname`, `email`, `phone`) VALUES ('173', 'Katelin', 'Simonis', 'vandervort.rubie@example.org', '297944');
INSERT INTO `users` (`id`, `firstname`, `lastname`, `email`, `phone`) VALUES ('175', 'Andreane', 'Mohr', 'chelsie19@example.com', '358879');
INSERT INTO `users` (`id`, `firstname`, `lastname`, `email`, `phone`) VALUES ('176', 'Aaron', 'Ryan', 'russel.kulas@example.com', '403005');
INSERT INTO `users` (`id`, `firstname`, `lastname`, `email`, `phone`) VALUES ('177', 'Amanda', 'Hansen', 'wellington39@example.org', '953');
INSERT INTO `users` (`id`, `firstname`, `lastname`, `email`, `phone`) VALUES ('179', 'Chloe', 'Fritsch', 'jayde.mclaughlin@example.com', '691');
INSERT INTO `users` (`id`, `firstname`, `lastname`, `email`, `phone`) VALUES ('181', 'Krystina', 'Nitzsche', 'orlando.altenwerth@example.com', '545546');
INSERT INTO `users` (`id`, `firstname`, `lastname`, `email`, `phone`) VALUES ('182', 'Ceasar', 'Hickle', 'vbalistreri@example.org', '668');
INSERT INTO `users` (`id`, `firstname`, `lastname`, `email`, `phone`) VALUES ('183', 'Isidro', 'Dietrich', 'vrempel@example.org', '561');
INSERT INTO `users` (`id`, `firstname`, `lastname`, `email`, `phone`) VALUES ('184', 'Leland', 'Crona', 'akonopelski@example.com', '97');
INSERT INTO `users` (`id`, `firstname`, `lastname`, `email`, `phone`) VALUES ('187', 'Dario', 'Wiza', 'kyra.kautzer@example.org', '1347116149');
INSERT INTO `users` (`id`, `firstname`, `lastname`, `email`, `phone`) VALUES ('188', 'Ebba', 'Waters', 'cnader@example.com', '586');
INSERT INTO `users` (`id`, `firstname`, `lastname`, `email`, `phone`) VALUES ('189', 'Ahmed', 'Nikolaus', 'nwisoky@example.org', '4015223356');
INSERT INTO `users` (`id`, `firstname`, `lastname`, `email`, `phone`) VALUES ('191', 'Hermann', 'Schulist', 'joan49@example.org', '617');
INSERT INTO `users` (`id`, `firstname`, `lastname`, `email`, `phone`) VALUES ('193', 'Estell', 'Dicki', 'bulah.dubuque@example.net', '9920394711');
INSERT INTO `users` (`id`, `firstname`, `lastname`, `email`, `phone`) VALUES ('194', 'Fidel', 'Hauck', 'garrick.hammes@example.com', '962140');
INSERT INTO `users` (`id`, `firstname`, `lastname`, `email`, `phone`) VALUES ('195', 'Kieran', 'White', 'wolff.gregory@example.com', '150794');
INSERT INTO `users` (`id`, `firstname`, `lastname`, `email`, `phone`) VALUES ('196', 'Sydni', 'Williamson', 'reyna.conn@example.org', '124819');
INSERT INTO `users` (`id`, `firstname`, `lastname`, `email`, `phone`) VALUES ('198', 'Leonie', 'Pfannerstill', 'flatley.viola@example.net', '511914');
INSERT INTO `users` (`id`, `firstname`, `lastname`, `email`, `phone`) VALUES ('199', 'Spencer', 'Dickinson', 'gust.zulauf@example.com', '934');


