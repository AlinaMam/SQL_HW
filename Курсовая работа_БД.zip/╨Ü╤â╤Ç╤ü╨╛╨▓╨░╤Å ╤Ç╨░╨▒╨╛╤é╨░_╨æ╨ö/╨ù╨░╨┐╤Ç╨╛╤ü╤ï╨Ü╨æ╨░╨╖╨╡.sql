use booking;

-- вложенный запрос
-- мы ищем всех пользователей из таблицы users у которых было трое детей

select * from users where id in (select user_id from hotel_reservations where number_children = 3);

-- JOIN
-- выводим имя, фамилию из таблицы users и способ оплаты 'VISA' из таблицы user_pays

select u.firstname, u.lastname, up.currency
	from users u, user_pays up
    where u.id = up.user_id and up.currency = 'VISA';

-- группировка
-- выводим пользователей и общую сумму их платежей, группируем по пользователю

select user_id, sum(amount_payment) from user_pays group by user_id;

-- представления
-- задание 1: создаем представление таблицы hotel_reservations и выбираем всех пользователей у которых кол-во детей = 3

create view users_children
	as select *
		from hotel_reservations
        where number_children = 3;

select * from users_children;


-- задание 2: создаем представление таблицы user_pays и выбираем пользователей, которые платили Discover Card

create view user_card
	as select *
		from user_pays
        where currency = 'Discover Card';

select * from user_card;


-- триггер
-- создаем триггер, который после вставки определенного пользователя показывает сообщение 'Такой пользователь уже существует'


delimiter //
create trigger specific_user before insert
on profiles
for each row
	begin
    if (new.user_id = 200) then
		signal sqlstate '35567' set message_text = 'Такой пользователь уже существует';
	end if;
    end //
delimiter;


insert into profiles (`user_id`, `gender`, `birthday`, `created_at`, `hometown`) values ('200', 'P', '1980-08-11', '1997-05-29 23:42:06', 'Port');

-- процедура
-- создаем процедуру, которая будет показывать список пользователей с пятью детьми

drop procedure if exists children;
delimiter //
create procedure children (user_children int unsigned)
begin
	select user_id, number_children
    from hotel_reservations
    where number_children = 3;
end //

delimiter ;
  
call children(3);
    